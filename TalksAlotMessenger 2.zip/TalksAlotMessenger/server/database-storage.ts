import {
  users,
  chatRooms,
  messages,
  matchRequests,
  type User,
  type UpsertUser,
  type InsertUser,
  type ChatRoom,
  type InsertChatRoom,
  type Message,
  type InsertMessage,
  type MatchRequest,
  type InsertMatchRequest,
} from "../shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializeDefaultRooms();
  }

  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Extended user operations
  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values(user)
      .returning();
    return newUser;
  }

  async getUserById(id: string): Promise<User | null> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || null;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | null> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user || null;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getOnlineUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.isOnline, true));
  }

  private async initializeDefaultRooms() {
    const existingRooms = await db.select().from(chatRooms);
    if (existingRooms.length > 0) return; // Rooms already initialized

    const defaultRooms: InsertChatRoom[] = [
      { name: "Fun Chatters", description: "Share jokes, memes, and have a laugh together!", emoji: "😄", category: "general" },
      { name: "Deep Thinkers", description: "Mature philosophical discussions for those who appreciate nuanced conversation", emoji: "🤔", category: "deep" },
      { name: "Vent Space", description: "Safe space for when you need to talk it out - no judgment, just listening", emoji: "💭", category: "support" },
      { name: "Rants & Real Talk", description: "Get it all out - passionate discussions and authentic conversations", emoji: "🗣️", category: "rants" },
      { name: "Dating & Relationships", description: "Love, dating, relationships - real talk about modern romance", emoji: "💕", category: "relationships" },
      { name: "RambleRealm", description: "20-minute timed speaking sessions - get it all out!", emoji: "⏰", category: "structured" },
      { name: "DialogueDen", description: "Deep, thoughtful conversations that matter", emoji: "💬", category: "meaningful" },
      { name: "BabbleBae", description: "Getting to know people on a deeper level - spark potential connections", emoji: "✨", category: "connections" },
      { name: "Sacred Space", description: "Spiritual discussions, universal laws, and higher consciousness conversations", emoji: "🙏", category: "spiritual" },
      { name: "Breaking Cycles (20s)", description: "For 20-26 year olds healing from generational patterns and rewriting family stories", emoji: "🌱", category: "healing" },
      { name: "Wisdom & Healing", description: "Older adults on healing journeys, breaking old patterns, and finding new growth", emoji: "🌿", category: "healing" },
      { name: "The Rant Zone", description: "Need to vent? Let it all out here - passionate discussions welcome", emoji: "💢", category: "rants" },
      { name: "Late Night Venting", description: "Can't sleep? Need to talk through the night? We're here for you", emoji: "🌙", category: "support" },
      { name: "Single & Talkative", description: "Single adults who love to talk - connect with fellow conversationalists", emoji: "🗨️", category: "singles" },
      { name: "Talk it Out (Mental Health)", description: "Safe space for mental health conversations - supportive community", emoji: "🧠", category: "mental-health" },
      { name: "Healing Hearts", description: "Gentle space for those on a healing journey - trauma-informed support", emoji: "💚", category: "mental-health" },
      { name: "Safe Harbor", description: "Protected space for vulnerable conversations - judgment-free zone", emoji: "🏠", category: "mental-health" },
      { name: "Recovery Circle", description: "Support for addiction recovery, mental health recovery, and life rebuilding", emoji: "🔄", category: "mental-health" },
      { name: "Anxiety & Depression Support", description: "Understanding community for anxiety, depression, and mental health struggles", emoji: "🤝", category: "mental-health" },
      { name: "Life Advice Corner", description: "Get guidance and share wisdom with others", emoji: "💡", category: "advice" },
      { name: "LGBTQIA+ Community", description: "Connect with fellow community members", emoji: "🏳️‍🌈", category: "community" },
      { name: "Entrepreneurs Hub", description: "Business minds and startup enthusiasts unite!", emoji: "💼", category: "business" },
      { name: "Bug Enthusiasts", description: "Talk about insects, beetles, butterflies and all things creepy crawly!", emoji: "🐛", category: "hobbies" },
      { name: "Animal Lovers", description: "Share stories about pets, wildlife, and our furry friends", emoji: "🐾", category: "animals" },
      { name: "Sky Watchers", description: "Astronomy, weather, clouds, sunsets - everything above us!", emoji: "🌌", category: "nature" },
      { name: "Cannabis Friendly", description: "Open-minded discussions about cannabis culture and experiences", emoji: "🌿", category: "lifestyle" },
      { name: "Music Corner", description: "Share your favorite tunes and discover new artists", emoji: "🎵", category: "entertainment" },
      { name: "Movie Night", description: "Discuss films, series, and everything entertainment", emoji: "🎬", category: "entertainment" },
      { name: "Gaming Zone", description: "Talk about video games, board games, and gaming culture", emoji: "🎮", category: "gaming" },
      { name: "Foodies United", description: "Share recipes, restaurant recommendations, and food adventures", emoji: "🍕", category: "food" },
      { name: "Travel Stories", description: "Share your adventures and dream destinations", emoji: "✈️", category: "travel" },
      { name: "Mindful Conversations", description: "A respectful space for adults who understand that meaningful dialogue is rare and precious", emoji: "🧘", category: "mindful" },
      { name: "Understanding Hearts", description: "For mature individuals who know the value of authentic conversation and connection", emoji: "❤️", category: "mature" },
      { name: "Night Owls", description: "Can't sleep? Home alone? Let's chat through the night!", emoji: "🦉", category: "late-night" },
      { name: "Cook Together Kitchen", description: "Live cooking sessions with video chat - cook together in real-time!", emoji: "👨‍🍳", category: "food" },
      { name: "Holiday Chatter", description: "Celebrate seasons and holidays together with festive conversations", emoji: "🎄", category: "seasonal" },
      { name: "Book Club Corner", description: "Discuss current reads, recommend books, and share literary adventures", emoji: "📚", category: "literature" },
      { name: "Language Exchange", description: "Practice languages with native speakers and learn together", emoji: "🗣️", category: "education" },
      { name: "College Years", description: "Current students and recent grads - navigate academic life together", emoji: "🎓", category: "education" },
      { name: "Empty Nesters", description: "Parents whose kids have grown up - new chapter conversations", emoji: "🏠", category: "life-stages" },
      { name: "Career Mentoring", description: "Professional guidance, career advice, and workplace discussions", emoji: "💼", category: "career" },
      { name: "Creative Corner", description: "Artists, writers, musicians - share your creative journey", emoji: "🎨", category: "creative" },
      { name: "Tech Talk", description: "Discuss technology, coding, gadgets, and digital life", emoji: "💻", category: "technology" },
      { name: "Fitness & Wellness", description: "Health goals, workout tips, and wellness conversations", emoji: "💪", category: "health" },
      { name: "Parenting Circle", description: "Parents supporting parents through all stages of child-rearing", emoji: "👶", category: "parenting" },
      { name: "Retirement Adventures", description: "Golden years conversations - hobbies, travel, and new beginnings", emoji: "🌅", category: "life-stages" },
      { name: "Financial Freedom", description: "Money management, investing, and financial independence discussions", emoji: "💰", category: "finance" },
      { name: "Home & Garden", description: "Decorating, gardening, DIY projects, and making your space beautiful", emoji: "🏡", category: "lifestyle" },
      { name: "Philosophy Lounge", description: "Deep philosophical discussions and life's big questions", emoji: "🤯", category: "philosophy" },
      { name: "Science Enthusiasts", description: "Explore discoveries, theories, and the wonders of science", emoji: "🔬", category: "science" }
    ];

    for (const room of defaultRooms) {
      await db.insert(chatRooms).values(room);
    }
  }

  // Chat room operations
  async createChatRoom(room: InsertChatRoom): Promise<ChatRoom> {
    const [newRoom] = await db
      .insert(chatRooms)
      .values(room)
      .returning();
    return newRoom;
  }

  async getChatRoomById(id: string): Promise<ChatRoom | null> {
    const [room] = await db.select().from(chatRooms).where(eq(chatRooms.id, id));
    return room || null;
  }

  async getAllChatRooms(): Promise<ChatRoom[]> {
    return await db.select().from(chatRooms);
  }

  async getActiveChatRooms(): Promise<ChatRoom[]> {
    return await db.select().from(chatRooms).where(eq(chatRooms.isActive, true));
  }

  async updateChatRoom(id: string, updates: Partial<InsertChatRoom>): Promise<ChatRoom | null> {
    const [room] = await db
      .update(chatRooms)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(chatRooms.id, id))
      .returning();
    return room || null;
  }

  async joinChatRoom(roomId: string, userId: string): Promise<ChatRoom | null> {
    const room = await this.getChatRoomById(roomId);
    if (!room) return null;

    const participants = room.participants || [];
    if (!participants.includes(userId)) {
      participants.push(userId);
      return await this.updateChatRoom(roomId, { participants });
    }
    return room;
  }

  async leaveChatRoom(roomId: string, userId: string): Promise<ChatRoom | null> {
    const room = await this.getChatRoomById(roomId);
    if (!room) return null;

    const participants = (room.participants || []).filter(id => id !== userId);
    return await this.updateChatRoom(roomId, { participants });
  }

  // Message operations
  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db
      .insert(messages)
      .values(message)
      .returning();
    return newMessage;
  }

  async getMessagesByRoomId(roomId: string): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.roomId, roomId));
  }

  // Match request operations
  async createMatchRequest(request: InsertMatchRequest): Promise<MatchRequest> {
    const [newRequest] = await db
      .insert(matchRequests)
      .values(request)
      .returning();
    return newRequest;
  }

  async getMatchRequests(): Promise<MatchRequest[]> {
    return await db.select().from(matchRequests);
  }

  async deleteMatchRequest(id: string): Promise<boolean> {
    const result = await db.delete(matchRequests).where(eq(matchRequests.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  async findMatchForUser(userId: string, topic: string): Promise<MatchRequest | null> {
    const [match] = await db.select().from(matchRequests).where(
      eq(matchRequests.preferredTopic, topic)
    );
    return match || null;
  }
}