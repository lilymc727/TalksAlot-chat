import { Request, Response, Router } from "express";
import { z } from "zod";
import type { InsertUser, InsertChatRoom, InsertMessage, InsertMatchRequest } from "@shared/schema";
import type { IStorage } from "./storage";
import Stripe from "stripe";

// Stripe disabled until account verification completes
const stripe = null;

export function createRouter(storage: IStorage): Router {
  const router = Router();

  // Health check endpoint for deployment
  router.get("/", (req: Request, res: Response) => {
    res.json({ 
      status: "ok", 
      message: "TalksAlot server is running",
      timestamp: new Date().toISOString()
    });
  });

  router.get("/health", (req: Request, res: Response) => {
    res.json({ 
      status: "healthy", 
      service: "TalksAlot Chat Application",
      timestamp: new Date().toISOString()
    });
  });

  // User routes
  router.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData: InsertUser = req.body;
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  router.get("/api/users/:id", async (req: Request, res: Response) => {
    const user = await storage.getUserById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  });

  router.patch("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const updates: Partial<InsertUser> = req.body;
      const user = await storage.updateUser(req.params.id, updates);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid update data" });
    }
  });

  router.get("/api/users", async (req: Request, res: Response) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  router.get("/api/users/online", async (req: Request, res: Response) => {
    const onlineUsers = await storage.getOnlineUsers();
    res.json(onlineUsers);
  });

  // Chat room routes
  router.get("/api/rooms", async (req: Request, res: Response) => {
    const rooms = await storage.getActiveChatRooms();
    res.json(rooms);
  });

  router.get("/api/rooms/:id", async (req: Request, res: Response) => {
    const room = await storage.getChatRoomById(req.params.id);
    if (!room) {
      return res.status(404).json({ error: "Room not found" });
    }
    res.json(room);
  });

  router.post("/api/rooms", async (req: Request, res: Response) => {
    try {
      const roomData: InsertChatRoom = req.body;
      const room = await storage.createChatRoom(roomData);
      res.json(room);
    } catch (error) {
      res.status(400).json({ error: "Invalid room data" });
    }
  });

  router.post("/api/rooms/:id/join", async (req: Request, res: Response) => {
    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ error: "User ID required" });
    }

    const room = await storage.joinChatRoom(req.params.id, userId);
    if (!room) {
      return res.status(404).json({ error: "Room not found" });
    }
    res.json(room);
  });

  router.post("/api/rooms/:id/leave", async (req: Request, res: Response) => {
    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ error: "User ID required" });
    }

    const room = await storage.leaveChatRoom(req.params.id, userId);
    if (!room) {
      return res.status(404).json({ error: "Room not found" });
    }
    res.json(room);
  });

  // Message routes
  router.get("/api/rooms/:id/messages", async (req: Request, res: Response) => {
    const messages = await storage.getMessagesByRoomId(req.params.id);
    res.json(messages);
  });

  router.post("/api/messages", async (req: Request, res: Response) => {
    try {
      const messageData: InsertMessage = req.body;
      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      res.status(400).json({ error: "Invalid message data" });
    }
  });

  // Match request routes
  router.post("/api/match-requests", async (req: Request, res: Response) => {
    try {
      const requestData: InsertMatchRequest = req.body;
      
      // Check if there's already a match waiting
      const existingMatch = await storage.findMatchForUser(
        requestData.userId, 
        requestData.preferredTopic
      );

      if (existingMatch) {
        // Remove the existing match request and return both users
        await storage.deleteMatchRequest(existingMatch.id);
        res.json({ 
          matched: true, 
          matchedWith: existingMatch.userId,
          topic: requestData.preferredTopic
        });
      } else {
        // Create new match request
        const matchRequest = await storage.createMatchRequest(requestData);
        res.json({ 
          matched: false, 
          requestId: matchRequest.id,
          waiting: true
        });
      }
    } catch (error) {
      res.status(400).json({ error: "Invalid match request data" });
    }
  });

  router.delete("/api/match-requests/:id", async (req: Request, res: Response) => {
    const deleted = await storage.deleteMatchRequest(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Match request not found" });
    }
    res.json({ success: true });
  });

  // Subscription routes
  router.post("/api/create-subscription", async (req: Request, res: Response) => {
    if (!stripe) {
      return res.status(500).json({ error: "Stripe not configured" });
    }

    try {
      const { planType, userId, userEmail } = req.body;

      // Create or retrieve customer
      let customer;
      try {
        customer = await stripe.customers.create({
          email: userEmail,
          metadata: {
            userId: userId,
            planType: planType
          }
        });
      } catch (error) {
        return res.status(400).json({ error: "Failed to create customer" });
      }

      // Set trial end to 12 hours from now
      const trialEnd = Math.floor(Date.now() / 1000) + (12 * 60 * 60); // 12 hours in seconds

      // Define price based on plan
      const prices = {
        monthly: 800, // $8.00 in cents
        yearly: 8000  // $80.00 in cents
      };

      // Create checkout session
      const session = await stripe.checkout.sessions.create({
        customer: customer.id,
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              product_data: {
                name: 'TalksAlot Premium',
                description: planType === 'yearly' 
                  ? 'Annual subscription (2 months free!)' 
                  : 'Monthly subscription',
              },
              unit_amount: prices[planType as keyof typeof prices],
              recurring: {
                interval: planType === 'yearly' ? 'year' : 'month',
              },
            },
            quantity: 1,
          },
        ],
        mode: 'subscription',
        success_url: `${req.headers.origin}/?success=true&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.headers.origin}/?canceled=true`,
        subscription_data: {
          trial_end: trialEnd,
          metadata: {
            userId: userId,
            planType: planType
          }
        },
        allow_promotion_codes: true,
      });

      // Update user with trial end time
      await storage.updateUser(userId, {
        trialEnd: new Date(trialEnd * 1000),
        subscriptionStatus: 'trialing'
      });

      res.json({ checkoutUrl: session.url, trialEnd: trialEnd });
    } catch (error: any) {
      console.error('Subscription error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  router.post("/api/webhook/stripe", async (req: Request, res: Response) => {
    if (!stripe) {
      return res.status(500).json({ error: "Stripe not configured" });
    }

    const sig = req.headers['stripe-signature'];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    if (!sig || !webhookSecret) {
      return res.status(400).json({ error: "Missing signature or webhook secret" });
    }

    try {
      const event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);

      switch (event.type) {
        case 'checkout.session.completed':
          const session = event.data.object as Stripe.Checkout.Session;
          const userId = session.metadata?.userId;
          
          if (userId && session.subscription) {
            // User completed checkout - they're now in trial
            await storage.updateUser(userId, {
              subscriptionId: session.subscription as string,
              subscriptionStatus: 'trialing'
            });
          }
          break;

        case 'customer.subscription.updated':
        case 'invoice.payment_succeeded':
          const subscription = event.data.object as any;
          const subUserId = subscription.metadata?.userId;
          
          if (subUserId) {
            // Payment succeeded - user is now fully subscribed
            await storage.updateUser(subUserId, {
              isSubscribed: true,
              subscriptionId: subscription.id,
              subscriptionStatus: subscription.status
            });
          }
          break;

        case 'customer.subscription.deleted':
        case 'invoice.payment_failed':
          const failedSubscription = event.data.object as any;
          const failedUserId = failedSubscription.metadata?.userId;
          
          if (failedUserId) {
            await storage.updateUser(failedUserId, {
              isSubscribed: false,
              subscriptionId: null,
              subscriptionStatus: 'canceled'
            });
          }
          break;
      }

      res.json({ received: true });
    } catch (error: any) {
      console.error('Webhook error:', error);
      res.status(400).json({ error: error.message });
    }
  });

  router.get("/api/subscription-status", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ error: "User ID required" });
      }

      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const now = new Date();
      const trialEnd = user.trialEnd ? new Date(user.trialEnd) : null;
      const isInTrial = trialEnd && now < trialEnd;
      const hoursLeftInTrial = trialEnd ? Math.max(0, Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60))) : 0;

      res.json({
        isSubscribed: user.isSubscribed || false,
        isInTrial,
        hoursLeftInTrial,
        subscriptionStatus: user.subscriptionStatus || 'none',
        hasAccess: user.isSubscribed || isInTrial
      });
    } catch (error: any) {
      console.error('Subscription status error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Contact Creator endpoint
  router.post("/api/contact-creator", async (req: Request, res: Response) => {
    try {
      const { name, email, subject, message, messageType } = req.body;
      
      // Validate required fields
      if (!name || !email || !subject || !message) {
        return res.status(400).json({ error: "All fields are required" });
      }

      // Log the contact message (in production, you'd send to email service or save to database)
      console.log("Contact Creator Message Received:", {
        name,
        email,
        subject,
        message,
        messageType,
        timestamp: new Date().toISOString()
      });

      // TODO: Integrate with email service (SendGrid, Mailgun, etc.)
      // or save to database for admin review

      res.json({ 
        success: true, 
        message: "Your message has been sent successfully!" 
      });
    } catch (error) {
      console.error("Error processing contact message:", error);
      res.status(500).json({ error: "Failed to send message" });
    }
  });

  return router;
}