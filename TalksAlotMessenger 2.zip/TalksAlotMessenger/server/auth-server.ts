import express from "express";
import cors from "cors";
import { registerRoutes } from "./auth-routes";

async function startServer() {
  const app = express();
  const port = process.env.PORT || 3000;

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Register authentication routes
  const httpServer = await registerRoutes(app);

  // Start the server
  httpServer.listen(port, "0.0.0.0", () => {
    console.log(`🗣️ TalksAlot server with Replit Auth running on port ${port}`);
    console.log(`🔐 Authenticated chat application ready!`);
    console.log(`💬 47+ chat rooms available for verified users`);
  });

  // Graceful shutdown handling
  process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down TalksAlot server gracefully...');
    httpServer.close(() => {
      console.log('✅ Server closed successfully');
      process.exit(0);
    });
  });

  process.on('SIGTERM', () => {
    console.log('\n🛑 Received SIGTERM, shutting down gracefully...');
    httpServer.close(() => {
      console.log('✅ Server closed successfully');
      process.exit(0);
    });
  });
}

startServer().catch(console.error);