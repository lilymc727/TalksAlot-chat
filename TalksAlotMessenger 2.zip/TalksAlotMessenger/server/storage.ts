import type { User, InsertUser, ChatRoom, InsertChatRoom, Message, InsertMessage, MatchRequest, InsertMatchRequest, UpsertUser } from "../shared/schema";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Extended user operations
  createUser(user: InsertUser): Promise<User>;
  getUserById(id: string): Promise<User | null>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User | null>;
  getAllUsers(): Promise<User[]>;
  getOnlineUsers(): Promise<User[]>;
  
  // Chat room operations
  createChatRoom(room: InsertChatRoom): Promise<ChatRoom>;
  getChatRoomById(id: string): Promise<ChatRoom | null>;
  getAllChatRooms(): Promise<ChatRoom[]>;
  getActiveChatRooms(): Promise<ChatRoom[]>;
  updateChatRoom(id: string, updates: Partial<InsertChatRoom>): Promise<ChatRoom | null>;
  joinChatRoom(roomId: string, userId: string): Promise<ChatRoom | null>;
  leaveChatRoom(roomId: string, userId: string): Promise<ChatRoom | null>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByRoomId(roomId: string): Promise<Message[]>;
  
  // Match request operations
  createMatchRequest(request: InsertMatchRequest): Promise<MatchRequest>;
  getMatchRequests(): Promise<MatchRequest[]>;
  deleteMatchRequest(id: string): Promise<boolean>;
  findMatchForUser(userId: string, topic: string): Promise<MatchRequest | null>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private chatRooms: Map<string, ChatRoom> = new Map();
  private messages: Map<string, Message> = new Map();
  private matchRequests: Map<string, MatchRequest> = new Map();

  constructor() {
    this.initializeDefaultRooms();
  }

  // Required for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = this.users.get(userData.id!);
    
    if (existingUser) {
      // Update existing user
      const updatedUser: User = {
        ...existingUser,
        ...userData,
        updatedAt: new Date(),
      };
      this.users.set(userData.id!, updatedUser);
      return updatedUser;
    } else {
      // Create new user
      const newUser: User = {
        id: userData.id!,
        email: userData.email || null,
        firstName: userData.firstName || null,
        lastName: userData.lastName || null,
        profileImageUrl: userData.profileImageUrl || null,
        name: userData.name || `${userData.firstName || ''} ${userData.lastName || ''}`.trim() || 'Anonymous',
        age: userData.age || null,
        location: userData.location || null,
        bio: userData.bio || null,
        photoUrl: userData.photoUrl || userData.profileImageUrl || null,
        talkStyle: userData.talkStyle || null,
        favoriteTopics: userData.favoriteTopics || [],
        interests: userData.interests || [],
        isOnline: userData.isOnline || false,
        talkStreak: userData.talkStreak || 1,
        badges: userData.badges || [],
        joinedAt: userData.joinedAt || new Date(),
        lastActiveAt: userData.lastActiveAt || new Date(),
        preferences: userData.preferences || null,
        karmaScore: userData.karmaScore || 0,
        isVerified: true, // All Replit users are verified
        timezone: userData.timezone || null,
        createdAt: userData.createdAt || new Date(),
        updatedAt: userData.updatedAt || new Date(),
      };
      this.users.set(userData.id!, newUser);
      return newUser;
    }
  }

  private initializeDefaultRooms() {
    const defaultRooms: InsertChatRoom[] = [
      { name: "Fun Chatters", description: "Share jokes, memes, and have a laugh together!", emoji: "😄", category: "general", participants: [] },
      { name: "Deep Thinkers", description: "Mature philosophical discussions for those who appreciate nuanced conversation", emoji: "🤔", category: "deep", participants: [] },
      { name: "Vent Space", description: "Safe space for when you need to talk it out - no judgment, just listening", emoji: "💭", category: "support", participants: [] },
      { name: "Rants & Real Talk", description: "Get it all out - passionate discussions and authentic conversations", emoji: "🗣️", category: "rants", participants: [] },
      { name: "Dating & Relationships", description: "Love, dating, relationships - real talk about modern romance", emoji: "💕", category: "relationships", participants: [] },
      { name: "RambleRealm", description: "20-minute timed speaking sessions - get it all out!", emoji: "⏰", category: "structured", participants: [] },
      { name: "DialogueDen", description: "Deep, thoughtful conversations that matter", emoji: "💬", category: "meaningful", participants: [] },
      { name: "BabbleBae", description: "Getting to know people on a deeper level - spark potential connections", emoji: "✨", category: "connections", participants: [] },
      { name: "Sacred Space", description: "Spiritual discussions, universal laws, and higher consciousness conversations", emoji: "🙏", category: "spiritual", participants: [] },
      { name: "Breaking Cycles (20s)", description: "For 20-26 year olds healing from generational patterns and rewriting family stories", emoji: "🌱", category: "healing", participants: [] },
      { name: "Wisdom & Healing", description: "Older adults on healing journeys, breaking old patterns, and finding new growth", emoji: "🌿", category: "healing", participants: [] },
      { name: "The Rant Zone", description: "Need to vent? Let it all out here - passionate discussions welcome", emoji: "💢", category: "rants", participants: [] },
      { name: "Late Night Venting", description: "Can't sleep? Need to talk through the night? We're here for you", emoji: "🌙", category: "support", participants: [] },
      { name: "Single & Talkative", description: "Single adults who love to talk - connect with fellow conversationalists", emoji: "🗨️", category: "singles", participants: [] },
      { name: "Talk it Out (Mental Health)", description: "Safe space for mental health conversations - supportive community", emoji: "🧠", category: "mental-health", participants: [] },
      { name: "Healing Hearts", description: "Gentle space for those on a healing journey - trauma-informed support", emoji: "💚", category: "mental-health", participants: [] },
      { name: "Safe Harbor", description: "Protected space for vulnerable conversations - judgment-free zone", emoji: "🏠", category: "mental-health", participants: [] },
      { name: "Recovery Circle", description: "Support for addiction recovery, mental health recovery, and life rebuilding", emoji: "🔄", category: "mental-health", participants: [] },
      { name: "Anxiety & Depression Support", description: "Understanding community for anxiety, depression, and mental health struggles", emoji: "🤝", category: "mental-health", participants: [] },
      { name: "Life Advice Corner", description: "Get guidance and share wisdom with others", emoji: "💡", category: "advice", participants: [] },
      { name: "LGBTQIA+ Community", description: "Connect with fellow community members", emoji: "🏳️‍🌈", category: "community", participants: [] },
      { name: "Entrepreneurs Hub", description: "Business minds and startup enthusiasts unite!", emoji: "💼", category: "business", participants: [] },
      { name: "Bug Enthusiasts", description: "Talk about insects, beetles, butterflies and all things creepy crawly!", emoji: "🐛", category: "hobbies", participants: [] },
      { name: "Animal Lovers", description: "Share stories about pets, wildlife, and our furry friends", emoji: "🐾", category: "animals", participants: [] },
      { name: "Sky Watchers", description: "Astronomy, weather, clouds, sunsets - everything above us!", emoji: "🌌", category: "nature", participants: [] },
      { name: "Cannabis Friendly", description: "Open-minded discussions about cannabis culture and experiences", emoji: "🌿", category: "lifestyle", participants: [] },
      { name: "Music Corner", description: "Share your favorite tunes and discover new artists", emoji: "🎵", category: "entertainment", participants: [] },
      { name: "Movie Night", description: "Discuss films, series, and everything entertainment", emoji: "🎬", category: "entertainment", participants: [] },
      { name: "Gaming Zone", description: "Talk about video games, board games, and gaming culture", emoji: "🎮", category: "gaming", participants: [] },
      { name: "Foodies United", description: "Share recipes, restaurant recommendations, and food adventures", emoji: "🍕", category: "food", participants: [] },
      { name: "Travel Stories", description: "Share your adventures and dream destinations", emoji: "✈️", category: "travel", participants: [] },
      { name: "Mindful Conversations", description: "A respectful space for adults who understand that meaningful dialogue is rare and precious", emoji: "🧘", category: "mindful", participants: [] },
      { name: "Understanding Hearts", description: "For mature individuals who know the value of authentic conversation and connection", emoji: "❤️", category: "mature", participants: [] },
      { name: "Night Owls", description: "Can't sleep? Home alone? Let's chat through the night!", emoji: "🦉", category: "late-night", participants: [] },
      { name: "Cook Together Kitchen", description: "Live cooking sessions with video chat - cook together in real-time!", emoji: "👨‍🍳", category: "food", participants: [] },
      { name: "Holiday Chatter", description: "Celebrate seasons and holidays together with festive conversations", emoji: "🎄", category: "seasonal", participants: [] },
      { name: "Book Club Corner", description: "Discuss current reads, recommend books, and share literary adventures", emoji: "📚", category: "literature", participants: [] },
      { name: "Language Exchange", description: "Practice languages with native speakers and learn together", emoji: "🗣️", category: "education", participants: [] },
      { name: "College Years", description: "Current students and recent grads - navigate academic life together", emoji: "🎓", category: "education", participants: [] },
      { name: "Empty Nesters", description: "Parents whose kids have grown up - new chapter conversations", emoji: "🏠", category: "life-stages", participants: [] },
      { name: "Career Mentoring", description: "Professional guidance, career advice, and workplace discussions", emoji: "💼", category: "career", participants: [] },
      { name: "Creative Corner", description: "Artists, writers, musicians - share your creative journey", emoji: "🎨", category: "creative", participants: [] },
      { name: "Tech Talk", description: "Discuss technology, coding, gadgets, and digital life", emoji: "💻", category: "technology", participants: [] },
      { name: "Fitness & Wellness", description: "Health goals, workout tips, and wellness conversations", emoji: "💪", category: "health", participants: [] },
      { name: "Parenting Circle", description: "Parents supporting parents through all stages of child-rearing", emoji: "👶", category: "parenting", participants: [] },
      { name: "Retirement Adventures", description: "Golden years conversations - hobbies, travel, and new beginnings", emoji: "🌅", category: "life-stages", participants: [] },
      { name: "Financial Freedom", description: "Money management, investing, and financial independence discussions", emoji: "💰", category: "finance", participants: [] },
      { name: "Home & Garden", description: "Decorating, gardening, DIY projects, and making your space beautiful", emoji: "🏡", category: "lifestyle", participants: [] },
      { name: "Philosophy Lounge", description: "Deep philosophical discussions and life's big questions", emoji: "🤯", category: "philosophy", participants: [] },
      { name: "Science Enthusiasts", description: "Explore discoveries, theories, and the wonders of science", emoji: "🔬", category: "science", participants: [] }
    ];

    defaultRooms.forEach(room => {
      this.createChatRoom(room);
    });
  }

  // User operations
  async createUser(user: InsertUser): Promise<User> {
    const id = crypto.randomUUID();
    const newUser: User = {
      id,
      email: user.email || null,
      firstName: user.firstName || null,
      lastName: user.lastName || null,
      profileImageUrl: user.profileImageUrl || null,
      name: user.name || null,
      age: user.age || null,
      location: user.location || null,
      bio: user.bio || null,
      photoUrl: user.photoUrl || null,
      talkStyle: user.talkStyle || null,
      favoriteTopics: user.favoriteTopics || null,
      interests: user.interests || null,
      isOnline: user.isOnline || null,
      talkStreak: user.talkStreak || null,
      badges: user.badges || null,
      joinedAt: new Date(),
      lastActiveAt: user.lastActiveAt || null,
      preferences: user.preferences || null,
      createdAt: new Date(),
      updatedAt: new Date(),
      karmaScore: 0,
      isVerified: true,
      timezone: null,
    };
    this.users.set(id, newUser);
    return newUser;
  }

  async getUserById(id: string): Promise<User | null> {
    return this.users.get(id) || null;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | null> {
    const user = this.users.get(id);
    if (!user) return null;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getOnlineUsers(): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.isOnline);
  }

  // Chat room operations
  async createChatRoom(room: InsertChatRoom): Promise<ChatRoom> {
    const id = crypto.randomUUID();
    const newRoom: ChatRoom = {
      id,
      name: room.name,
      description: room.description,
      emoji: room.emoji,
      category: room.category,
      participants: room.participants || null,
      activeParticipants: room.activeParticipants || null,
      isActive: room.isActive !== undefined ? room.isActive : true,
      createdAt: new Date(),
      updatedAt: new Date(),
      createdBy: room.createdBy || null,
      moderators: room.moderators || null,
    };
    this.chatRooms.set(id, newRoom);
    return newRoom;
  }

  async getChatRoomById(id: string): Promise<ChatRoom | null> {
    return this.chatRooms.get(id) || null;
  }

  async getAllChatRooms(): Promise<ChatRoom[]> {
    return Array.from(this.chatRooms.values());
  }

  async getActiveChatRooms(): Promise<ChatRoom[]> {
    return Array.from(this.chatRooms.values()).filter(room => room.isActive);
  }

  async updateChatRoom(id: string, updates: Partial<InsertChatRoom>): Promise<ChatRoom | null> {
    const room = this.chatRooms.get(id);
    if (!room) return null;
    
    const updatedRoom = { ...room, ...updates };
    this.chatRooms.set(id, updatedRoom);
    return updatedRoom;
  }

  async joinChatRoom(roomId: string, userId: string): Promise<ChatRoom | null> {
    const room = this.chatRooms.get(roomId);
    if (!room) return null;

    if (!room.participants) {
      room.participants = [];
    }
    if (!room.participants.includes(userId)) {
      room.participants.push(userId);
      this.chatRooms.set(roomId, room);
    }
    return room;
  }

  async leaveChatRoom(roomId: string, userId: string): Promise<ChatRoom | null> {
    const room = this.chatRooms.get(roomId);
    if (!room) return null;

    if (room.participants) {
      room.participants = room.participants.filter(id => id !== userId);
    }
    this.chatRooms.set(roomId, room);
    return room;
  }

  // Message operations
  async createMessage(message: InsertMessage): Promise<Message> {
    const id = crypto.randomUUID();
    const newMessage: Message = {
      id,
      roomId: message.roomId,
      userId: message.userId,
      userName: message.userName,
      content: message.content,
      type: message.type || "text",
      createdAt: new Date(),
      editedAt: null,
      isDeleted: false,
      replyTo: null,
      reactions: null,
    };
    this.messages.set(id, newMessage);
    return newMessage;
  }

  async getMessagesByRoomId(roomId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.roomId === roomId)
      .sort((a, b) => (a.createdAt?.getTime() || 0) - (b.createdAt?.getTime() || 0));
  }

  // Match request operations
  async createMatchRequest(request: InsertMatchRequest): Promise<MatchRequest> {
    const id = crypto.randomUUID();
    const newRequest: MatchRequest = {
      id,
      isActive: request.isActive !== undefined ? request.isActive : true,
      userId: request.userId || null,
      userName: request.userName,
      preferredTopic: request.preferredTopic,
      matchedWith: request.matchedWith || null,
      matchedAt: request.matchedAt || null,
      createdAt: new Date(),
    };
    this.matchRequests.set(id, newRequest);
    return newRequest;
  }

  async getMatchRequests(): Promise<MatchRequest[]> {
    return Array.from(this.matchRequests.values());
  }

  async deleteMatchRequest(id: string): Promise<boolean> {
    return this.matchRequests.delete(id);
  }

  async findMatchForUser(userId: string, topic: string): Promise<MatchRequest | null> {
    const requests = Array.from(this.matchRequests.values())
      .filter(req => req.userId !== userId && req.preferredTopic === topic);
    
    return requests.length > 0 ? requests[0] : null;
  }
}

// Export storage instance - switch to DatabaseStorage for Replit Auth
import { DatabaseStorage } from "./database-storage";
export const storage = new DatabaseStorage();