import express from "express";
import { createServer } from "http";
import path from "path";

const app = express();
const PORT = process.env.PORT || 3000;

// Basic middleware
app.use(express.json());

// Health check endpoint - must return 200 for deployment
app.get('/health', (req, res) => {
  res.status(200).json({ 
    status: 'healthy',
    service: 'TalksAlot',
    timestamp: new Date().toISOString()
  });
});

// Root endpoint - must return 200 for deployment
app.get('/', (req, res) => {
  res.status(200).json({
    status: 'ok',
    message: 'TalksAlot server running',
    timestamp: new Date().toISOString()
  });
});

// Static file serving
const distPath = path.resolve(process.cwd(), "dist");
console.log(`Serving static files from: ${distPath}`);

app.use(express.static(distPath, { 
  fallthrough: true,
  setHeaders: (res, path) => {
    if (path.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  }
}));

// SPA fallback - serve index.html for non-API routes
app.get('*', (req, res) => {
  const indexPath = path.join(distPath, "index.html");
  res.sendFile(indexPath, (err) => {
    if (err) {
      console.error('Error serving index.html:', err);
      res.status(200).json({ 
        message: 'TalksAlot - Frontend not built yet',
        status: 'ok'
      });
    }
  });
});

const server = createServer(app);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`TalksAlot server running on http://0.0.0.0:${PORT}`);
  console.log(`Health check: http://0.0.0.0:${PORT}/health`);
  console.log(`Deployment ready`);
});

process.on('SIGTERM', () => {
  console.log('Graceful shutdown');
  server.close(() => process.exit(0));
});