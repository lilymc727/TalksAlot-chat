import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Health check endpoint
  app.get("/health", (req: Request, res: Response) => {
    res.status(200).json({ 
      status: "OK", 
      timestamp: new Date().toISOString(),
      message: "TalksAlot server is running with Replit Auth"
    });
  });

  // Rooms API (protected)
  app.get("/api/rooms", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const rooms = await storage.getAllChatRooms();
      res.json(rooms);
    } catch (error) {
      console.error("Error fetching rooms:", error);
      res.status(500).json({ message: "Failed to fetch rooms" });
    }
  });

  // Messages API (protected)
  app.get("/api/rooms/:roomId/messages", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { roomId } = req.params;
      const messages = await storage.getMessagesByRoomId(roomId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Create message API (protected)
  app.post("/api/messages", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const messageData = {
        ...req.body,
        userId: userId,
        userName: req.user.claims.first_name || req.user.claims.email || "Anonymous"
      };
      
      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  // Serve landing page for non-authenticated users
  app.get("/", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>TalksAlot - Welcome to Your Tribe</title>
          <style>
            body {
              font-family: 'Arial', sans-serif;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              margin: 0;
              padding: 20px;
              min-height: 100vh;
              display: flex;
              align-items: center;
              justify-content: center;
            }
            .container {
              background: white;
              padding: 40px;
              border-radius: 15px;
              box-shadow: 0 15px 35px rgba(0,0,0,0.1);
              text-align: center;
              max-width: 600px;
              width: 100%;
            }
            h1 {
              color: #333;
              margin-bottom: 20px;
              font-size: 2.5em;
            }
            p {
              color: #666;
              line-height: 1.6;
              margin-bottom: 20px;
              font-size: 1.1em;
            }
            .highlight {
              color: #667eea;
              font-weight: bold;
            }
            .login-btn {
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              color: white;
              padding: 15px 30px;
              border: none;
              border-radius: 8px;
              font-size: 1.2em;
              cursor: pointer;
              text-decoration: none;
              display: inline-block;
              margin-top: 20px;
              transition: transform 0.2s;
            }
            .login-btn:hover {
              transform: translateY(-2px);
            }
            .feature {
              background: #f8f9fa;
              padding: 20px;
              border-radius: 10px;
              margin: 20px 0;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>🗣️ Welcome to TalksAlot</h1>
            <p class="highlight">Have people said you talk a lot? You've found your tribe!</p>
            
            <div class="feature">
              <h3>🔐 Verified Community</h3>
              <p>Every member is verified through Replit authentication - no anonymous users, just real people who love meaningful conversation.</p>
            </div>

            <div class="feature">
              <h3>💬 47+ Chat Rooms</h3>
              <p>From Deep Thinkers to Healing Hearts, Gaming Zone to Philosophy Lounge - find your perfect conversation space.</p>
            </div>

            <div class="feature">
              <h3>🛡️ Safe Space Policy</h3>
              <p>Zero tolerance for negativity. Every room is actively protected from harassment - this is your safe space to be authentically you.</p>
            </div>

            <p>Join a community where talking a lot isn't a burden - it's a gift!</p>
            
            <a href="/api/login" class="login-btn">Join Your Tribe</a>
          </div>
        </body>
        </html>
      `);
    } else {
      // Serve the main chat application for authenticated users
      res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>TalksAlot - Chat Rooms</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              margin: 0;
              padding: 0;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              min-height: 100vh;
            }
            .header {
              background: rgba(255,255,255,0.95);
              padding: 20px;
              text-align: center;
              box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .container {
              max-width: 1200px;
              margin: 20px auto;
              padding: 20px;
            }
            .room-grid {
              display: grid;
              grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
              gap: 20px;
              margin-top: 20px;
            }
            .room-card {
              background: white;
              padding: 20px;
              border-radius: 10px;
              box-shadow: 0 5px 15px rgba(0,0,0,0.1);
              transition: transform 0.2s;
            }
            .room-card:hover {
              transform: translateY(-5px);
            }
            .room-title {
              font-size: 1.3em;
              margin-bottom: 10px;
              color: #333;
            }
            .room-description {
              color: #666;
              margin-bottom: 15px;
            }
            .participant-count {
              color: #667eea;
              font-weight: bold;
            }
            .logout-btn {
              background: #dc3545;
              color: white;
              padding: 10px 20px;
              border: none;
              border-radius: 5px;
              cursor: pointer;
              text-decoration: none;
              margin-left: 20px;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>🗣️ TalksAlot - Welcome Home, Talkers!</h1>
            <p>Where being chatty is celebrated, not criticized</p>
            <a href="/api/logout" class="logout-btn">Logout</a>
          </div>
          
          <div class="container">
            <div id="room-grid" class="room-grid">
              <p>Loading your conversation spaces...</p>
            </div>
          </div>

          <script>
            // Load chat rooms
            fetch('/api/rooms')
              .then(response => response.json())
              .then(rooms => {
                const grid = document.getElementById('room-grid');
                grid.innerHTML = rooms.map(room => {
                  const participantCount = Math.floor(Math.random() * 50) + 15; // Mock participant count
                  return \`
                    <div class="room-card">
                      <div class="room-title">\${room.emoji} \${room.name}</div>
                      <div class="room-description">\${room.description}</div>
                      <div class="participant-count">\${participantCount} active talkers</div>
                    </div>
                  \`;
                }).join('');
              })
              .catch(error => {
                console.error('Error loading rooms:', error);
                document.getElementById('room-grid').innerHTML = '<p>Error loading rooms. Please refresh the page.</p>';
              });
          </script>
        </body>
        </html>
      `);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}