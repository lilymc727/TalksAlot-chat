import express from "express";
import { createServer } from "http";
import path from "path";
import { createRouter } from "./routes";
import { DatabaseStorage } from "./database-storage";
import { setupAuth } from "./replitAuth";

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());

// Health check endpoint (accessible without auth for deployment)
app.get('/health', (req, res) => {
  res.status(200).json({ 
    status: 'healthy',
    service: 'TalksAlot Chat Application',
    timestamp: new Date().toISOString(),
    port: PORT,
    environment: process.env.NODE_ENV || 'development'
  });
});

// Root endpoint for deployment verification
app.get('/', (req, res) => {
  res.status(200).json({
    status: 'ok',
    message: 'TalksAlot server is running',
    timestamp: new Date().toISOString(),
    deployment: 'ready'
  });
});

async function startServer() {
  try {
    console.log('Starting TalksAlot production server...');
    
    // Initialize storage
    const storage = new DatabaseStorage();
    console.log('Database storage initialized');
    
    // Setup authentication
    await setupAuth(app);
    console.log('Authentication setup complete');
    
    // Add API routes
    const router = createRouter(storage);
    app.use('/', router);
    console.log('API routes configured');
    
    // Serve static files for production
    const distPath = path.resolve(process.cwd(), "dist");
    app.use(express.static(distPath));
    
    // Catch-all handler for SPA routing
    app.get("*", (req, res) => {
      if (!req.path.startsWith('/api') && !req.path.startsWith('/health') && !req.path.startsWith('/auth')) {
        res.sendFile(path.join(distPath, "index.html"));
      } else {
        res.status(404).json({ error: "Endpoint not found" });
      }
    });
    
    // Create HTTP server
    const server = createServer(app);
    
    // Start server
    server.listen(PORT, '0.0.0.0', () => {
      console.log(`🚀 TalksAlot server running on http://0.0.0.0:${PORT}`);
      console.log(`📊 Health check: http://0.0.0.0:${PORT}/health`);
      console.log(`🔒 Authentication enabled with Replit Auth`);
      console.log(`📁 Serving static files from: ${distPath}`);
      console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`✅ Deployment ready - server bound to 0.0.0.0:${PORT}`);
    });
    
    // Graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    });
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();