import express from "express";
import { WebSocketServer, WebSocket } from "ws";
import { createRouter } from "./routes";
import { MemStorage } from "./storage";
import { createServer as createViteServer } from "vite";
import { createServer } from "http";
import { setupAuth } from "./replitAuth";
import path from "path";


async function setupVite(app: any, server: any) {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  });

  app.use(vite.ssrFixStacktrace);
  app.use(vite.middlewares);
}

function serveStatic(app: any) {
  const distPath = path.resolve(process.cwd(), "dist");
  app.use(express.static(distPath));
  app.get("*", (req: any, res: any) => {
    if (!req.path.startsWith('/api') && !req.path.startsWith('/ws')) {
      res.sendFile(path.join(distPath, "index.html"));
    }
  });
}

function log(...args: any[]) {
  console.log(...args);
}

const app = express();
app.use(express.json());

// Create storage instance
const storage = new MemStorage();

interface WebSocketWithUserId extends WebSocket {
  userId?: string;
  roomId?: string;
}

// Initialize server and WebSocket after auth setup
async function initializeServer() {
  // Setup auth first
  await setupAuth(app);
  
  // Add routes with authentication
  const router = createRouter(storage);
  app.use('/', router);
  
  const server = createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws: WebSocketWithUserId, req) => {
    log('Secure WebSocket connection established');

  ws.on('message', async (data) => {
    try {
      const message = JSON.parse(data.toString());
      
      switch (message.type) {
        case 'join-room':
          ws.userId = message.userId;
          ws.roomId = message.roomId;
          
          // Join the room in storage
          await storage.joinChatRoom(message.roomId, message.userId);
          
          // Notify others in the room
          wss.clients.forEach((client: WebSocketWithUserId) => {
            if (client !== ws && 
                client.roomId === message.roomId && 
                client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'user-joined',
                userId: message.userId,
                roomId: message.roomId
              }));
            }
          });
          break;

        case 'send-message':
          // Save message to storage
          const savedMessage = await storage.createMessage({
            roomId: message.roomId,
            userId: message.userId,
            userName: message.userName,
            content: message.content
          });

          // Broadcast to all clients in the same room
          wss.clients.forEach((client: WebSocketWithUserId) => {
            if (client.roomId === message.roomId && 
                client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'new-message',
                message: savedMessage
              }));
            }
          });
          break;

        case 'leave-room':
          if (ws.roomId && ws.userId) {
            await storage.leaveChatRoom(ws.roomId, ws.userId);
            
            // Notify others
            wss.clients.forEach((client: WebSocketWithUserId) => {
              if (client !== ws && 
                  client.roomId === ws.roomId && 
                  client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                  type: 'user-left',
                  userId: ws.userId,
                  roomId: ws.roomId
                }));
              }
            });
          }
          ws.roomId = undefined;
          ws.userId = undefined;
          break;
      }
    } catch (error) {
      log('WebSocket message error:', error);
    }
  });

  ws.on('close', async () => {
    if (ws.roomId && ws.userId) {
      await storage.leaveChatRoom(ws.roomId, ws.userId);
      await storage.updateUser(ws.userId, { isOnline: false });
    }
  });
});

// Setup Vite or static serving
if (process.env.NODE_ENV === "production") {
  serveStatic(app);
} else {
  setupVite(app, server);
}





  const port = Number(process.env.PORT) || 3000;
  const host = "0.0.0.0";
  
  server.listen(port, host, () => {
    log(`TalksAlot server is running on http://${host}:${port}`);
    log(`Ready to serve chat application with verified users only`);
    log(`Secure WebSocket server available at wss://${host}:${port}/ws`);
    log(`Health check available at http://${host}:${port}/health`);
    log(`Deployment ready - server bound to ${host}:${port}`);
  });
}

// Start the server
initializeServer().catch(console.error);