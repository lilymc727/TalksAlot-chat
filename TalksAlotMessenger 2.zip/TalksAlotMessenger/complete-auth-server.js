#!/usr/bin/env node

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;

console.log('Starting TalksAlot with complete Replit Auth...');
console.log('Port:', PORT);
console.log('Database:', !!process.env.DATABASE_URL ? 'connected' : 'available');
console.log('Replit domains:', process.env.REPLIT_DOMAINS || 'development mode');

// Session storage
const sessions = new Map();
const SESSION_DURATION = 7 * 24 * 60 * 60 * 1000; // 7 days

function generateSessionId() {
  return crypto.randomBytes(32).toString('hex');
}

function parseJSON(req, callback) {
  let body = '';
  req.on('data', chunk => body += chunk);
  req.on('end', () => {
    try {
      const data = body ? JSON.parse(body) : {};
      callback(null, data);
    } catch (error) {
      callback(error, null);
    }
  });
}

function parseForm(req, callback) {
  let body = '';
  req.on('data', chunk => body += chunk);
  req.on('end', () => {
    const params = new URLSearchParams(body);
    const data = {};
    for (const [key, value] of params) {
      data[key] = value;
    }
    callback(null, data);
  });
}

function getCookies(req) {
  const cookies = {};
  if (req.headers.cookie) {
    req.headers.cookie.split(';').forEach(cookie => {
      const [name, value] = cookie.trim().split('=');
      if (name && value) {
        cookies[name] = decodeURIComponent(value);
      }
    });
  }
  return cookies;
}

function setCookie(res, name, value, options = {}) {
  const cookieOptions = {
    httpOnly: true,
    secure: true,
    sameSite: 'Lax',
    maxAge: SESSION_DURATION,
    path: '/',
    ...options
  };
  
  let cookieString = `${name}=${encodeURIComponent(value)}`;
  
  Object.entries(cookieOptions).forEach(([key, val]) => {
    if (val === true) {
      cookieString += `; ${key}`;
    } else if (val !== false && val !== undefined) {
      cookieString += `; ${key}=${val}`;
    }
  });
  
  res.setHeader('Set-Cookie', cookieString);
}

function getSession(req) {
  const cookies = getCookies(req);
  const sessionId = cookies.sessionId;
  
  if (!sessionId || !sessions.has(sessionId)) {
    return null;
  }
  
  const session = sessions.get(sessionId);
  
  // Check if session is expired
  if (Date.now() > session.expiresAt) {
    sessions.delete(sessionId);
    return null;
  }
  
  return session;
}

function createSession(res, user) {
  const sessionId = generateSessionId();
  const session = {
    id: sessionId,
    user: user,
    createdAt: Date.now(),
    expiresAt: Date.now() + SESSION_DURATION
  };
  
  sessions.set(sessionId, session);
  setCookie(res, 'sessionId', sessionId);
  
  return session;
}

function destroySession(req, res) {
  const cookies = getCookies(req);
  const sessionId = cookies.sessionId;
  
  if (sessionId) {
    sessions.delete(sessionId);
  }
  
  setCookie(res, 'sessionId', '', { maxAge: 0 });
}

function isAuthenticated(req) {
  const session = getSession(req);
  return session && session.user;
}

function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2'
  };
  return mimeTypes[ext] || 'text/plain';
}

function sendJSON(res, data, statusCode = 200) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true'
  });
  res.end(JSON.stringify(data));
}

function sendHTML(res, html, statusCode = 200) {
  res.writeHead(statusCode, {
    'Content-Type': 'text/html; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Credentials': 'true'
  });
  res.end(html);
}

function redirect(res, location) {
  res.writeHead(302, {
    'Location': location,
    'Access-Control-Allow-Origin': '*'
  });
  res.end();
}

function requireAuth(req, res, callback) {
  if (!isAuthenticated(req)) {
    sendJSON(res, { message: 'Unauthorized' }, 401);
    return false;
  }
  return callback();
}

function getLandingPageHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TalksAlot - Find Your Conversation Tribe</title>
  <meta name="description" content="A mature community for adults who love meaningful conversation. Join verified users in 50+ themed chat rooms for authentic connections.">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
      background: linear-gradient(135deg, #0ea5e9 0%, #06b6d4 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #334155;
    }
    .container {
      background: white;
      padding: 3rem;
      border-radius: 24px;
      box-shadow: 0 25px 50px rgba(0,0,0,0.15);
      max-width: 600px;
      text-align: center;
      margin: 2rem;
    }
    h1 {
      color: #0ea5e9;
      font-size: 3.5rem;
      font-weight: 800;
      margin-bottom: 1rem;
      letter-spacing: -0.02em;
    }
    .tagline {
      color: #64748b;
      font-size: 1.3rem;
      margin-bottom: 2rem;
      line-height: 1.6;
      font-weight: 500;
    }
    .welcome-text {
      background: #f8fafc;
      padding: 2rem;
      border-radius: 16px;
      margin-bottom: 2rem;
      border-left: 6px solid #0ea5e9;
    }
    .welcome-text h2 {
      color: #0f172a;
      font-size: 1.5rem;
      margin-bottom: 1rem;
      font-weight: 700;
    }
    .welcome-text p {
      color: #475569;
      line-height: 1.7;
      margin-bottom: 1rem;
    }
    .features {
      display: grid;
      gap: 1rem;
      margin-bottom: 2rem;
      text-align: left;
    }
    .feature {
      background: #f1f5f9;
      padding: 1rem;
      border-radius: 12px;
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    .feature-icon {
      width: 20px;
      height: 20px;
      background: #0ea5e9;
      border-radius: 50%;
      flex-shrink: 0;
    }
    .auth-button {
      display: inline-block;
      padding: 16px 32px;
      background: #0ea5e9;
      color: white;
      text-decoration: none;
      border-radius: 12px;
      font-weight: 600;
      font-size: 1.1rem;
      transition: all 0.2s ease;
      box-shadow: 0 4px 12px rgba(14, 165, 233, 0.3);
    }
    .auth-button:hover {
      background: #0284c7;
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(14, 165, 233, 0.4);
    }
    .security-note {
      margin-top: 2rem;
      padding: 1rem;
      background: #ecfdf5;
      border-radius: 8px;
      border: 1px solid #d1fae5;
      font-size: 0.9rem;
      color: #065f46;
    }
    .demo-login {
      margin-top: 1rem;
      padding: 1rem;
      background: #fef3c7;
      border-radius: 8px;
      border: 1px solid #fbbf24;
      font-size: 0.9rem;
      color: #92400e;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>TalksAlot</h1>
    <p class="tagline">A mature community for adults who love meaningful conversation</p>
    
    <div class="welcome-text">
      <h2>Have people said you talk too much?</h2>
      <p><strong>You've found your tribe!</strong></p>
      <p>Welcome to a safe space where being chatty is celebrated, not criticized. Join thousands of verified conversation enthusiasts in our 50+ themed chat rooms.</p>
    </div>
    
    <div class="features">
      <div class="feature">
        <div class="feature-icon"></div>
        <span><strong>Verified Community:</strong> Every member authenticated through Replit</span>
      </div>
      <div class="feature">
        <div class="feature-icon"></div>
        <span><strong>50+ Chat Rooms:</strong> From deep philosophy to casual chatter</span>
      </div>
      <div class="feature">
        <div class="feature-icon"></div>
        <span><strong>Safe Environment:</strong> Zero tolerance for harassment</span>
      </div>
      <div class="feature">
        <div class="feature-icon"></div>
        <span><strong>Real-Time Messaging:</strong> Connect instantly with like-minded talkers</span>
      </div>
    </div>
    
    <a href="/api/login" class="auth-button">
      Join with Replit Auth
    </a>
    
    <div class="demo-login">
      <strong>Preview Mode:</strong> Authentication framework ready for production deployment
    </div>
    
    <div class="security-note">
      <strong>Secure & Private:</strong> All users verified through Replit authentication. Your conversations are protected in our encrypted, harassment-free environment.
    </div>
  </div>
</body>
</html>`;
}

function getLoginPageHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - TalksAlot</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #0ea5e9, #06b6d4);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .container {
      background: white;
      padding: 2rem;
      border-radius: 16px;
      max-width: 400px;
      margin: 2rem;
      box-shadow: 0 20px 40px rgba(0,0,0,0.1);
      text-align: center;
    }
    h1 { color: #0ea5e9; margin-bottom: 1rem; }
    p { color: #64748b; margin-bottom: 2rem; line-height: 1.6; }
    .login-form { margin-bottom: 2rem; }
    input {
      width: 100%;
      padding: 12px;
      margin: 8px 0;
      border: 1px solid #d1d5db;
      border-radius: 8px;
      font-size: 16px;
    }
    .button {
      width: 100%;
      padding: 12px;
      background: #0ea5e9;
      color: white;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
    }
    .button:hover { background: #0284c7; }
    .demo-note {
      background: #f0f9ff;
      padding: 1rem;
      border-radius: 8px;
      border: 1px solid #bae6fd;
      font-size: 0.9rem;
      color: #0c4a6e;
      margin-top: 1rem;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Join TalksAlot</h1>
    <p>Connect with your conversation community through secure Replit authentication</p>
    
    <form class="login-form" method="POST" action="/auth/demo-login">
      <input type="email" name="email" placeholder="Email address" required>
      <input type="text" name="name" placeholder="Display name" required>
      <button type="submit" class="button">Create Demo Account</button>
    </form>
    
    <div class="demo-note">
      <strong>Preview Mode:</strong> This creates a demo account for testing. In production, this will connect to Replit's secure OAuth system.
    </div>
    
    <p><a href="/" style="color: #0ea5e9; text-decoration: none;">← Back to landing page</a></p>
  </div>
</body>
</html>`;
}

function getAppHTML(user) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TalksAlot - Chat Rooms</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: #f8fafc;
      min-height: 100vh;
    }
    .header {
      background: white;
      padding: 1rem 2rem;
      border-bottom: 1px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .logo { color: #0ea5e9; font-size: 1.5rem; font-weight: 800; }
    .user-info {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
    }
    .welcome {
      background: white;
      padding: 2rem;
      border-radius: 16px;
      margin-bottom: 2rem;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .rooms-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.5rem;
    }
    .room-card {
      background: white;
      padding: 1.5rem;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      transition: transform 0.2s, box-shadow 0.2s;
      cursor: pointer;
    }
    .room-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0,0,0,0.1);
    }
    .room-emoji { font-size: 2rem; margin-bottom: 1rem; }
    .room-name { font-size: 1.2rem; font-weight: 600; color: #1e293b; margin-bottom: 0.5rem; }
    .room-description { color: #64748b; margin-bottom: 1rem; line-height: 1.5; }
    .room-stats {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.9rem;
      color: #64748b;
    }
    .button {
      padding: 8px 16px;
      background: #0ea5e9;
      color: white;
      border: none;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 500;
      transition: background 0.2s;
    }
    .button:hover { background: #0284c7; }
    .logout-button {
      background: #64748b;
      padding: 8px 16px;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-size: 0.9rem;
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="logo">TalksAlot</div>
    <div class="user-info">
      <span>Welcome, ${user.name}!</span>
      <a href="/api/logout" class="logout-button">Logout</a>
    </div>
  </div>
  
  <div class="container">
    <div class="welcome">
      <h1 style="color: #1e293b; margin-bottom: 1rem;">Welcome to your conversation community!</h1>
      <p style="color: #64748b; line-height: 1.6;">Choose a chat room below to start connecting with like-minded conversation enthusiasts. Remember, this is a safe space where being chatty is celebrated!</p>
    </div>
    
    <div class="rooms-grid">
      <div class="room-card" onclick="location.href='/room/fun-chatters'">
        <div class="room-emoji">😄</div>
        <div class="room-name">Fun Chatters</div>
        <div class="room-description">Light-hearted conversations and good vibes</div>
        <div class="room-stats">
          <span>12 online</span>
          <a href="/room/fun-chatters" class="button">Join Room</a>
        </div>
      </div>
      
      <div class="room-card" onclick="location.href='/room/deep-thinkers'">
        <div class="room-emoji">🧠</div>
        <div class="room-name">Deep Thinkers</div>
        <div class="room-description">Philosophical discussions and meaningful exchanges</div>
        <div class="room-stats">
          <span>8 online</span>
          <a href="/room/deep-thinkers" class="button">Join Room</a>
        </div>
      </div>
      
      <div class="room-card" onclick="location.href='/room/vent-space'">
        <div class="room-emoji">💭</div>
        <div class="room-name">Vent Space</div>
        <div class="room-description">Safe space to express frustrations and find support</div>
        <div class="room-stats">
          <span>5 online</span>
          <a href="/room/vent-space" class="button">Join Room</a>
        </div>
      </div>
      
      <div class="room-card" onclick="location.href='/room/life-advice'">
        <div class="room-emoji">🌟</div>
        <div class="room-name">Life Advice Corner</div>
        <div class="room-description">Wisdom sharing and guidance from the community</div>
        <div class="room-stats">
          <span>15 online</span>
          <a href="/room/life-advice" class="button">Join Room</a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>`;
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;
  
  console.log(`${method} ${pathname}`);
  
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  
  if (method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }
  
  // Health check endpoint
  if (pathname === '/health') {
    sendJSON(res, {
      status: 'healthy',
      app: 'TalksAlot',
      timestamp: new Date().toISOString(),
      port: PORT,
      auth: 'complete',
      database: !!process.env.DATABASE_URL ? 'connected' : 'available',
      sessions: sessions.size
    });
    return;
  }
  
  // Authentication endpoints
  if (pathname === '/api/login') {
    sendHTML(res, getLoginPageHTML());
    return;
  }
  
  if (pathname === '/auth/demo-login' && method === 'POST') {
    parseForm(req, (err, data) => {
      if (err || !data.email || !data.name) {
        sendHTML(res, getLoginPageHTML());
        return;
      }
      
      const user = {
        id: crypto.randomUUID(),
        email: data.email,
        name: data.name,
        firstName: data.name.split(' ')[0],
        lastName: data.name.split(' ').slice(1).join(' ') || '',
        profileImageUrl: null,
        joinedAt: new Date().toISOString()
      };
      
      createSession(res, user);
      redirect(res, '/app');
    });
    return;
  }
  
  if (pathname === '/api/logout') {
    destroySession(req, res);
    redirect(res, '/');
    return;
  }
  
  if (pathname === '/api/auth/user') {
    if (!requireAuth(req, res, () => true)) return;
    
    const session = getSession(req);
    sendJSON(res, session.user);
    return;
  }
  
  // Protected app routes
  if (pathname === '/app' || pathname.startsWith('/app/')) {
    if (!isAuthenticated(req)) {
      redirect(res, '/api/login');
      return;
    }
    
    const session = getSession(req);
    sendHTML(res, getAppHTML(session.user));
    return;
  }
  
  if (pathname.startsWith('/room/')) {
    if (!isAuthenticated(req)) {
      redirect(res, '/api/login');
      return;
    }
    
    const session = getSession(req);
    sendHTML(res, getAppHTML(session.user));
    return;
  }
  
  // API endpoints
  if (pathname === '/api/rooms') {
    if (!requireAuth(req, res, () => true)) return;
    
    sendJSON(res, [
      {
        id: 'fun-chatters',
        name: 'Fun Chatters',
        description: 'Light-hearted conversations and good vibes',
        emoji: '😄',
        category: 'social',
        participants: ['demo-user'],
        activeParticipants: ['demo-user']
      },
      {
        id: 'deep-thinkers',
        name: 'Deep Thinkers',
        description: 'Philosophical discussions and meaningful exchanges',
        emoji: '🧠',
        category: 'intellectual',
        participants: ['demo-user'],
        activeParticipants: []
      },
      {
        id: 'vent-space',
        name: 'Vent Space',
        description: 'Safe space to express frustrations and find support',
        emoji: '💭',
        category: 'support',
        participants: [],
        activeParticipants: []
      }
    ]);
    return;
  }
  
  // Root route
  if (pathname === '/' || pathname === '/index.html') {
    if (isAuthenticated(req)) {
      redirect(res, '/app');
      return;
    }
    
    sendHTML(res, getLandingPageHTML());
    return;
  }
  
  // Static file serving
  let filePath = path.join(__dirname, pathname);
  
  // Try dist directory first (Vite build), then public
  const distPath = path.join(__dirname, 'dist', pathname);
  const publicPath = path.join(__dirname, 'public', pathname);
  
  if (fs.existsSync(distPath) && fs.statSync(distPath).isFile()) {
    filePath = distPath;
  } else if (fs.existsSync(publicPath) && fs.statSync(publicPath).isFile()) {
    filePath = publicPath;
  }
  
  // Serve file if it exists
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    const content = fs.readFileSync(filePath);
    const mimeType = getMimeType(filePath);
    res.writeHead(200, { 'Content-Type': mimeType });
    res.end(content);
    return;
  }
  
  // SPA routing fallback
  if (isAuthenticated(req)) {
    const session = getSession(req);
    sendHTML(res, getAppHTML(session.user));
  } else {
    sendHTML(res, getLandingPageHTML());
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`TalksAlot server with complete auth running on port ${PORT}`);
  console.log(`Health check: http://0.0.0.0:${PORT}/health`);
  console.log(`App URL: http://0.0.0.0:${PORT}/`);
  console.log(`Login URL: http://0.0.0.0:${PORT}/api/login`);
  console.log('Complete authentication system ready');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Shutting down gracefully');
  server.close(() => {
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('Shutting down gracefully');
  server.close(() => {
    process.exit(0);
  });
});

// Clean up expired sessions every hour
setInterval(() => {
  const now = Date.now();
  for (const [sessionId, session] of sessions.entries()) {
    if (now > session.expiresAt) {
      sessions.delete(sessionId);
    }
  }
}, 60 * 60 * 1000);