const http = require('http');
const fs = require('fs');
const PORT = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    
    if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
<!DOCTYPE html>
<html>
<head>
    <title>TalksAlot - Find Your Tribe</title>
    <style>
        body { font-family: system-ui; background: linear-gradient(135deg, #0f766e, #06b6d4); margin: 0; padding: 20px; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .container { max-width: 800px; background: white; border-radius: 20px; padding: 40px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); text-align: center; }
        h1 { color: #0f766e; margin-bottom: 20px; font-size: 2.5rem; }
        .tagline { color: #374151; font-size: 1.3rem; margin-bottom: 30px; font-weight: 600; }
        .description { color: #6b7280; margin-bottom: 30px; line-height: 1.6; }
        .chat-btn { display: inline-block; margin: 20px; padding: 15px 30px; background: #0f766e; color: white; text-decoration: none; border-radius: 25px; font-weight: 600; transition: all 0.3s ease; border: none; cursor: pointer; font-size: 1rem; }
        .chat-btn:hover { background: #065f46; transform: translateY(-2px); }
        .features { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0; }
        .feature { background: #f0f9ff; padding: 20px; border-radius: 15px; text-align: center; }
        .feature-icon { font-size: 2rem; margin-bottom: 10px; }
        .feature-title { color: #0f766e; font-weight: 600; margin-bottom: 5px; }
        .feature-desc { color: #6b7280; font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🗣️ TalksAlot</h1>
        <div class="tagline">Have people said you talk a lot? You've found your tribe!</div>
        <div class="description">
            Welcome to TalksAlot - where talking too much is celebrated, not criticized! 
            Join 40+ specialized chat rooms designed for conversation enthusiasts who love meaningful dialogue.
        </div>
        
        <div class="features">
            <div class="feature">
                <div class="feature-icon">🛡️</div>
                <div class="feature-title">100% Verified</div>
                <div class="feature-desc">Every member authenticated - no anonymous trolls</div>
            </div>
            <div class="feature">
                <div class="feature-icon">💬</div>
                <div class="feature-title">40+ Rooms</div>
                <div class="feature-desc">Specialized spaces for every conversation style</div>
            </div>
            <div class="feature">
                <div class="feature-icon">🌟</div>
                <div class="feature-title">Safe Spaces</div>
                <div class="feature-desc">Healing rooms with extra protection and support</div>
            </div>
            <div class="feature">
                <div class="feature-icon">⚡</div>
                <div class="feature-title">Real-Time</div>
                <div class="feature-desc">Instant messaging with fellow conversation lovers</div>
            </div>
        </div>
        
        <button class="chat-btn" onclick="location.href='/app'">Enter TalksAlot Community</button>
    </div>
</body>
</html>
        `);
    } else if (req.url === '/app') {
        const filePath = __dirname + '/chat.html';
        console.log('Trying to serve:', filePath);

        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading chat.html:', err);
                res.writeHead(500, { 'Content-Type': 'text/plain' });
                res.end('Internal Server Error: Could not load chat.html');
            } else {
                res.writeHead(200, { 'Content-Type': 'text/html' });
                res.end(data);
            }
        });
    } else if (req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'healthy', timestamp: new Date().toISOString() }));
    } else {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>Page Not Found</h1><p><a href="/">Return to TalksAlot Home</a></p>');
    }
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`TalksAlot server running on http://0.0.0.0:${PORT}`);
});

process.on('SIGTERM', () => {
    server.close(() => process.exit(0));
});