const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';

const talksalotPage = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TalksAlot - Where Talkers Find Their Tribe</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #0891b2 0%, #06b6d4 50%, #22d3ee 100%);
            min-height: 100vh;
            color: white;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 60px;
        }
        .header h1 {
            font-size: 4rem;
            margin-bottom: 1rem;
            font-weight: 700;
        }
        .tagline {
            font-size: 1.5rem;
            opacity: 0.9;
            margin-bottom: 2rem;
        }
        .welcome {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 2rem;
            margin: 0 0 40px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 40px 0;
        }
        .stat {
            background: rgba(255, 255, 255, 0.1);
            padding: 2rem;
            border-radius: 15px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .stat-number {
            font-size: 3rem;
            font-weight: bold;
            display: block;
            margin-bottom: 0.5rem;
        }
        .rooms {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 40px;
        }
        .room {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            padding: 1.5rem;
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s;
            cursor: pointer;
        }
        .room:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.15);
        }
        .room-emoji {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            display: block;
        }
        .room-name {
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .room-desc {
            opacity: 0.8;
            line-height: 1.4;
        }
        .status {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(34, 197, 94, 0.9);
            padding: 1rem 1.5rem;
            border-radius: 25px;
            font-weight: bold;
            z-index: 1000;
        }
        @media (max-width: 768px) {
            .header h1 {
                font-size: 2.5rem;
            }
            .rooms {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="status">🟢 TalksAlot Server Online</div>
    
    <div class="container">
        <div class="header">
            <h1>🗣️ TalksAlot</h1>
            <p class="tagline">Where Talkers Find Their Tribe</p>
        </div>
        
        <div class="welcome">
            <h2 style="text-align: center; margin-bottom: 1rem;">Have people said you talk a lot? You've found your tribe!</h2>
            <p style="text-align: center; font-size: 1.1rem; line-height: 1.6;">
                TalksAlot is a mature community for adults (19+) who love meaningful conversation and understand 
                that not everyone appreciates the gift of deep dialogue. This is your safe space where being 
                chatty is celebrated, not criticized. Welcome home, talkers!
            </p>
        </div>

        <div class="stats">
            <div class="stat">
                <span class="stat-number">50</span>
                <span>Chat Rooms</span>
            </div>
            <div class="stat">
                <span class="stat-number">24/7</span>
                <span>Active Community</span>
            </div>
            <div class="stat">
                <span class="stat-number">19+</span>
                <span>Mature Adults</span>
            </div>
            <div class="stat">
                <span class="stat-number">Safe</span>
                <span>Zero Tolerance</span>
            </div>
        </div>

        <h2 style="text-align: center; font-size: 2.5rem; margin-bottom: 2rem;">Featured Chat Rooms</h2>
        <div class="rooms">
            <div class="room">
                <span class="room-emoji">😄</span>
                <div class="room-name">Fun Chatters</div>
                <div class="room-desc">Share jokes, memes, and have a laugh together! Light-hearted conversations and good vibes.</div>
            </div>
            <div class="room">
                <span class="room-emoji">🤔</span>
                <div class="room-name">Deep Thinkers</div>
                <div class="room-desc">Mature philosophical discussions about life, meaning, and the big questions that matter.</div>
            </div>
            <div class="room">
                <span class="room-emoji">💭</span>
                <div class="room-name">Vent Space</div>
                <div class="room-desc">Safe space for venting frustrations and getting support from understanding listeners.</div>
            </div>
            <div class="room">
                <span class="room-emoji">🧠</span>
                <div class="room-name">Mental Health Support</div>
                <div class="room-desc">Community support for anxiety, depression, and mental wellness journeys.</div>
            </div>
            <div class="room">
                <span class="room-emoji">🏳️‍🌈</span>
                <div class="room-name">LGBTQIA+ Community</div>
                <div class="room-desc">Inclusive space for LGBTQIA+ individuals to connect and find acceptance.</div>
            </div>
            <div class="room">
                <span class="room-emoji">🌿</span>
                <div class="room-name">Cannabis Friendly</div>
                <div class="room-desc">Cannabis culture discussions in a judgment-free environment.</div>
            </div>
            <div class="room">
                <span class="room-emoji">⏰</span>
                <div class="room-name">RambleRealm</div>
                <div class="room-desc">20-minute timed speaking sessions for uninterrupted expression and storytelling.</div>
            </div>
            <div class="room">
                <span class="room-emoji">🙏</span>
                <div class="room-name">Sacred Space</div>
                <div class="room-desc">Spiritual discussions, universal laws, and meaningful faith conversations.</div>
            </div>
        </div>

        <div style="text-align: center; margin-top: 60px; padding: 40px; background: rgba(0,0,0,0.2); border-radius: 20px;">
            <h3 style="margin-bottom: 20px; font-size: 2rem;">Ready to Join the Conversation?</h3>
            <p style="font-size: 1.2rem; opacity: 0.9;">You've found your people. Welcome to a community where talking is truly appreciated.</p>
        </div>
    </div>
</body>
</html>`;

const server = http.createServer((req, res) => {
    const url = req.url;
    const method = req.method;
    
    console.log(`${method} ${url} - ${new Date().toLocaleTimeString()}`);
    
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    // Handle preflight requests
    if (method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }
    
    // Health check endpoint
    if (url === '/health') {
        const healthData = {
            status: 'healthy',
            app: 'TalksAlot',
            version: '1.0.0',
            timestamp: new Date().toISOString(),
            port: PORT,
            uptime: process.uptime(),
            rooms: 50,
            environment: 'production'
        };
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(healthData, null, 2));
        return;
    }
    
    // API endpoint for rooms
    if (url === '/api/rooms') {
        const rooms = [
            { id: '1', name: 'Fun Chatters', emoji: '😄', participants: 12, active: true },
            { id: '2', name: 'Deep Thinkers', emoji: '🤔', participants: 8, active: true },
            { id: '3', name: 'Vent Space', emoji: '💭', participants: 15, active: true },
            { id: '4', name: 'Mental Health Support', emoji: '🧠', participants: 22, active: true },
            { id: '5', name: 'LGBTQIA+ Community', emoji: '🏳️‍🌈', participants: 18, active: true },
            { id: '6', name: 'Cannabis Friendly', emoji: '🌿', participants: 14, active: true },
            { id: '7', name: 'RambleRealm', emoji: '⏰', participants: 9, active: true },
            { id: '8', name: 'Sacred Space', emoji: '🙏', participants: 11, active: true }
        ];
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ rooms, total: 50 }));
        return;
    }
    
    // Serve homepage for all other requests
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(talksalotPage);
});

// Error handling
server.on('error', (err) => {
    console.error('Server error:', err);
});

// Start the server
server.listen(PORT, HOST, () => {
    console.log(`TalksAlot server started successfully`);
    console.log(`Listening on http://${HOST}:${PORT}`);
    console.log(`Health check: http://${HOST}:${PORT}/health`);
    console.log(`API: http://${HOST}:${PORT}/api/rooms`);
    console.log(`Preview ready - server responding to all requests`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('Received SIGINT, shutting down gracefully');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});

// Keep process alive with heartbeat
setInterval(() => {
    console.log(`Server heartbeat: ${new Date().toLocaleTimeString()} - Active on port ${PORT}`);
}, 60000);