const http = require('http');
const fs = require('fs');

const PORT = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
    // Add CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
<!DOCTYPE html>
<html>
<head>
    <title>TalksAlot - Find Your Tribe</title>
    <style>
        body { 
            font-family: system-ui; 
            background: linear-gradient(135deg, #0f766e, #06b6d4); 
            margin: 0; 
            padding: 20px; 
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container { 
            max-width: 800px; 
            background: white; 
            border-radius: 20px; 
            padding: 40px; 
            box-shadow: 0 20px 40px rgba(0,0,0,0.1); 
            text-align: center;
        }
        h1 { color: #0f766e; margin-bottom: 20px; font-size: 2.5rem; }
        .tagline { color: #374151; font-size: 1.3rem; margin-bottom: 30px; font-weight: 600; }
        .description { color: #6b7280; margin-bottom: 30px; line-height: 1.6; }
        .demo-btn { 
            display: inline-block; 
            margin: 20px; 
            padding: 15px 30px; 
            background: #0f766e; 
            color: white; 
            text-decoration: none; 
            border-radius: 25px; 
            font-weight: 600; 
            transition: all 0.3s ease;
        }
        .demo-btn:hover { background: #065f46; transform: translateY(-2px); }
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .feature {
            background: #f0f9ff;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
        }
        .feature-icon { font-size: 2rem; margin-bottom: 10px; }
        .feature-title { color: #0f766e; font-weight: 600; margin-bottom: 5px; }
        .feature-desc { color: #6b7280; font-size: 0.9rem; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🗣️ TalksAlot</h1>
        <div class="tagline">Have people said you talk a lot? You've found your tribe!</div>
        <div class="description">
            Welcome to TalksAlot - where talking too much is celebrated, not criticized! 
            Join 40+ specialized chat rooms designed for conversation enthusiasts who love meaningful dialogue.
        </div>
        
        <div class="features">
            <div class="feature">
                <div class="feature-icon">🛡️</div>
                <div class="feature-title">100% Verified</div>
                <div class="feature-desc">Every member authenticated - no anonymous trolls</div>
            </div>
            <div class="feature">
                <div class="feature-icon">💬</div>
                <div class="feature-title">40+ Rooms</div>
                <div class="feature-desc">Specialized spaces for every conversation style</div>
            </div>
            <div class="feature">
                <div class="feature-icon">🌟</div>
                <div class="feature-title">Safe Spaces</div>
                <div class="feature-desc">Healing rooms with extra protection and support</div>
            </div>
            <div class="feature">
                <div class="feature-icon">⚡</div>
                <div class="feature-title">Real-Time</div>
                <div class="feature-desc">Instant messaging with fellow conversation lovers</div>
            </div>
        </div>
        
        <a href="/chat" class="demo-btn">Enter TalksAlot Community</a>
        <a href="/about" class="demo-btn" style="background: #6b7280;">Learn More</a>
    </div>
</body>
</html>
        `);
    } else if (req.url === '/chat') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        try {
            const chatHTML = fs.readFileSync('./chat.html', 'utf8');
            res.end(chatHTML);
        } catch (error) {
            res.writeHead(500, { 'Content-Type': 'text/html' });
            res.end('<h1>Loading Chat...</h1><p>The chat interface is starting up. Please refresh in a moment.</p>');
        }
    } else if (req.url === '/about') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
<!DOCTYPE html>
<html>
<head>
    <title>About TalksAlot</title>
    <style>
        body { font-family: system-ui; background: #f0f9ff; margin: 0; padding: 20px; line-height: 1.6; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 40px; border-radius: 20px; }
        h1 { color: #0f766e; text-align: center; }
        .back-btn { background: #0f766e; color: white; padding: 10px 20px; text-decoration: none; border-radius: 25px; display: inline-block; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <a href="/" class="back-btn">← Back to Home</a>
        <h1>About TalksAlot</h1>
        <p><strong>TalksAlot transforms what society sees as "talking too much" into a celebrated gift of connection.</strong></p>
        
        <p>This mature chat application is designed for adults (19+) who love meaningful conversation and understand that not everyone appreciates lengthy dialogue. This is a thoughtful community for mature, like-minded individuals who recognize that loving to talk deeply is a gift and seek others who value authentic communication.</p>
        
        <h3>Our Mission</h3>
        <p>We believe that people who love to talk are not burdens - they are connectors, storytellers, and community builders. TalksAlot provides a safe space where your love of conversation is not just tolerated, but celebrated.</p>
        
        <h3>Community Features</h3>
        <ul>
            <li><strong>40+ Specialized Rooms:</strong> From healing spaces to hobby groups, we have a place for every conversation</li>
            <li><strong>Verified Members:</strong> Every user is authenticated for a safer community experience</li>
            <li><strong>Mental Health Support:</strong> Dedicated healing rooms with extra protection</li>
            <li><strong>Identity-Safe Spaces:</strong> LGBTQIA+ and other identity groups have protected areas</li>
            <li><strong>Real-Time Messaging:</strong> Instant connections with fellow conversation enthusiasts</li>
        </ul>
        
        <h3>Safety Promise</h3>
        <p>We've invested extensive effort in technical security, community moderation, and creating safe spaces for vulnerable conversations. Our zero-tolerance policy ensures every room stays positive and supportive.</p>
        
        <p style="text-align: center; margin-top: 30px;">
            <a href="/chat" class="back-btn">Join the Community</a>
        </p>
    </div>
</body>
</html>
        `);
    } else if (req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ 
            status: 'healthy', 
            timestamp: new Date().toISOString(),
            rooms: 40,
            features: ['verified-users', 'real-time-chat', 'healing-spaces', 'community-moderation']
        }));
    } else {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>Page Not Found</h1><p><a href="/">Return to TalksAlot Home</a></p>');
    }
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`TalksAlot server running on http://0.0.0.0:${PORT}`);
    console.log('Ready for deployment with complete chat functionality');
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});