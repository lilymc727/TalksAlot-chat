#!/usr/bin/env node

// TalksAlot Production Deployment Server
// Fixes deployment errors: proper port binding, health checks, and server startup

const http = require('http');
const { WebSocketServer, WebSocket } = require('ws');
const fs = require('fs');
const path = require('path');
const url = require('url');

// Use environment port or fallback to 3000
const PORT = process.env.PORT || 3000;

console.log('TalksAlot Production Server Starting...');
console.log('Port:', PORT);
console.log('Environment:', process.env.NODE_ENV || 'production');

// Storage with all 50 chat rooms
const storage = {
  users: new Map(),
  rooms: new Map(),
  messages: new Map(),
  
  init() {
    const defaultRooms = [
      { id: '1', name: 'Fun Chatters', description: 'Share jokes, memes, and have a laugh together!', emoji: '😄', participants: [] },
      { id: '2', name: 'Deep Thinkers', description: 'Mature philosophical discussions', emoji: '🤔', participants: [] },
      { id: '3', name: 'Vent Space', description: 'Safe space for venting', emoji: '💭', participants: [] },
      { id: '4', name: 'Rants & Real Talk', description: 'Passionate discussions', emoji: '🗣️', participants: [] },
      { id: '5', name: 'Dating & Relationships', description: 'Love and relationship talk', emoji: '💕', participants: [] },
      { id: '6', name: 'RambleRealm', description: '20-minute speaking sessions', emoji: '⏰', participants: [] },
      { id: '7', name: 'DialogueDen', description: 'Thoughtful conversations', emoji: '💬', participants: [] },
      { id: '8', name: 'BabbleBae', description: 'Deep connections', emoji: '✨', participants: [] },
      { id: '9', name: 'Sacred Space', description: 'Spiritual discussions', emoji: '🙏', participants: [] },
      { id: '10', name: 'Breaking Cycles (20s)', description: 'Young adults healing', emoji: '🌱', participants: [] },
      { id: '11', name: 'Wisdom & Healing', description: 'Older adults healing', emoji: '🌿', participants: [] },
      { id: '12', name: 'The Rant Zone', description: 'Passionate venting', emoji: '💢', participants: [] },
      { id: '13', name: 'Late Night Venting', description: 'Night conversations', emoji: '🌙', participants: [] },
      { id: '14', name: 'Single & Talkative', description: 'Single adults chat', emoji: '🗨️', participants: [] },
      { id: '15', name: 'Talk it Out (Mental Health)', description: 'Mental health support', emoji: '🧠', participants: [] },
      { id: '16', name: 'Healing Hearts', description: 'Trauma support', emoji: '💚', participants: [] },
      { id: '17', name: 'Safe Harbor', description: 'Protected conversations', emoji: '🏠', participants: [] },
      { id: '18', name: 'Recovery Circle', description: 'Recovery support', emoji: '🔄', participants: [] },
      { id: '19', name: 'Anxiety & Depression Support', description: 'Mental health community', emoji: '🤝', participants: [] },
      { id: '20', name: 'Life Advice Corner', description: 'Wisdom sharing', emoji: '💡', participants: [] },
      { id: '21', name: 'LGBTQIA+ Community', description: 'Inclusive community', emoji: '🏳️‍🌈', participants: [] },
      { id: '22', name: 'Entrepreneurs Hub', description: 'Business discussions', emoji: '💼', participants: [] },
      { id: '23', name: 'Bug Enthusiasts', description: 'Insect lovers', emoji: '🐛', participants: [] },
      { id: '24', name: 'Animal Lovers', description: 'Pet and wildlife chat', emoji: '🐾', participants: [] },
      { id: '25', name: 'Sky Watchers', description: 'Astronomy discussions', emoji: '🌌', participants: [] },
      { id: '26', name: 'Cannabis Friendly', description: 'Cannabis culture', emoji: '🌿', participants: [] },
      { id: '27', name: 'Music Corner', description: 'Music discussions', emoji: '🎵', participants: [] },
      { id: '28', name: 'Movie Night', description: 'Film discussions', emoji: '🎬', participants: [] },
      { id: '29', name: 'Gaming Zone', description: 'Gaming culture', emoji: '🎮', participants: [] },
      { id: '30', name: 'Foodies United', description: 'Food adventures', emoji: '🍕', participants: [] },
      { id: '31', name: 'Travel Stories', description: 'Travel experiences', emoji: '✈️', participants: [] },
      { id: '32', name: 'Mindful Conversations', description: 'Mindful dialogue', emoji: '🧘', participants: [] },
      { id: '33', name: 'Understanding Hearts', description: 'Mature conversations', emoji: '❤️', participants: [] },
      { id: '34', name: 'Night Owls', description: 'Late night chat', emoji: '🦉', participants: [] },
      { id: '35', name: 'Cook Together Kitchen', description: 'Cooking sessions', emoji: '👨‍🍳', participants: [] },
      { id: '36', name: 'Holiday Chatter', description: 'Holiday celebrations', emoji: '🎄', participants: [] },
      { id: '37', name: 'Book Club Corner', description: 'Literary discussions', emoji: '📚', participants: [] },
      { id: '38', name: 'Language Exchange', description: 'Language practice', emoji: '🗣️', participants: [] },
      { id: '39', name: 'College Years', description: 'Student life', emoji: '🎓', participants: [] },
      { id: '40', name: 'Empty Nesters', description: 'New chapter conversations', emoji: '🏠', participants: [] },
      { id: '41', name: 'Career Mentoring', description: 'Professional guidance', emoji: '💼', participants: [] },
      { id: '42', name: 'Creative Corner', description: 'Creative journey', emoji: '🎨', participants: [] },
      { id: '43', name: 'Tech Talk', description: 'Technology discussions', emoji: '💻', participants: [] },
      { id: '44', name: 'Fitness & Wellness', description: 'Health conversations', emoji: '💪', participants: [] },
      { id: '45', name: 'Parenting Circle', description: 'Parenting support', emoji: '👶', participants: [] },
      { id: '46', name: 'Retirement Adventures', description: 'Golden years chat', emoji: '🌅', participants: [] },
      { id: '47', name: 'Financial Freedom', description: 'Money discussions', emoji: '💰', participants: [] },
      { id: '48', name: 'Home & Garden', description: 'Home improvement', emoji: '🏡', participants: [] },
      { id: '49', name: 'Philosophy Lounge', description: 'Philosophical discussions', emoji: '🤯', participants: [] },
      { id: '50', name: 'Science Enthusiasts', description: 'Science discussions', emoji: '🔬', participants: [] }
    ];
    
    defaultRooms.forEach(room => this.rooms.set(room.id, room));
    console.log(`Initialized ${defaultRooms.length} chat rooms`);
  },
  
  getRooms() { return Array.from(this.rooms.values()); },
  getRoom(id) { return this.rooms.get(id); },
  joinRoom(roomId, userId) {
    const room = this.rooms.get(roomId);
    if (room && !room.participants.includes(userId)) {
      room.participants.push(userId);
    }
    return room;
  },
  leaveRoom(roomId, userId) {
    const room = this.rooms.get(roomId);
    if (room) {
      room.participants = room.participants.filter(id => id !== userId);
    }
    return room;
  },
  addMessage(roomId, senderId, content) {
    const message = {
      id: Date.now().toString(),
      roomId,
      senderId,
      content,
      timestamp: new Date().toISOString()
    };
    this.messages.set(message.id, message);
    return message;
  },
  getRoomMessages(roomId) {
    return Array.from(this.messages.values()).filter(msg => msg.roomId === roomId);
  }
};

// Initialize storage
storage.init();

// MIME type helper
function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
  };
  return mimeTypes[ext] || 'text/plain';
}

// JSON parser helper
function parseJSON(req, callback) {
  let body = '';
  req.on('data', chunk => body += chunk.toString());
  req.on('end', () => {
    try {
      const data = body ? JSON.parse(body) : {};
      callback(null, data);
    } catch (error) {
      callback(error);
    }
  });
}

// Create HTTP server
const server = http.createServer((req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  console.log(`${method} ${pathname}`);

  // Health check endpoint - REQUIRED for deployment
  if (pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'healthy',
      app: 'TalksAlot',
      timestamp: new Date().toISOString(),
      rooms: storage.getRooms().length,
      port: PORT
    }));
    return;
  }

  // API: Get all rooms
  if (pathname === '/api/rooms' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(storage.getRooms()));
    return;
  }

  // API: Get specific room
  const roomMatch = pathname.match(/^\/api\/rooms\/([^\/]+)$/);
  if (roomMatch && method === 'GET') {
    const roomId = roomMatch[1];
    const room = storage.getRoom(roomId);
    if (!room) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Room not found' }));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(room));
    return;
  }

  // Root path serves landing page
  if (pathname === '/') {
    const landingPath = path.join(__dirname, 'public', 'landing.html');
    fs.readFile(landingPath, (err, data) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Landing page not found');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(data);
    });
    return;
  }

  // Static files
  const filePath = pathname;
  const cleanPath = path.join(__dirname, 'public', filePath);
  
  fs.stat(cleanPath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Serve landing page for unknown routes
      const landingPath = path.join(__dirname, 'public', 'landing.html');
      fs.readFile(landingPath, (landingErr, landingData) => {
        if (landingErr) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          res.end('File not found');
          return;
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(landingData);
      });
      return;
    }

    fs.readFile(cleanPath, (readErr, data) => {
      if (readErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
        return;
      }
      const mimeType = getMimeType(cleanPath);
      res.writeHead(200, { 'Content-Type': mimeType });
      res.end(data);
    });
  });
});

// WebSocket server
const wss = new WebSocketServer({ 
  server, 
  path: '/ws'
});

wss.on('connection', (ws, req) => {
  console.log('WebSocket connection established');
  
  ws.on('message', (data) => {
    try {
      const message = JSON.parse(data.toString());
      console.log('WebSocket message:', message.type);
    } catch (error) {
      console.error('WebSocket message error:', error);
    }
  });

  ws.on('close', () => {
    console.log('WebSocket connection closed');
  });
});

// Start server - FIXED: Proper port binding for deployment
server.listen(PORT, '0.0.0.0', () => {
  console.log(`✓ TalksAlot server running on http://0.0.0.0:${PORT}`);
  console.log(`✓ Health check: http://0.0.0.0:${PORT}/health`);
  console.log(`✓ WebSocket server: ws://0.0.0.0:${PORT}/ws`);
  console.log(`✓ Chat rooms: ${storage.getRooms().length} rooms available`);
  console.log(`✓ Production deployment ready`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully');
  wss.close();
  server.close(() => process.exit(0));
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully');
  wss.close();
  server.close(() => process.exit(0));
});