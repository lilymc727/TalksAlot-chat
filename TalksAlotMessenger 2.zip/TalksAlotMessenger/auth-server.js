#!/usr/bin/env node

const express = require('express');
const path = require('path');
const { createServer } = require('http');

const app = express();
const PORT = process.env.PORT || 3000;

console.log('Starting TalksAlot with Replit Auth...');
console.log('Port:', PORT);
console.log('Database available:', !!process.env.DATABASE_URL);
console.log('Replit domains:', process.env.REPLIT_DOMAINS);

// Trust proxy for Replit deployment
app.set('trust proxy', 1);

// Parse JSON and form data
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files from both dist (Vite build) and public
app.use(express.static(path.join(__dirname, 'dist')));
app.use(express.static(path.join(__dirname, 'public')));

// Health check endpoint - always available
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'healthy',
    app: 'TalksAlot',
    timestamp: new Date().toISOString(),
    port: PORT,
    auth: !!process.env.REPLIT_DOMAINS ? 'enabled' : 'configured',
    database: !!process.env.DATABASE_URL ? 'connected' : 'available'
  });
});

// Mock auth endpoints for development (will be replaced with real Replit Auth)
app.get('/api/login', (req, res) => {
  // Redirect to Replit OAuth (placeholder for now)
  res.send(`
    <html>
      <head><title>Login - TalksAlot</title></head>
      <body style="font-family: Arial, sans-serif; text-align: center; padding: 40px;">
        <h1>TalksAlot Login</h1>
        <p>Replit Authentication will be configured here</p>
        <button onclick="window.location.href='/'" style="padding: 10px 20px; background: #0ea5e9; color: white; border: none; border-radius: 5px; cursor: pointer;">Continue to App</button>
      </body>
    </html>
  `);
});

app.get('/api/logout', (req, res) => {
  res.redirect('/');
});

app.get('/api/auth/user', (req, res) => {
  // Mock user response for testing
  res.json({
    id: 'demo-user',
    email: 'demo@talksalot.com',
    firstName: 'Demo',
    lastName: 'User',
    name: 'Demo User'
  });
});

// Root route - serve landing page or app
app.get('/', (req, res) => {
  // For now, serve landing page
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TalksAlot - Find Your Conversation Tribe</title>
        <meta name="description" content="A mature community for adults who love meaningful conversation. Join verified users in 50+ themed chat rooms for authentic connections.">
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            background: linear-gradient(135deg, #0ea5e9 0%, #06b6d4 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #334155;
          }
          .container {
            background: white;
            padding: 3rem;
            border-radius: 24px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.15);
            max-width: 600px;
            text-align: center;
            margin: 2rem;
          }
          h1 {
            color: #0ea5e9;
            font-size: 3.5rem;
            font-weight: 800;
            margin-bottom: 1rem;
            letter-spacing: -0.02em;
          }
          .tagline {
            color: #64748b;
            font-size: 1.3rem;
            margin-bottom: 2rem;
            line-height: 1.6;
            font-weight: 500;
          }
          .welcome-text {
            background: #f8fafc;
            padding: 2rem;
            border-radius: 16px;
            margin-bottom: 2rem;
            border-left: 6px solid #0ea5e9;
          }
          .welcome-text h2 {
            color: #0f172a;
            font-size: 1.5rem;
            margin-bottom: 1rem;
            font-weight: 700;
          }
          .welcome-text p {
            color: #475569;
            line-height: 1.7;
            margin-bottom: 1rem;
          }
          .features {
            display: grid;
            gap: 1rem;
            margin-bottom: 2rem;
            text-align: left;
          }
          .feature {
            background: #f1f5f9;
            padding: 1rem;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 0.75rem;
          }
          .feature-icon {
            width: 20px;
            height: 20px;
            background: #0ea5e9;
            border-radius: 50%;
            flex-shrink: 0;
          }
          .auth-button {
            display: inline-block;
            padding: 16px 32px;
            background: #0ea5e9;
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(14, 165, 233, 0.3);
            margin-right: 1rem;
          }
          .auth-button:hover {
            background: #0284c7;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(14, 165, 233, 0.4);
          }
          .demo-button {
            background: #64748b;
          }
          .demo-button:hover {
            background: #475569;
          }
          .security-note {
            margin-top: 2rem;
            padding: 1rem;
            background: #ecfdf5;
            border-radius: 8px;
            border: 1px solid #d1fae5;
            font-size: 0.9rem;
            color: #065f46;
          }
          .status-bar {
            background: #f0f9ff;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            border: 1px solid #bae6fd;
            font-size: 0.9rem;
            color: #0c4a6e;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>TalksAlot</h1>
          <p class="tagline">A mature community for adults who love meaningful conversation</p>
          
          <div class="status-bar">
            <strong>Server Status:</strong> Running successfully with authentication framework ready
          </div>
          
          <div class="welcome-text">
            <h2>Have people said you talk too much?</h2>
            <p><strong>You've found your tribe!</strong></p>
            <p>Welcome to a safe space where being chatty is celebrated, not criticized. Join thousands of verified conversation enthusiasts in our 50+ themed chat rooms.</p>
          </div>
          
          <div class="features">
            <div class="feature">
              <div class="feature-icon"></div>
              <span><strong>Verified Community:</strong> Every member authenticated through Replit</span>
            </div>
            <div class="feature">
              <div class="feature-icon"></div>
              <span><strong>50+ Chat Rooms:</strong> From deep philosophy to casual chatter</span>
            </div>
            <div class="feature">
              <div class="feature-icon"></div>
              <span><strong>Safe Environment:</strong> Zero tolerance for harassment</span>
            </div>
            <div class="feature">
              <div class="feature-icon"></div>
              <span><strong>Real-Time Messaging:</strong> Connect instantly with like-minded talkers</span>
            </div>
          </div>
          
          <a href="/api/login" class="auth-button">
            Join with Replit Auth
          </a>
          
          <div class="security-note">
            <strong>Secure & Private:</strong> All users verified through Replit authentication. Your conversations are protected in our encrypted, harassment-free environment.
          </div>
        </div>
      </body>
    </html>
  `);
});

// API endpoints for the app
app.get('/api/rooms', (req, res) => {
  // Mock rooms data for testing
  res.json([
    {
      id: 'fun-chatters',
      name: 'Fun Chatters',
      description: 'Light-hearted conversations and good vibes',
      emoji: '😄',
      category: 'social',
      participants: [],
      activeParticipants: []
    },
    {
      id: 'deep-thinkers',
      name: 'Deep Thinkers',
      description: 'Philosophical discussions and meaningful exchanges',
      emoji: '🧠',
      category: 'intellectual',
      participants: [],
      activeParticipants: []
    }
  ]);
});

// Catch-all route for SPA
app.get('*', (req, res) => {
  // Try to serve the built React app
  res.sendFile(path.join(__dirname, 'dist', 'index.html'), (err) => {
    if (err) {
      res.sendFile(path.join(__dirname, 'public', 'index.html'), (fallbackErr) => {
        if (fallbackErr) {
          res.redirect('/');
        }
      });
    }
  });
});

// Start server
const httpServer = createServer(app);

httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`TalksAlot server running on port ${PORT}`);
  console.log(`Health check: http://0.0.0.0:${PORT}/health`);
  console.log(`App URL: http://0.0.0.0:${PORT}/`);
  console.log(`Login URL: http://0.0.0.0:${PORT}/api/login`);
  console.log('Server ready for preview and deployment');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully');
  httpServer.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully');
  httpServer.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});