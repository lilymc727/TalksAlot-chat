#!/usr/bin/env node

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;

console.log('Starting TalksAlot preview server...');
console.log('Port:', PORT);

function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
  };
  return mimeTypes[ext] || 'text/plain';
}

const server = http.createServer((req, res) => {
  console.log(`${req.method} ${req.url}`);
  
  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }
  
  // Health check endpoint
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'healthy',
      app: 'TalksAlot',
      timestamp: new Date().toISOString(),
      port: PORT
    }));
    return;
  }
  
  // Handle root request
  if (req.url === '/' || req.url === '/index.html') {
    // Try to serve from dist first (Vite build), then public, then fallback
    const distIndex = path.join(__dirname, 'dist', 'index.html');
    const publicIndex = path.join(__dirname, 'public', 'index.html');
    
    // Check if dist/index.html exists
    if (fs.existsSync(distIndex)) {
      const content = fs.readFileSync(distIndex);
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(content);
      return;
    }
    
    // Check if public/index.html exists
    if (fs.existsSync(publicIndex)) {
      const content = fs.readFileSync(publicIndex);
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(content);
      return;
    }
    
    // Fallback HTML
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>TalksAlot</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              margin: 0;
              padding: 40px;
              text-align: center;
              background: linear-gradient(135deg, #0ea5e9, #06b6d4);
              min-height: 100vh;
              display: flex;
              align-items: center;
              justify-content: center;
            }
            .container {
              background: white;
              padding: 3rem;
              border-radius: 20px;
              box-shadow: 0 20px 40px rgba(0,0,0,0.1);
              max-width: 600px;
            }
            h1 {
              color: #0ea5e9;
              font-size: 3rem;
              margin-bottom: 1rem;
              font-weight: 700;
            }
            p {
              color: #64748b;
              font-size: 1.2rem;
              margin-bottom: 2rem;
              line-height: 1.6;
            }
            .status {
              background: #f0f9ff;
              padding: 1rem;
              border-radius: 10px;
              border-left: 4px solid #0ea5e9;
              margin-bottom: 2rem;
            }
            .auth-button {
              display: inline-block;
              padding: 12px 24px;
              background: #0ea5e9;
              color: white;
              text-decoration: none;
              border-radius: 8px;
              font-weight: 600;
              transition: background 0.2s;
            }
            .auth-button:hover {
              background: #0284c7;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>TalksAlot</h1>
            <p>A mature community for adults who love meaningful conversation</p>
            <div class="status">
              <strong>Preview Status:</strong> Server running successfully!<br>
              <small>Ready for Replit Auth integration</small>
            </div>
            <p>Have people said you talk too much? You've found your tribe!</p>
            <a href="#" class="auth-button">Join the Community</a>
          </div>
        </body>
      </html>
    `);
    return;
  }
  
  // Serve static files
  let filePath = path.join(__dirname, req.url);
  
  // Try dist directory first, then public
  const distPath = path.join(__dirname, 'dist', req.url);
  const publicPath = path.join(__dirname, 'public', req.url);
  
  if (fs.existsSync(distPath) && fs.statSync(distPath).isFile()) {
    filePath = distPath;
  } else if (fs.existsSync(publicPath) && fs.statSync(publicPath).isFile()) {
    filePath = publicPath;
  }
  
  // Check if file exists
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    const content = fs.readFileSync(filePath);
    const mimeType = getMimeType(filePath);
    res.writeHead(200, { 'Content-Type': mimeType });
    res.end(content);
  } else {
    // For SPA routing, serve index.html for any unknown routes
    const distIndex = path.join(__dirname, 'dist', 'index.html');
    const publicIndex = path.join(__dirname, 'public', 'index.html');
    
    if (fs.existsSync(distIndex)) {
      const content = fs.readFileSync(distIndex);
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(content);
    } else if (fs.existsSync(publicIndex)) {
      const content = fs.readFileSync(publicIndex);
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(content);
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('File not found');
    }
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`TalksAlot server listening on port ${PORT}`);
  console.log(`Health check: http://0.0.0.0:${PORT}/health`);
  console.log(`App URL: http://0.0.0.0:${PORT}/`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Shutting down gracefully');
  server.close(() => {
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('Shutting down gracefully');
  server.close(() => {
    process.exit(0);
  });
});