const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;

// Simple HTTP server that serves static files and basic routes
const server = http.createServer((req, res) => {
  const url = req.url;
  
  // Set CORS headers for all requests
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Health check endpoint
  if (url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ 
      status: 'healthy', 
      service: 'TalksAlot',
      timestamp: new Date().toISOString()
    }));
    return;
  }

  // Demo page
  if (url === '/demo') {
    try {
      const demoPath = path.join(__dirname, 'demo.html');
      const content = fs.readFileSync(demoPath, 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(content);
    } catch (error) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Demo page not found');
    }
    return;
  }

  // App page (redirect to login for now)
  if (url === '/app') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>TalksAlot - Login Required</title>
        <style>
          body { font-family: system-ui; text-align: center; padding: 2rem; background: #f0f9ff; }
          .container { max-width: 500px; margin: 0 auto; background: white; padding: 2rem; border-radius: 20px; }
          .btn { background: #0f766e; color: white; padding: 1rem 2rem; border: none; border-radius: 25px; cursor: pointer; text-decoration: none; display: inline-block; margin: 1rem; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>🗣️ TalksAlot</h1>
          <p>Authentication system is being configured.</p>
          <p>Try the demo version for now:</p>
          <a href="/demo" class="btn">Try Demo</a>
          <a href="/" class="btn">Home</a>
        </div>
      </body>
      </html>
    `);
    return;
  }

  // Landing page
  if (url === '/' || url === '/landing') {
    try {
      const landingPath = path.join(__dirname, 'public', 'landing.html');
      if (fs.existsSync(landingPath)) {
        const content = fs.readFileSync(landingPath, 'utf8');
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(content);
      } else {
        // Fallback landing page
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
          <!DOCTYPE html>
          <html>
          <head>
            <title>TalksAlot - Where Talkers Find Their Tribe</title>
            <style>
              body { font-family: system-ui; text-align: center; padding: 2rem; background: linear-gradient(135deg, #0891b2, #22d3ee); color: white; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
              .container { max-width: 600px; background: rgba(255,255,255,0.1); padding: 3rem; border-radius: 20px; backdrop-filter: blur(10px); }
              h1 { font-size: 3rem; margin-bottom: 1rem; }
              .btn { background: rgba(255,255,255,0.9); color: #0f766e; padding: 1rem 2rem; border: none; border-radius: 25px; cursor: pointer; text-decoration: none; display: inline-block; margin: 1rem; font-weight: 600; }
              .btn:hover { background: white; }
            </style>
          </head>
          <body>
            <div class="container">
              <h1>🗣️ TalksAlot</h1>
              <p style="font-size: 1.2rem; margin-bottom: 2rem;">Where people who love to talk find their tribe</p>
              <p>Have people said you talk too much? You've found your home!</p>
              <a href="/demo" class="btn">Try Demo</a>
              <a href="/app" class="btn">Join Community</a>
            </div>
          </body>
          </html>
        `);
      }
    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Server error');
    }
    return;
  }

  // 404 for other routes
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Page not found');
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`🗣️ TalksAlot server running on http://0.0.0.0:${PORT}`);
  console.log(`📱 Demo: http://0.0.0.0:${PORT}/demo`);
  console.log(`🏠 Home: http://0.0.0.0:${PORT}/`);
  console.log(`💬 App: http://0.0.0.0:${PORT}/app`);
});

process.on('SIGTERM', () => {
  console.log('Server shutting down gracefully...');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});