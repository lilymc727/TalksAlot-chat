#!/usr/bin/env node

const { spawn } = require('child_process');
const fs = require('fs');

console.log('Starting TalksAlot server with persistent connection...');

function startServer() {
  const server = spawn('node', ['server.js'], {
    stdio: ['pipe', 'pipe', 'pipe'],
    detached: false
  });

  server.stdout.on('data', (data) => {
    console.log(`Server: ${data}`);
  });

  server.stderr.on('data', (data) => {
    console.error(`Server Error: ${data}`);
  });

  server.on('close', (code) => {
    console.log(`Server process exited with code ${code}`);
    console.log('Restarting server in 2 seconds...');
    setTimeout(startServer, 2000);
  });

  server.on('error', (err) => {
    console.error('Failed to start server:', err);
    setTimeout(startServer, 2000);
  });

  // Keep the process alive
  process.on('SIGTERM', () => {
    console.log('Shutting down server manager');
    server.kill();
    process.exit(0);
  });

  process.on('SIGINT', () => {
    console.log('Shutting down server manager');
    server.kill();
    process.exit(0);
  });
}

startServer();