const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;

// Initialize default rooms data
const rooms = [
  // Core Community Spaces
  { id: 'fun-chatters', name: 'Fun Chatters', emoji: '🎉', category: 'Core Community', description: 'Light-hearted conversations and laughs', participants: 47 },
  { id: 'deep-thinkers', name: 'Deep Thinkers', emoji: '💭', category: 'Core Community', description: 'Philosophical discussions and meaningful conversations', participants: 52 },
  { id: 'vent-space', name: 'Vent Space', emoji: '💨', category: 'Core Community', description: 'Safe space to express frustrations and feelings', participants: 34 },
  { id: 'life-advice-corner', name: 'Life Advice Corner', emoji: '🤝', category: 'Core Community', description: 'Share wisdom and seek guidance from fellow talkers', participants: 41 },
  
  // Healing & Mental Health
  { id: 'talk-it-out', name: 'Talk it Out (Mental Health)', emoji: '🧠', category: 'Healing & Mental Health', description: 'Mental health support and understanding', participants: 28 },
  { id: 'healing-hearts', name: 'Healing Hearts', emoji: '💚', category: 'Healing & Mental Health', description: 'Recovery and emotional healing journey', participants: 31 },
  { id: 'safe-harbor', name: 'Safe Harbor', emoji: '⚓', category: 'Healing & Mental Health', description: 'Crisis support and immediate comfort', participants: 19 },
  { id: 'recovery-circle', name: 'Recovery Circle', emoji: '🔄', category: 'Healing & Mental Health', description: 'Addiction recovery and sobriety support', participants: 23 },
  { id: 'anxiety-depression', name: 'Anxiety & Depression Support', emoji: '🌈', category: 'Healing & Mental Health', description: 'Understanding and coping together', participants: 45 },
];

const server = http.createServer((req, res) => {
  const url = req.url;
  
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Health check endpoint - REQUIRED for deployment
  if (url === '/health' || url === '/') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ 
      status: 'healthy', 
      service: 'TalksAlot Chat Application',
      timestamp: new Date().toISOString(),
      rooms: rooms.length
    }));
    return;
  }

  // Demo page - serves the chat interface
  if (url === '/demo') {
    const demoHTML = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TalksAlot - Demo Chat</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: system-ui; background: #f0f9ff; height: 100vh; display: flex; flex-direction: column; }
        .header { background: linear-gradient(135deg, #0f766e, #14b8a6); color: white; padding: 1rem; display: flex; justify-content: space-between; align-items: center; }
        .content { flex: 1; display: flex; overflow: hidden; }
        .sidebar { width: 350px; background: white; border-right: 1px solid #e5e7eb; overflow-y: auto; }
        .chat-area { flex: 1; display: flex; flex-direction: column; background: white; }
        .room-category { padding: 1rem; border-bottom: 1px solid #e5e7eb; }
        .category-title { font-weight: 600; color: #374151; margin-bottom: 0.5rem; }
        .room-item { padding: 0.75rem 1rem; cursor: pointer; border-bottom: 1px solid #f3f4f6; transition: background 0.2s; }
        .room-item:hover { background: #f9fafb; }
        .room-header { display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem; }
        .room-emoji { font-size: 1.2rem; }
        .room-name { font-weight: 500; color: #111827; }
        .room-participants { font-size: 0.875rem; color: #6b7280; }
        .welcome-message { text-align: center; color: #6b7280; padding: 2rem; }
        .chat-header { padding: 1rem; border-bottom: 1px solid #e5e7eb; background: #f9fafb; }
        .messages { flex: 1; padding: 1rem; overflow-y: auto; background: #fafafa; }
        .message-input { padding: 1rem; border-top: 1px solid #e5e7eb; background: white; }
        .input-container { display: flex; gap: 0.5rem; }
        .message-field { flex: 1; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 25px; outline: none; }
        .send-btn { background: #0f766e; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 25px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🗣️ TalksAlot Demo</h1>
        <div>Welcome, Demo User!</div>
    </div>
    
    <div class="content">
        <div class="sidebar" id="sidebar">
            <div class="room-category">
                <div class="category-title">Core Community</div>
                ${rooms.filter(r => r.category === 'Core Community').map(room => `
                    <div class="room-item" onclick="selectRoom('${room.id}')">
                        <div class="room-header">
                            <span class="room-emoji">${room.emoji}</span>
                            <span class="room-name">${room.name}</span>
                        </div>
                        <div class="room-participants">${room.participants} active talkers</div>
                    </div>
                `).join('')}
            </div>
            <div class="room-category">
                <div class="category-title">Healing & Mental Health</div>
                ${rooms.filter(r => r.category === 'Healing & Mental Health').map(room => `
                    <div class="room-item" onclick="selectRoom('${room.id}')">
                        <div class="room-header">
                            <span class="room-emoji">${room.emoji}</span>
                            <span class="room-name">${room.name}</span>
                        </div>
                        <div class="room-participants">${room.participants} active talkers</div>
                    </div>
                `).join('')}
            </div>
        </div>
        
        <div class="chat-area">
            <div class="chat-header">
                <h2 id="current-room">Select a room to start chatting</h2>
            </div>
            <div class="messages" id="messages">
                <div class="welcome-message">
                    <h3>Welcome to TalksAlot!</h3>
                    <p>Choose a room from the sidebar to start conversations with fellow talkers.</p>
                    <p style="margin-top: 1rem; font-style: italic;">This is a demo - experience our full community with 50+ rooms!</p>
                </div>
            </div>
            <div class="message-input">
                <div class="input-container">
                    <input type="text" id="messageInput" class="message-field" placeholder="Type your message..." disabled>
                    <button id="sendBtn" class="send-btn" disabled>Send</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function selectRoom(roomId) {
            const room = ${JSON.stringify(rooms)}.find(r => r.id === roomId);
            document.getElementById('current-room').textContent = room.emoji + ' ' + room.name;
            document.getElementById('messageInput').disabled = false;
            document.getElementById('sendBtn').disabled = false;
            
            // Show demo messages
            const messages = document.getElementById('messages');
            messages.innerHTML = '<div style="margin-bottom: 1rem; padding: 0.75rem; background: #f3f4f6; border-radius: 10px;"><strong>TalkerBot:</strong> Welcome to ' + room.name + '! This room is perfect for ' + room.description.toLowerCase() + '.</div><div style="margin-bottom: 1rem; padding: 0.75rem; background: #f0f9ff; border-radius: 10px;"><strong>Demo User:</strong> This is a demo message to show how conversations work in TalksAlot!</div>';
        }
    </script>
</body>
</html>`;
    
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(demoHTML);
    return;
  }

  // Landing page
  if (url === '/landing' || url === '/home') {
    const landingHTML = `
<!DOCTYPE html>
<html lang="en">
<head>
    <title>TalksAlot - Where Talkers Find Their Tribe</title>
    <style>
        body { font-family: system-ui; text-align: center; padding: 2rem; background: linear-gradient(135deg, #0891b2, #22d3ee); color: white; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .container { max-width: 600px; background: rgba(255,255,255,0.1); padding: 3rem; border-radius: 20px; backdrop-filter: blur(10px); }
        h1 { font-size: 3rem; margin-bottom: 1rem; }
        .btn { background: rgba(255,255,255,0.9); color: #0f766e; padding: 1rem 2rem; border: none; border-radius: 25px; cursor: pointer; text-decoration: none; display: inline-block; margin: 1rem; font-weight: 600; }
        .btn:hover { background: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🗣️ TalksAlot</h1>
        <p style="font-size: 1.2rem; margin-bottom: 2rem;">Where people who love to talk find their tribe</p>
        <p>Have people said you talk too much? You've found your home!</p>
        <a href="/demo" class="btn">Try Demo</a>
    </div>
</body>
</html>`;
    
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(landingHTML);
    return;
  }

  // Default - redirect to demo for now
  res.writeHead(302, { 'Location': '/demo' });
  res.end();
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('🗣️ TalksAlot server running on http://0.0.0.0:' + PORT);
  console.log('📱 Demo: http://0.0.0.0:' + PORT + '/demo');
  console.log('🏠 Landing: http://0.0.0.0:' + PORT + '/landing');
  console.log('✅ Health: http://0.0.0.0:' + PORT + '/health');
});

process.on('SIGTERM', () => {
  console.log('Server shutting down gracefully...');
  server.close(() => {
    process.exit(0);
  });
});