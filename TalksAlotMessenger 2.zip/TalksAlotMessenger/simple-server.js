const http = require('http');
const PORT = process.env.PORT || 3000;

console.log('Starting TalksAlot server...');

const homepage = `<!DOCTYPE html>
<html>
<head>
    <title>TalksAlot - Where Talkers Find Their Tribe</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #0891b2, #06b6d4);
            color: white;
            text-align: center;
            min-height: 100vh;
        }
        .container { max-width: 800px; margin: 0 auto; padding: 40px 20px; }
        h1 { font-size: 3em; margin-bottom: 20px; }
        .tagline { font-size: 1.3em; margin-bottom: 30px; opacity: 0.9; }
        .welcome { 
            background: rgba(255,255,255,0.1); 
            padding: 30px; 
            border-radius: 15px; 
            margin: 30px 0;
            backdrop-filter: blur(10px);
        }
        .stats { display: flex; justify-content: space-around; margin: 40px 0; flex-wrap: wrap; }
        .stat { 
            background: rgba(255,255,255,0.1); 
            padding: 20px; 
            border-radius: 10px; 
            margin: 10px;
            min-width: 120px;
        }
        .stat-number { font-size: 2.5em; font-weight: bold; display: block; }
        .rooms { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-top: 40px; }
        .room { 
            background: rgba(255,255,255,0.1); 
            padding: 20px; 
            border-radius: 10px;
            transition: transform 0.3s;
        }
        .room:hover { transform: translateY(-5px); }
        .room-emoji { font-size: 2em; margin-bottom: 10px; }
        .room-name { font-size: 1.2em; font-weight: bold; margin-bottom: 5px; }
        .status { position: fixed; top: 20px; right: 20px; background: #22c55e; padding: 10px 20px; border-radius: 25px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🗣️ TalksAlot</h1>
        <p class="tagline">Where Talkers Find Their Tribe</p>
        
        <div class="welcome">
            <h2>Have people said you talk a lot? You've found your tribe!</h2>
            <p>TalksAlot is a mature community for adults (19+) who love meaningful conversation. This is your safe space where being chatty is celebrated, not criticized.</p>
        </div>

        <div class="stats">
            <div class="stat">
                <span class="stat-number">50</span>
                <span>Chat Rooms</span>
            </div>
            <div class="stat">
                <span class="stat-number">24/7</span>
                <span>Active</span>
            </div>
            <div class="stat">
                <span class="stat-number">19+</span>
                <span>Adults Only</span>
            </div>
            <div class="stat">
                <span class="stat-number">Safe</span>
                <span>Zero Tolerance</span>
            </div>
        </div>

        <h2>Featured Chat Rooms</h2>
        <div class="rooms">
            <div class="room">
                <div class="room-emoji">😄</div>
                <div class="room-name">Fun Chatters</div>
                <p>Share jokes and laughs</p>
            </div>
            <div class="room">
                <div class="room-emoji">🤔</div>
                <div class="room-name">Deep Thinkers</div>
                <p>Philosophical discussions</p>
            </div>
            <div class="room">
                <div class="room-emoji">💭</div>
                <div class="room-name">Vent Space</div>
                <p>Safe space for venting</p>
            </div>
            <div class="room">
                <div class="room-emoji">🧠</div>
                <div class="room-name">Mental Health</div>
                <p>Support and understanding</p>
            </div>
            <div class="room">
                <div class="room-emoji">🏳️‍🌈</div>
                <div class="room-name">LGBTQIA+</div>
                <p>Inclusive community</p>
            </div>
            <div class="room">
                <div class="room-emoji">⏰</div>
                <div class="room-name">RambleRealm</div>
                <p>20-minute speaking sessions</p>
            </div>
        </div>
    </div>
    
    <div class="status">🟢 Server Online</div>
</body>
</html>`;

const server = http.createServer((req, res) => {
    const url = req.url;
    
    console.log(`${req.method} ${url}`);
    
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }
    
    // Health check
    if (url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            status: 'healthy',
            app: 'TalksAlot',
            port: PORT,
            timestamp: new Date().toISOString()
        }));
        return;
    }
    
    // Serve homepage for all other requests
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(homepage);
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`TalksAlot server running on http://0.0.0.0:${PORT}`);
    console.log(`Health check: http://0.0.0.0:${PORT}/health`);
    console.log('Server ready for preview');
});

// Keep server alive
setInterval(() => {
    console.log(`Server heartbeat - ${new Date().toLocaleTimeString()}`);
}, 30000);

process.on('SIGTERM', () => {
    console.log('Server shutting down');
    server.close(() => process.exit(0));
});

process.on('SIGINT', () => {
    console.log('Server shutting down');
    server.close(() => process.exit(0));
});