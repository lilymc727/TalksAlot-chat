const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;

const server = http.createServer((req, res) => {
    if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
<!DOCTYPE html>
<html>
<head>
    <title>TalksAlot - Chat Community</title>
    <style>
        body { font-family: system-ui; background: linear-gradient(135deg, #0f766e, #06b6d4); margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: white; border-radius: 20px; padding: 40px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); }
        h1 { color: #0f766e; text-align: center; margin-bottom: 30px; }
        .demo-btn { display: block; margin: 20px auto; padding: 15px 30px; background: #0f766e; color: white; text-decoration: none; border-radius: 25px; text-align: center; font-weight: 600; }
        .demo-btn:hover { background: #065f46; }
        .description { text-align: center; color: #374151; margin-bottom: 30px; line-height: 1.6; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🗣️ TalksAlot</h1>
        <div class="description">
            <p>Welcome to TalksAlot - where talking too much is celebrated, not criticized!</p>
            <p>Join 40+ specialized chat rooms designed for conversation enthusiasts who love meaningful dialogue.</p>
        </div>
        <a href="/demo" class="demo-btn">View Full Chat Application</a>
    </div>
</body>
</html>
        `);
    } else if (req.url === '/demo') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        try {
            const demoHTML = fs.readFileSync('./demo.html', 'utf8');
            res.end(demoHTML);
        } catch (error) {
            res.end('<h1>Demo loading...</h1><p>Chat application is loading. Please refresh in a moment.</p>');
        }
    } else if (req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'healthy', timestamp: new Date().toISOString() }));
    } else {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>Page Not Found</h1>');
    }
});

server.listen(PORT, '0.0.0.0', () => {
    console.log(`TalksAlot server running on http://0.0.0.0:${PORT}`);
});