import {
  pgTable,
  uuid,
  varchar,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  index,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";


// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User table with Replit Auth integration
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(), // Replit user ID
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  name: varchar("name", { length: 255 }),
  age: integer("age"),
  location: varchar("location", { length: 255 }),
  bio: text("bio"),
  photoUrl: varchar("photo_url", { length: 500 }),
  talkStyle: varchar("talk_style", { length: 100 }),
  favoriteTopics: text("favorite_topics").array(),
  interests: text("interests").array(),
  isOnline: boolean("is_online").default(false),
  talkStreak: integer("talk_streak").default(1),
  badges: text("badges").array(),
  joinedAt: timestamp("joined_at").defaultNow(),
  lastActiveAt: timestamp("last_active_at").defaultNow(),
  preferences: jsonb("preferences"),
  karmaScore: integer("karma_score").default(0),
  isVerified: boolean("is_verified").default(true), // Replit users are verified
  timezone: varchar("timezone", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  // Stripe payment fields
  stripeCustomerId: varchar("stripe_customer_id"),
  subscriptionId: varchar("subscription_id"),
  subscriptionStatus: varchar("subscription_status"),
  isSubscribed: boolean("is_subscribed").default(false),
  trialEnd: timestamp("trial_end"),
});

export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;

// Chat room table
export const chatRooms = pgTable("chat_rooms", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description").notNull(),
  emoji: varchar("emoji", { length: 10 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  participants: text("participants").array(),
  activeParticipants: text("active_participants").array(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  createdBy: varchar("created_by").references(() => users.id),
  moderators: text("moderators").array(),
});

export type ChatRoom = typeof chatRooms.$inferSelect;

// Messages table - declare first to avoid circular reference
export const messages = pgTable("messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  roomId: uuid("room_id").notNull(),
  userId: varchar("user_id").notNull(),
  userName: varchar("user_name", { length: 255 }).notNull(),
  content: text("content").notNull(),
  type: varchar("type", { length: 50 }).default("text"),
  createdAt: timestamp("created_at").defaultNow(),
  editedAt: timestamp("edited_at"),
  isDeleted: boolean("is_deleted").default(false),
  replyTo: uuid("reply_to"),
  reactions: jsonb("reactions"),
});

export type Message = typeof messages.$inferSelect;

// Match requests table
export const matchRequests = pgTable("match_requests", {
  id: uuid("id").primaryKey().defaultRandom(),
  isActive: boolean("is_active").default(true),
  userId: varchar("user_id").references(() => users.id),
  userName: varchar("user_name", { length: 255 }).notNull(),
  preferredTopic: varchar("preferred_topic", { length: 255 }).notNull(),
  matchedWith: varchar("matched_with").references(() => users.id),
  matchedAt: timestamp("matched_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type MatchRequest = typeof matchRequests.$inferSelect;

// User reports table
export const userReports = pgTable("user_reports", {
  id: uuid("id").primaryKey().defaultRandom(),
  description: text("description"),
  roomId: uuid("room_id").references(() => chatRooms.id),
  reportedUserId: varchar("reported_user_id").references(() => users.id).notNull(),
  reporterUserId: varchar("reporter_user_id").references(() => users.id).notNull(),
  messageId: uuid("message_id").references(() => messages.id),
  category: varchar("category", { length: 100 }).notNull(),
  status: varchar("status", { length: 50 }).default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
  resolvedBy: varchar("resolved_by").references(() => users.id),
});

export type UserReport = typeof userReports.$inferSelect;

// Private conversations table
export const privateConversations = pgTable("private_conversations", {
  id: uuid("id").primaryKey().defaultRandom(),
  isActive: boolean("is_active").default(true),
  user1Id: varchar("user1_id").references(() => users.id),
  user2Id: varchar("user2_id").references(() => users.id),
  lastMessageAt: timestamp("last_message_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type PrivateConversation = typeof privateConversations.$inferSelect;

// Private messages table
export const privateMessages = pgTable("private_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  content: text("content").notNull(),
  type: varchar("type", { length: 50 }).default("text"),
  conversationId: uuid("conversation_id").references(() => privateConversations.id),
  senderId: varchar("sender_id").references(() => users.id),
  isRead: boolean("is_read").default(false),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type PrivateMessage = typeof privateMessages.$inferSelect;

// User achievements table
export const userAchievements = pgTable("user_achievements", {
  id: uuid("id").primaryKey().defaultRandom(),
  description: text("description"),
  userId: varchar("user_id").references(() => users.id),
  achievementType: varchar("achievement_type", { length: 100 }).notNull(),
  achievementName: varchar("achievement_name", { length: 255 }).notNull(),
  isVisible: boolean("is_visible").default(true),
  earnedAt: timestamp("earned_at").defaultNow(),
});

export type UserAchievement = typeof userAchievements.$inferSelect;

// Conversation favorites table
export const conversationFavorites = pgTable("conversation_favorites", {
  id: uuid("id").primaryKey().defaultRandom(),
  roomId: uuid("room_id").references(() => chatRooms.id),
  userId: varchar("user_id").references(() => users.id),
  messageId: uuid("message_id").references(() => messages.id),
  title: varchar("title", { length: 255 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type ConversationFavorite = typeof conversationFavorites.$inferSelect;

// Room bookmarks table
export const roomBookmarks = pgTable("room_bookmarks", {
  id: uuid("id").primaryKey().defaultRandom(),
  roomId: uuid("room_id").references(() => chatRooms.id),
  userId: varchar("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export type RoomBookmark = typeof roomBookmarks.$inferSelect;

// User interactions table (for karma system)
export const userInteractions = pgTable("user_interactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  roomId: uuid("room_id").references(() => chatRooms.id),
  type: varchar("type", { length: 50 }).notNull(),
  messageId: uuid("message_id").references(() => messages.id),
  fromUserId: varchar("from_user_id").references(() => users.id),
  toUserId: varchar("to_user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export type UserInteraction = typeof userInteractions.$inferSelect;

// Community events table
export const communityEvents = pgTable("community_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  duration: integer("duration"),
  description: text("description"),
  title: varchar("title", { length: 255 }).notNull(),
  eventType: varchar("event_type", { length: 100 }).notNull(),
  hostUserId: varchar("host_user_id").references(() => users.id),
  participants: text("participants").array(),
  maxParticipants: integer("max_participants"),
  isActive: boolean("is_active").default(true),
  scheduledFor: timestamp("scheduled_for"),
  createdAt: timestamp("created_at").defaultNow(),
});

export type CommunityEvent = typeof communityEvents.$inferSelect;

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  messages: many(messages),
  matchRequests: many(matchRequests),
  userReports: many(userReports),
  privateConversations1: many(privateConversations, { relationName: "user1" }),
  privateConversations2: many(privateConversations, { relationName: "user2" }),
  privateMessages: many(privateMessages),
  userAchievements: many(userAchievements),
  conversationFavorites: many(conversationFavorites),
  roomBookmarks: many(roomBookmarks),
  userInteractions: many(userInteractions),
  communityEvents: many(communityEvents),
}));

export const chatRoomsRelations = relations(chatRooms, ({ one, many }) => ({
  createdBy: one(users, { fields: [chatRooms.createdBy], references: [users.id] }),
  messages: many(messages),
  userReports: many(userReports),
  conversationFavorites: many(conversationFavorites),
  roomBookmarks: many(roomBookmarks),
  userInteractions: many(userInteractions),
}));

export const messagesRelations = relations(messages, ({ one, many }) => ({
  room: one(chatRooms, { fields: [messages.roomId], references: [chatRooms.id] }),
  user: one(users, { fields: [messages.userId], references: [users.id] }),
  replyToMessage: one(messages, { fields: [messages.replyTo], references: [messages.id] }),
  replies: many(messages),
  userReports: many(userReports),
  conversationFavorites: many(conversationFavorites),
  userInteractions: many(userInteractions),
}));

// Simplified Insert types (temporary fix for deployment)
export type InsertUser = {
  id?: string;
  email?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  profileImageUrl?: string | null;
  name?: string | null;
  age?: number | null;
  location?: string | null;
  bio?: string | null;
  photoUrl?: string | null;
  talkStyle?: string | null;
  favoriteTopics?: string[] | null;
  interests?: string[] | null;
  isOnline?: boolean | null;
  talkStreak?: number | null;
  badges?: string[] | null;
  joinedAt?: Date | null;
  lastActiveAt?: Date | null;
  preferences?: unknown;
  createdAt?: Date | null;
  updatedAt?: Date | null;
  // Stripe payment fields
  stripeCustomerId?: string | null;
  subscriptionId?: string | null;
  subscriptionStatus?: string | null;
  isSubscribed?: boolean | null;
  trialEnd?: Date | null;
};

export type InsertChatRoom = {
  id?: string;
  name: string;
  description: string;
  emoji: string;
  category: string;
  participants?: string[] | null;
  activeParticipants?: string[] | null;
  isActive?: boolean | null;
  createdAt?: Date | null;
  updatedAt?: Date | null;
  createdBy?: string | null;
  moderators?: string[] | null;
};

export type InsertMessage = {
  id?: string;
  roomId: string;
  userId: string;
  userName: string;
  content: string;
  type?: string | null;
  createdAt?: Date | null;
  editedAt?: Date | null;
  isDeleted?: boolean | null;
  replyTo?: string | null;
  reactions?: unknown;
};

export type InsertMatchRequest = {
  id?: string;
  isActive?: boolean | null;
  userId?: string | null;
  userName: string;
  preferredTopic: string;
  matchedWith?: string | null;
  matchedAt?: Date | null;
  createdAt?: Date | null;
};

export type InsertUserReport = typeof userReports.$inferInsert;
export type InsertPrivateConversation = typeof privateConversations.$inferInsert;
export type InsertPrivateMessage = typeof privateMessages.$inferInsert;
export type InsertUserAchievement = typeof userAchievements.$inferInsert;
export type InsertConversationFavorite = typeof conversationFavorites.$inferInsert;
export type InsertRoomBookmark = typeof roomBookmarks.$inferInsert;
export type InsertUserInteraction = typeof userInteractions.$inferInsert;
export type InsertCommunityEvent = typeof communityEvents.$inferInsert;