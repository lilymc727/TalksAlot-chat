export const TOPIC_CATEGORIES = {
  "Life & Personal": {
    emoji: "🌟",
    color: "from-blue-400 to-purple-500",
    topics: [
      "Daily Life Stories", "Personal Growth", "Life Transitions", "Family Dynamics",
      "Childhood Memories", "Dreams & Goals", "Life Lessons", "Milestone Moments"
    ]
  },
  "Relationships": {
    emoji: "💕",
    color: "from-pink-400 to-rose-500", 
    topics: [
      "Dating Stories", "Friendship Challenges", "Family Relationships", "Love Languages",
      "Breakup Recovery", "Communication Tips", "Relationship Advice", "Single Life"
    ]
  },
  "Mental Health & Healing": {
    emoji: "🌱",
    color: "from-green-400 to-emerald-500",
    topics: [
      "Anxiety & Depression", "Therapy Experiences", "Self-Care Routines", "Healing Journey",
      "Mindfulness & Meditation", "Boundary Setting", "Trauma Recovery", "Mental Health Resources"
    ]
  },
  "Career & Work": {
    emoji: "💼",
    color: "from-indigo-400 to-blue-500",
    topics: [
      "Career Changes", "Workplace Drama", "Job Interviews", "Work-Life Balance",
      "Entrepreneurship", "Professional Growth", "Office Politics", "Side Hustles"
    ]
  },
  "Hobbies & Interests": {
    emoji: "🎨",
    color: "from-purple-400 to-pink-500",
    topics: [
      "Music & Concerts", "Movies & TV Shows", "Books & Reading", "Art & Creativity",
      "Gaming", "Sports", "Cooking & Food", "Travel Adventures"
    ]
  },
  "Philosophy & Deep Thoughts": {
    emoji: "🤔",
    color: "from-gray-500 to-slate-600",
    topics: [
      "Life's Meaning", "Existential Questions", "Spiritual Beliefs", "Moral Dilemmas",
      "Future of Humanity", "Consciousness", "Free Will", "Reality & Perception"
    ]
  },
  "Current Events & Society": {
    emoji: "🌍",
    color: "from-teal-400 to-cyan-500",
    topics: [
      "Social Issues", "Politics & Government", "Environmental Concerns", "Technology Impact",
      "Cultural Trends", "Global Events", "Local Community", "Social Justice"
    ]
  },
  "Fun & Random": {
    emoji: "🎉",
    color: "from-yellow-400 to-orange-500",
    topics: [
      "Random Thoughts", "Conspiracy Theories", "Weird Dreams", "Funny Stories",
      "Would You Rather", "Unpopular Opinions", "Shower Thoughts", "Strange Encounters"
    ]
  }
} as const;

export const CONVERSATION_PREFERENCES = [
  "Quick Check-ins (5-15 mins)",
  "Medium Chats (30-60 mins)", 
  "Deep Dives (1+ hours)",
  "Voice Conversations",
  "Text-Only Chats",
  "Video Calls",
  "Group Discussions",
  "One-on-One Only",
  "Advice Seeking",
  "Advice Giving",
  "Just Venting",
  "Active Listening",
  "Debate & Discussion",
  "Emotional Support",
  "Casual & Light",
  "Serious & Deep"
] as const;

export type TopicCategory = keyof typeof TOPIC_CATEGORIES;
export type ConversationPreference = typeof CONVERSATION_PREFERENCES[number];