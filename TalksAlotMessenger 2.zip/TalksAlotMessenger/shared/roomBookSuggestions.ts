export const ROOM_BOOK_CATEGORIES = {
  'Fun Chatters': 'humor, light reads, feel-good stories',
  'Deep Thinkers': 'philosophy, psychology, thought-provoking non-fiction',
  'Mental Health': 'mental wellness, therapy, self-help, healing',
  'Career Mentoring': 'professional development, leadership, business skills',
  'Entrepreneurs Hub': 'startup guides, business strategy, innovation',
  'LGBTQIA+ Community': 'LGBTQIA+ authors, identity, representation',
  'Cannabis Friendly': 'cannabis culture, wellness, alternative medicine',
  'Healing Hearts': 'trauma recovery, emotional healing, resilience',
  'Breaking Cycles (20s)': 'generational healing, young adult growth, family dynamics',
  'Wisdom & Healing': 'life wisdom, elder perspectives, spiritual growth',
  'Sacred Space': 'spirituality, meditation, universal laws, consciousness',
  'Dating & Relationships': 'love advice, relationship psychology, dating guides',
  'Animal Lovers': 'animal behavior, veterinary, nature conservation',
  'Travel Stories': 'travel memoirs, cultural exploration, adventure',
  'Foodies United': 'cookbooks, food culture, culinary memoirs',
  'Music Corner': 'music history, artist biographies, sound theory',
  'Gaming Zone': 'game development, esports, gaming culture',
  'College Years': 'student life, academic success, career planning',
  'Empty Nesters': 'life transitions, rediscovering purpose, midlife growth',
  'Language Exchange': 'language learning, cultural understanding, communication',
  'Holiday Chatter': 'seasonal traditions, cultural celebrations, holiday stories'
} as const;

export const getRecommendedBooks = (roomName: string) => {
  const recommendations: Record<string, Array<{title: string, author: string, reason: string}>> = {
    'Mental Health': [
      { title: 'The Body Keeps the Score', author: 'Bessel van der Kolk', reason: 'Essential reading on trauma and healing' },
      { title: 'Atomic Habits', author: 'James Clear', reason: 'Building healthy mental habits' },
      { title: 'Self-Compassion', author: 'Kristin Neff', reason: 'Learning to be kind to yourself' }
    ],
    'Career Mentoring': [
      { title: 'Radical Candor', author: 'Kim Scott', reason: 'Essential leadership communication' },
      { title: 'The 7 Habits of Highly Effective People', author: 'Stephen Covey', reason: 'Timeless productivity principles' },
      { title: 'Dare to Lead', author: 'Brené Brown', reason: 'Vulnerable leadership in modern workplace' }
    ],
    'Entrepreneurs Hub': [
      { title: 'The Lean Startup', author: 'Eric Ries', reason: 'Startup methodology bible' },
      { title: 'Zero to One', author: 'Peter Thiel', reason: 'Building monopolies and innovation' },
      { title: 'The Mom Test', author: 'Rob Fitzpatrick', reason: 'Customer validation techniques' }
    ],
    'Sacred Space': [
      { title: 'The Power of Now', author: 'Eckhart Tolle', reason: 'Present moment awareness' },
      { title: 'The Untethered Soul', author: 'Michael Singer', reason: 'Understanding consciousness' },
      { title: 'Big Magic', author: 'Elizabeth Gilbert', reason: 'Creative living and inspiration' }
    ],
    'Breaking Cycles (20s)': [
      { title: 'Adult Children of Emotionally Immature Parents', author: 'Lindsay Gibson', reason: 'Understanding family patterns' },
      { title: 'The Gifts of Imperfection', author: 'Brené Brown', reason: 'Embracing vulnerability and authenticity' },
      { title: 'Set Boundaries, Find Peace', author: 'Nedra Glover Tawwab', reason: 'Healthy relationship boundaries' }
    ]
  };
  
  return recommendations[roomName] || [];
};