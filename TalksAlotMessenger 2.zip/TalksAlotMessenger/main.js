// TalksAlot Main Entry Point for Replit
console.log("🚀 Starting TalksAlot server...");

// Import and start the app.js server
require('./app.js');

console.log("✅ TalksAlot is ready!");