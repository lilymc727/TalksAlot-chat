#!/usr/bin/env node

const express = require('express');
const path = require('path');
const { createServer } = require('http');

// Use tsx to load TypeScript files
const { register } = require('tsx/esm');
register();

const app = express();
const PORT = process.env.PORT || 3000;

console.log('Starting TalksAlot production server...');
console.log('Environment:', process.env.NODE_ENV || 'development');
console.log('Port:', PORT);
console.log('Database URL available:', !!process.env.DATABASE_URL);
console.log('Replit domains:', process.env.REPLIT_DOMAINS);

// Trust proxy for Replit deployment
app.set('trust proxy', 1);

// Parse JSON and form data
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files from both dist (Vite build) and public
app.use(express.static(path.join(__dirname, 'dist')));
app.use(express.static(path.join(__dirname, 'public')));

async function initializeServer() {
  try {
    // Load authentication system
    const { setupAuth, isAuthenticated } = await import('./server/replitAuth.ts');
    const { DatabaseStorage } = await import('./server/database-storage.ts');
    
    console.log('Setting up Replit authentication...');
    
    // Initialize database storage
    const storage = new DatabaseStorage();
    
    // Setup Replit Auth with all required routes
    await setupAuth(app);
    
    console.log('Authentication setup complete');
    
    // Auth status endpoint
    app.get('/api/auth/user', isAuthenticated, async (req, res) => {
      try {
        const userId = req.user.claims.sub;
        const user = await storage.getUser(userId);
        
        if (!user) {
          // Create user if doesn't exist
          const newUser = await storage.upsertUser({
            id: userId,
            email: req.user.claims.email,
            firstName: req.user.claims.first_name,
            lastName: req.user.claims.last_name,
            profileImageUrl: req.user.claims.profile_image_url,
          });
          return res.json(newUser);
        }
        
        res.json(user);
      } catch (error) {
        console.error("Error fetching user:", error);
        res.status(500).json({ message: "Failed to fetch user" });
      }
    });
    
    // Chat API routes (protected)
    app.get('/api/rooms', isAuthenticated, async (req, res) => {
      try {
        const rooms = await storage.getAllChatRooms();
        res.json(rooms);
      } catch (error) {
        console.error("Error fetching rooms:", error);
        res.status(500).json({ message: "Failed to fetch rooms" });
      }
    });
    
    app.get('/api/rooms/:id', isAuthenticated, async (req, res) => {
      try {
        const room = await storage.getChatRoomById(req.params.id);
        if (!room) {
          return res.status(404).json({ message: "Room not found" });
        }
        res.json(room);
      } catch (error) {
        console.error("Error fetching room:", error);
        res.status(500).json({ message: "Failed to fetch room" });
      }
    });
    
    app.get('/api/rooms/:id/messages', isAuthenticated, async (req, res) => {
      try {
        const messages = await storage.getMessagesByRoomId(req.params.id);
        res.json(messages);
      } catch (error) {
        console.error("Error fetching messages:", error);
        res.status(500).json({ message: "Failed to fetch messages" });
      }
    });
    
    app.post('/api/messages', isAuthenticated, async (req, res) => {
      try {
        const userId = req.user.claims.sub;
        const user = await storage.getUser(userId);
        
        const messageData = {
          ...req.body,
          userId: userId,
          userName: user?.name || user?.firstName || 'Anonymous'
        };
        
        const message = await storage.createMessage(messageData);
        res.status(201).json(message);
      } catch (error) {
        console.error("Error creating message:", error);
        res.status(500).json({ message: "Failed to create message" });
      }
    });
    
    // User profile routes
    app.get('/api/users/me', isAuthenticated, async (req, res) => {
      try {
        const userId = req.user.claims.sub;
        const user = await storage.getUser(userId);
        res.json(user);
      } catch (error) {
        console.error("Error fetching user profile:", error);
        res.status(500).json({ message: "Failed to fetch user profile" });
      }
    });
    
    app.patch('/api/users/me', isAuthenticated, async (req, res) => {
      try {
        const userId = req.user.claims.sub;
        const updatedUser = await storage.updateUser(userId, req.body);
        res.json(updatedUser);
      } catch (error) {
        console.error("Error updating user profile:", error);
        res.status(500).json({ message: "Failed to update user profile" });
      }
    });
    
    console.log('API routes setup complete');
    
  } catch (error) {
    console.error('Authentication setup failed:', error);
    console.log('Running in fallback mode without authentication');
  }
  
  // Health check endpoint (always available)
  app.get('/health', (req, res) => {
    res.status(200).json({
      status: 'healthy',
      app: 'TalksAlot',
      timestamp: new Date().toISOString(),
      port: PORT,
      auth: !!process.env.REPLIT_DOMAINS ? 'enabled' : 'disabled',
      database: !!process.env.DATABASE_URL ? 'connected' : 'disconnected'
    });
  });
  
  // Root route - serve app or landing page
  app.get('/', (req, res) => {
    // Check if user is authenticated
    if (req.isAuthenticated && req.isAuthenticated()) {
      // Serve the main app
      res.sendFile(path.join(__dirname, 'dist', 'index.html'), (err) => {
        if (err) {
          res.sendFile(path.join(__dirname, 'public', 'index.html'), (fallbackErr) => {
            if (fallbackErr) {
              res.send(getAuthenticatedFallbackHTML());
            }
          });
        }
      });
    } else {
      // Serve landing page for non-authenticated users
      res.sendFile(path.join(__dirname, 'public', 'landing.html'), (err) => {
        if (err) {
          res.send(getLandingPageHTML());
        }
      });
    }
  });
  
  // Protected app routes (SPA routing)
  app.get('/app/*', (req, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.redirect('/api/login');
    }
    
    res.sendFile(path.join(__dirname, 'dist', 'index.html'), (err) => {
      if (err) {
        res.sendFile(path.join(__dirname, 'public', 'index.html'), (fallbackErr) => {
          if (fallbackErr) {
            res.status(404).send('App not found');
          }
        });
      }
    });
  });
  
  // Catch-all route for SPA
  app.get('*', (req, res) => {
    // If user is authenticated, serve the app
    if (req.isAuthenticated && req.isAuthenticated()) {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'), (err) => {
        if (err) {
          res.sendFile(path.join(__dirname, 'public', 'index.html'), (fallbackErr) => {
            if (fallbackErr) {
              res.status(404).send('Page not found');
            }
          });
        }
      });
    } else {
      // Redirect unauthenticated users to login
      res.redirect('/api/login');
    }
  });
  
  console.log('Route setup complete');
}

function getLandingPageHTML() {
  return `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TalksAlot - Find Your Conversation Tribe</title>
        <meta name="description" content="A mature community for adults who love meaningful conversation. Join verified users in 50+ themed chat rooms for authentic connections.">
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            background: linear-gradient(135deg, #0ea5e9 0%, #06b6d4 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #334155;
          }
          .container {
            background: white;
            padding: 3rem;
            border-radius: 24px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.15);
            max-width: 600px;
            text-align: center;
            margin: 2rem;
          }
          h1 {
            color: #0ea5e9;
            font-size: 3.5rem;
            font-weight: 800;
            margin-bottom: 1rem;
            letter-spacing: -0.02em;
          }
          .tagline {
            color: #64748b;
            font-size: 1.3rem;
            margin-bottom: 2rem;
            line-height: 1.6;
            font-weight: 500;
          }
          .welcome-text {
            background: #f8fafc;
            padding: 2rem;
            border-radius: 16px;
            margin-bottom: 2rem;
            border-left: 6px solid #0ea5e9;
          }
          .welcome-text h2 {
            color: #0f172a;
            font-size: 1.5rem;
            margin-bottom: 1rem;
            font-weight: 700;
          }
          .welcome-text p {
            color: #475569;
            line-height: 1.7;
            margin-bottom: 1rem;
          }
          .features {
            display: grid;
            gap: 1rem;
            margin-bottom: 2rem;
            text-align: left;
          }
          .feature {
            background: #f1f5f9;
            padding: 1rem;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 0.75rem;
          }
          .feature-icon {
            width: 20px;
            height: 20px;
            background: #0ea5e9;
            border-radius: 50%;
            flex-shrink: 0;
          }
          .auth-button {
            display: inline-block;
            padding: 16px 32px;
            background: #0ea5e9;
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(14, 165, 233, 0.3);
          }
          .auth-button:hover {
            background: #0284c7;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(14, 165, 233, 0.4);
          }
          .security-note {
            margin-top: 2rem;
            padding: 1rem;
            background: #ecfdf5;
            border-radius: 8px;
            border: 1px solid #d1fae5;
            font-size: 0.9rem;
            color: #065f46;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>TalksAlot</h1>
          <p class="tagline">A mature community for adults who love meaningful conversation</p>
          
          <div class="welcome-text">
            <h2>Have people said you talk too much?</h2>
            <p><strong>You've found your tribe!</strong></p>
            <p>Welcome to a safe space where being chatty is celebrated, not criticized. Join thousands of verified conversation enthusiasts in our 50+ themed chat rooms.</p>
          </div>
          
          <div class="features">
            <div class="feature">
              <div class="feature-icon"></div>
              <span><strong>Verified Community:</strong> Every member authenticated through Replit</span>
            </div>
            <div class="feature">
              <div class="feature-icon"></div>
              <span><strong>50+ Chat Rooms:</strong> From deep philosophy to casual chatter</span>
            </div>
            <div class="feature">
              <div class="feature-icon"></div>
              <span><strong>Safe Environment:</strong> Zero tolerance for harassment</span>
            </div>
            <div class="feature">
              <div class="feature-icon"></div>
              <span><strong>Real-Time Messaging:</strong> Connect instantly with like-minded talkers</span>
            </div>
          </div>
          
          <a href="/api/login" class="auth-button">
            Join the Community
          </a>
          
          <div class="security-note">
            <strong>🔒 Secure & Private:</strong> All users verified through Replit authentication. Your conversations are protected in our encrypted, harassment-free environment.
          </div>
        </div>
      </body>
    </html>
  `;
}

function getAuthenticatedFallbackHTML() {
  return `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>TalksAlot - Loading...</title>
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #0ea5e9, #06b6d4);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
          }
          .loading {
            background: white;
            padding: 2rem;
            border-radius: 16px;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
          }
          .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid #f3f4f6;
            border-top: 4px solid #0ea5e9;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
          }
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        </style>
      </head>
      <body>
        <div class="loading">
          <div class="spinner"></div>
          <h2 style="color: #0ea5e9; margin-bottom: 0.5rem;">Loading TalksAlot...</h2>
          <p style="color: #64748b;">Welcome back to your conversation community!</p>
        </div>
        <script>
          // Auto-refresh after 3 seconds if app doesn't load
          setTimeout(() => {
            window.location.reload();
          }, 3000);
        </script>
      </body>
    </html>
  `;
}

// Initialize server
initializeServer().then(() => {
  const httpServer = createServer(app);
  
  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 TalksAlot server running on port ${PORT}`);
    console.log(`📊 Health check: http://0.0.0.0:${PORT}/health`);
    console.log(`🌐 App URL: http://0.0.0.0:${PORT}/`);
    console.log(`🔐 Login URL: http://0.0.0.0:${PORT}/api/login`);
    console.log('✅ Server ready for deployment');
  });
  
  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully');
    httpServer.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  });
  
  process.on('SIGINT', () => {
    console.log('Received SIGINT, shutting down gracefully');
    httpServer.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  });
  
}).catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});