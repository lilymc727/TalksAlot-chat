import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./client/src/**/*.{js,ts,jsx,tsx}",
    "./client/index.html"
  ],
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Custom relaxing colors
        ocean: {
          50: "hsl(195, 100%, 97%)",
          100: "hsl(190, 80%, 92%)",
          200: "hsl(185, 70%, 85%)",
          300: "hsl(180, 65%, 75%)",
          400: "hsl(175, 60%, 65%)",
          500: "hsl(170, 75%, 45%)",
          600: "hsl(165, 80%, 35%)",
          700: "hsl(160, 85%, 25%)",
          800: "hsl(155, 90%, 18%)",
          900: "hsl(150, 95%, 12%)",
        },
        mint: {
          50: "hsl(165, 60%, 95%)",
          100: "hsl(160, 55%, 88%)",
          200: "hsl(155, 50%, 78%)",
          300: "hsl(150, 45%, 68%)",
          400: "hsl(145, 50%, 58%)",
          500: "hsl(140, 55%, 48%)",
          600: "hsl(135, 60%, 38%)",
          700: "hsl(130, 65%, 28%)",
          800: "hsl(125, 70%, 20%)",
          900: "hsl(120, 75%, 15%)",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  plugins: [],
};

export default config;