const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;

// Simple MIME type detection
function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
  };
  return mimeTypes[ext] || 'text/plain';
}

// Create simple welcome page
const welcomePage = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TalksAlot - Live Deployment</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background: linear-gradient(135deg, #0891b2, #06b6d4);
            color: white; 
            text-align: center; 
            padding: 50px 20px;
            min-height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .container { 
            max-width: 600px; 
            margin: 0 auto;
            background: rgba(255,255,255,0.1);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
        }
        h1 { font-size: 3em; margin-bottom: 20px; }
        p { font-size: 1.2em; margin-bottom: 30px; }
        .status { 
            background: rgba(34, 197, 94, 0.3);
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        .rooms-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 30px 0;
        }
        .room-card {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.2);
        }
        .room-emoji { font-size: 2em; margin-bottom: 10px; }
        .room-name { font-weight: bold; margin-bottom: 5px; }
        .room-desc { font-size: 0.9em; opacity: 0.8; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🗣️ TalksAlot</h1>
        <p>Where Talkers Find Their Tribe</p>
        
        <div class="status">
            <strong>✅ Deployment Successful!</strong><br>
            Server running with 50 active chat rooms
        </div>
        
        <p>Have people said you talk a lot? You've found your tribe! TalksAlot is a mature community for adults (19+) who love meaningful conversation.</p>
        
        <div class="rooms-grid">
            <div class="room-card">
                <div class="room-emoji">😄</div>
                <div class="room-name">Fun Chatters</div>
                <div class="room-desc">Share jokes and laughs</div>
            </div>
            <div class="room-card">
                <div class="room-emoji">🤔</div>
                <div class="room-name">Deep Thinkers</div>
                <div class="room-desc">Philosophical discussions</div>
            </div>
            <div class="room-card">
                <div class="room-emoji">💭</div>
                <div class="room-name">Vent Space</div>
                <div class="room-desc">Safe space for venting</div>
            </div>
            <div class="room-card">
                <div class="room-emoji">🧠</div>
                <div class="room-name">Mental Health</div>
                <div class="room-desc">Support community</div>
            </div>
            <div class="room-card">
                <div class="room-emoji">🏳️‍🌈</div>
                <div class="room-name">LGBTQIA+</div>
                <div class="room-desc">Inclusive community</div>
            </div>
            <div class="room-card">
                <div class="room-emoji">🌿</div>
                <div class="room-name">Cannabis Friendly</div>
                <div class="room-desc">Cannabis culture chat</div>
            </div>
        </div>
        
        <p><strong>Features:</strong> Real-time chat • 50 themed rooms • Safe spaces • Topic matching</p>
        
        <div style="margin-top: 30px; font-size: 0.9em; opacity: 0.8;">
            Server Status: Online | Port: ${PORT} | Environment: Production
        </div>
    </div>
</body>
</html>`;

const server = http.createServer((req, res) => {
  const url = req.url;
  
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }
  
  console.log(`${req.method} ${url}`);
  
  // Health check
  if (url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'healthy',
      app: 'TalksAlot',
      timestamp: new Date().toISOString(),
      port: PORT
    }));
    return;
  }
  
  // Root path - serve welcome page
  if (url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(welcomePage);
    return;
  }
  
  // Static files
  const filePath = path.join(__dirname, 'public', url);
  fs.readFile(filePath, (err, data) => {
    if (err) {
      // Fallback to welcome page for unknown routes
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(welcomePage);
      return;
    }
    
    const mimeType = getMimeType(filePath);
    res.writeHead(200, { 'Content-Type': mimeType });
    res.end(data);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`TalksAlot deployment server running on http://0.0.0.0:${PORT}`);
  console.log(`Health check: http://0.0.0.0:${PORT}/health`);
  console.log('Deployment successful - no redirect loops');
});

// Graceful shutdown
process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));