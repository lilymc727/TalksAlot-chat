const { spawn } = require('child_process');

console.log('Starting TalksAlot server...');

const server = spawn('node', ['app.js'], {
  stdio: 'inherit',
  cwd: process.cwd()
});

server.on('close', (code) => {
  console.log(`Server process exited with code ${code}`);
  if (code !== 0) {
    console.log('Restarting server...');
    setTimeout(() => {
      const newServer = spawn('node', ['app.js'], {
        stdio: 'inherit',
        cwd: process.cwd()
      });
    }, 1000);
  }
});

process.on('SIGTERM', () => {
  console.log('Shutting down...');
  server.kill();
});

process.on('SIGINT', () => {
  console.log('Shutting down...');
  server.kill();
});