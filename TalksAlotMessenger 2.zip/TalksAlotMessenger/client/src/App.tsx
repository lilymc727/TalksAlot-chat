import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Router, Route, Switch } from "wouter";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import HomePage from "@/pages/HomePage";
import LandingPage from "@/pages/LandingPage";
import ChatRoomPage from "@/pages/ChatRoomPage";
import ProfilePage from "@/pages/ProfilePage";
import TestimonialsPage from "@/pages/TestimonialsPage";
import GuidelinesPage from "@/pages/GuidelinesPage";
import ContactCreatorPage from "@/pages/ContactCreatorPage";
import { ToastProvider } from "@/components/ToastProvider";
import "./index.css";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={LandingPage} />
      ) : (
        <>
          <Route path="/" component={HomePage} />
          <Route path="/room/:roomId" component={ChatRoomPage} />
          <Route path="/profile" component={ProfilePage} />
          <Route path="/stories" component={TestimonialsPage} />
          <Route path="/guidelines" component={GuidelinesPage} />
          <Route path="/contact" component={ContactCreatorPage} />
        </>
      )}
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-teal-100 dark:from-gray-900 dark:to-cyan-900">
          <Router />
        </div>
      </ToastProvider>
    </QueryClientProvider>
  );
}

export default App;