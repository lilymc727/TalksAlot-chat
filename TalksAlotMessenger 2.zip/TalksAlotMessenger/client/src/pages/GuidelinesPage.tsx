import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Heart, Shield, MessageCircle, Users } from "lucide-react";

export default function GuidelinesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">
              Community Guidelines
            </h1>
            <p className="text-gray-600 mt-1">
              How we create a safe space for enthusiastic talkers
            </p>
          </div>
        </div>

        {/* Welcome Message */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-teal-400 to-cyan-400 rounded-full flex items-center justify-center text-white text-2xl mx-auto mb-4">
              💬
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">
              Welcome to Your Tribe!
            </h2>
            <p className="text-gray-600">
              These guidelines help us maintain a community where talking a lot is celebrated, not criticized. 
              This isn't primarily a dating app - it's for conversation lovers who feel like burdens to find their tribe.
            </p>
          </div>
        </div>

        {/* Core Values */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center mb-4">
              <Heart className="w-6 h-6 text-red-500 mr-3" />
              <h3 className="text-xl font-semibold">Celebrate Conversation</h3>
            </div>
            <p className="text-gray-700">
              We believe loving to talk is a gift. Long conversations, detailed stories, and enthusiastic 
              discussions are not just welcome - they're the heart of our community.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center mb-4">
              <Shield className="w-6 h-6 text-blue-500 mr-3" />
              <h3 className="text-xl font-semibold">Every Room is a Safe Space</h3>
            </div>
            <p className="text-gray-700">
              TalksAlot has ZERO tolerance for negativity, harassment, trolling, or disrespect. Every single room - 
              from casual chat to healing spaces - is actively protected. We don't allow anyone to infiltrate 
              with negativity or make others feel unwelcome for their enthusiasm.
            </p>
          </div>
        </div>

        {/* Detailed Guidelines */}
        <div className="space-y-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <MessageCircle className="w-5 h-5 text-teal-600 mr-2" />
              Conversation Guidelines
            </h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-gray-800 mb-2">✅ Do:</h4>
                <ul className="text-sm text-gray-700 space-y-1 ml-4">
                  <li>• Share your stories - the longer, the better!</li>
                  <li>• Ask follow-up questions - we love curiosity</li>
                  <li>• Express enthusiasm about your interests</li>
                  <li>• Support others who get excited about topics</li>
                  <li>• Use voice/video chat for deeper connections</li>
                  <li>• Remember that "tell me more" are magic words here</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-gray-800 mb-2">❌ Don't:</h4>
                <ul className="text-sm text-gray-700 space-y-1 ml-4">
                  <li>• Tell someone they talk too much (seriously!)</li>
                  <li>• Dismiss someone's enthusiasm</li>
                  <li>• Rush conversations or push for "quick answers"</li>
                  <li>• Share personal information of other members</li>
                  <li>• Use hate speech or discriminatory language</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <Users className="w-5 h-5 text-green-600 mr-2" />
              Zero Tolerance for Negativity
            </h3>
            <div className="space-y-3 text-gray-700">
              <p>
                <strong>Protected Environment:</strong> Every room in TalksAlot is actively moderated to prevent 
                negativity, harassment, trolling, or any behavior that makes others feel unwelcome. We don't 
                allow infiltration by people who want to bring others down.
              </p>
              <p>
                <strong>Immediate Action:</strong> Negative behavior results in immediate removal. We prioritize 
                protecting our community's positive atmosphere over giving troublemakers "second chances."
              </p>
              <p>
                <strong>Safe Expression:</strong> Whether you're sharing excitement about beetles, discussing 
                deep philosophical thoughts, or opening up about personal struggles - you can do so knowing 
                this space actively protects your right to be heard without judgment.
              </p>
              <p>
                <strong>Community Standards:</strong> Being enthusiastic about conversation is celebrated. 
                Making others feel small, unwelcome, or "too much" is absolutely prohibited.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <Users className="w-5 h-5 text-green-600 mr-2" />
              Respect & Privacy
            </h3>
            <div className="space-y-3 text-gray-700">
              <p>
                <strong>Age Verification:</strong> This is a 19+ community for mature conversations. 
                We verify ages to ensure appropriate interactions.
              </p>
              <p>
                <strong>Consent in Conversations:</strong> If someone needs to step away from a conversation, 
                respect that boundary. Not everyone is available for 3-hour chats at all times.
              </p>
              <p>
                <strong>Mental Health Support:</strong> Our healing rooms require extra care. Listen without 
                trying to "fix," avoid giving medical advice, and encourage professional help when appropriate.
              </p>
              <p>
                <strong>Privacy:</strong> What's shared in TalksAlot stays in TalksAlot. Don't screenshot 
                private conversations or share personal details outside the platform.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-xl font-semibold mb-4">Our Mission & Community Purpose</h3>
            <div className="space-y-3 text-gray-700">
              <p>
                <strong>Not Primarily Dating:</strong> While romance might happen naturally, TalksAlot exists to connect 
                conversation enthusiasts who often feel like burdens to non-talkers. We're about friendship, intellectual 
                connection, emotional support, and celebrating the joy of deep dialogue.
              </p>
              <p>
                <strong>Everyone Deserves to Be Heard:</strong> Our core mission is ensuring that people who love to talk 
                never feel "too much" again. Whether you need someone to listen to your daily adventures, dive deep into 
                philosophical discussions, or just appreciate your storytelling enthusiasm - you belong here.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-xl font-semibold mb-4">Active Protection & Moderation</h3>
            <div className="space-y-3 text-gray-700">
              <p>
                <strong>Immediate Response:</strong> We actively monitor all rooms and respond immediately to 
                negativity, harassment, or disrespectful behavior. Report anything that makes you uncomfortable - 
                we take every report seriously and act fast.
              </p>
              <p>
                <strong>Community Defense:</strong> Our moderation prioritizes protecting enthusiastic talkers 
                over accommodating negative people. If someone can't respect our positive atmosphere, they don't 
                belong here.
              </p>
              <p className="text-sm">
                <strong>Remember:</strong> Being enthusiastic about conversation is never against the rules. 
                Bringing negativity or making others feel unwelcome always is.
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-yellow-50 to-amber-50 border border-yellow-200 rounded-xl p-6">
            <h3 className="text-xl font-semibold mb-3 text-yellow-800">Fair Warning Reminder</h3>
            <p className="text-yellow-700 mb-2">
              If you're someone who prefers quick, surface-level chats, you might find our community 
              intensity overwhelming. That's okay! We just want everyone to know what they're signing up for.
            </p>
            <p className="text-sm text-yellow-600">
              We're the people who turn "How was your day?" into a 2-hour deep dive. Consider yourself warned! 😄
            </p>
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl p-8 mt-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-2">Ready to Talk Your Heart Out?</h3>
          <p className="mb-4 opacity-90">
            By joining TalksAlot, you agree to help us maintain a community where conversation is celebrated.
          </p>
          <Link href="/">
            <Button className="bg-white text-teal-600 hover:bg-gray-100">
              Start Conversations
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}