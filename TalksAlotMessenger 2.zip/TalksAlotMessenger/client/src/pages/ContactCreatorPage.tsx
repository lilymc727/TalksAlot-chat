import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { MessageCircle, Send, Heart, Mail, User, MessageSquare } from "lucide-react";
import { useToastContext } from "@/components/ToastProvider";
import { SecurityBadge } from "@/components/SecurityBadge";
import { apiRequest } from "@/lib/queryClient";

export default function ContactCreatorPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
    messageType: "general"
  });
  const { toast } = useToastContext();

  const sendMessageMutation = useMutation({
    mutationFn: (data: typeof formData) => apiRequest("/api/contact-creator", {
      method: "POST",
      body: JSON.stringify(data),
    }),
    onSuccess: () => {
      toast({
        title: "Message Sent!",
        description: "Thanks for reaching out! I'll get back to you soon.",
      });
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: "",
        messageType: "general"
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessageMutation.mutate(formData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-teal-50 to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <MessageCircle className="h-12 w-12 text-cyan-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Talk to Me Directly</h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Have feedback, ideas, or just want to chat? I'd love to hear from you!
          </p>
        </div>

        {/* Creator Introduction */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 max-w-4xl mx-auto mb-8">
          <div className="flex items-start space-x-6">
            {/* Creator Photo - You can replace this with your actual photo */}
            <div className="flex-shrink-0">
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-cyan-200 shadow-lg">
                {/* TODO: Replace with your actual photo */}
                <img 
                  src="/api/placeholder/96/96" 
                  alt="Creator photo"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    // Fallback to emoji if image fails to load
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.nextElementSibling.style.display = 'flex';
                  }}
                />
                <div className="w-full h-full bg-gradient-to-r from-cyan-400 to-teal-400 rounded-full flex items-center justify-center text-2xl font-bold text-white" style={{display: 'none'}}>
                  💬
                </div>
              </div>
            </div>
            <div className="flex-1">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                Hey there, fellow talker!
              </h3>
              <div className="text-gray-700 dark:text-gray-300 space-y-3">
                <p>
                  I'm the creator of TalksAlot, and just like you, I've been told "you talk too much" 
                  countless times. This platform exists because I believe our love for conversation 
                  is a gift, not a burden.
                </p>
                <p>
                  Whether you want to share your experience, suggest new features, report issues, 
                  or just have a heart-to-heart conversation about what it's like to be a "talker" 
                  in a world that sometimes doesn't appreciate it - I'm here to listen.
                </p>
                <p className="font-medium text-cyan-600 dark:text-cyan-400">
                  Your voice matters, and I genuinely want to hear what you have to say. 💙
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 max-w-2xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Message Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                What's this about?
              </label>
              <select
                name="messageType"
                value={formData.messageType}
                onChange={handleInputChange}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                required
              >
                <option value="general">General conversation</option>
                <option value="feedback">Platform feedback</option>
                <option value="feature-request">Feature suggestion</option>
                <option value="bug-report">Bug report</option>
                <option value="community-idea">Community idea</option>
                <option value="personal-story">Personal story/experience</option>
                <option value="support">Need support</option>
                <option value="partnership">Partnership/collaboration</option>
              </select>
            </div>

            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Your Name
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="What should I call you?"
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Email Address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="So I can write back to you"
                required
              />
            </div>

            {/* Subject */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Subject
              </label>
              <input
                type="text"
                name="subject"
                value={formData.subject}
                onChange={handleInputChange}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="What's on your mind?"
                required
              />
            </div>

            {/* Message */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Your Message
              </label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleInputChange}
                rows={6}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent dark:bg-gray-700 dark:text-white resize-none"
                placeholder="Don't hold back - this is your space to talk as much as you want! Share your thoughts, experiences, ideas, or whatever's on your heart. I read every single message personally."
                required
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Feel free to write as much as you need - I actually love long messages!
              </p>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full bg-cyan-600 hover:bg-cyan-700 text-white py-3 text-lg font-medium flex items-center justify-center space-x-2"
              disabled={sendMessageMutation.isPending}
            >
              {sendMessageMutation.isPending ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Sending...</span>
                </>
              ) : (
                <>
                  <Send className="h-5 w-5" />
                  <span>Send Message</span>
                </>
              )}
            </Button>
          </form>
        </div>

        {/* Response Promise */}
        <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20 border border-emerald-200 dark:border-emerald-800 rounded-xl p-6 max-w-2xl mx-auto mt-8">
          <div className="flex items-center space-x-3 mb-4">
            <Heart className="h-6 w-6 text-emerald-600" />
            <h4 className="font-semibold text-emerald-800 dark:text-emerald-300">
              My Promise to You
            </h4>
          </div>
          <div className="text-emerald-700 dark:text-emerald-300 space-y-2 text-sm">
            <p>• I personally read every single message that comes through</p>
            <p>• I'll respond within 24-48 hours (usually much sooner!)</p>
            <p>• Your message will never feel "too long" - I appreciate detailed thoughts</p>
            <p>• Whether it's feedback, ideas, or just wanting to connect, you matter to me</p>
          </div>
        </div>

        {/* Alternative Contact Methods */}
        <div className="text-center mt-12">
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Prefer a different way to connect?
          </p>
          <div className="flex justify-center space-x-6">
            <Button variant="outline" className="flex items-center space-x-2">
              <Mail className="h-4 w-4" />
              <span>Email directly</span>
            </Button>
            <Button variant="outline" className="flex items-center space-x-2">
              <MessageSquare className="h-4 w-4" />
              <span>Join our feedback room</span>
            </Button>
          </div>
        </div>

        <SecurityBadge />
      </div>
    </div>
  );
}