import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Edit3, Award, Calendar, MessageCircle } from "lucide-react";
import type { User } from "@shared/schema";

export default function ProfilePage() {
  const [, setLocation] = useLocation();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem("talksalot-user");
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  const handleSaveProfile = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!currentUser) return;

    const formData = new FormData(e.currentTarget);
    const interests = formData.get("interests")?.toString().split(",").map(i => i.trim()) || [];
    
    const age = parseInt(formData.get("age")?.toString() || currentUser.age.toString());
    
    const updatedUser = {
      ...currentUser,
      name: formData.get("name")?.toString() || currentUser.name,
      age,
      photo: formData.get("photo")?.toString() || currentUser.photo,
      location: formData.get("location")?.toString() || currentUser.location,
      talkStyle: formData.get("talkStyle")?.toString() as any || currentUser.talkStyle,
      interests,
    };

    setCurrentUser(updatedUser);
    localStorage.setItem("talksalot-user", JSON.stringify(updatedUser));
    setIsEditing(false);
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="mb-4">No profile found</p>
          <Button onClick={() => setLocation("/")}>Go Home</Button>
        </div>
      </div>
    );
  }

  const talkStyleLabels = {
    "fast-talker": "Fast Talker ⚡",
    "storyteller": "Storyteller 📚",
    "jokester": "Jokester 😄",
    "deep-thinker": "Deep Thinker 🤔",
    "listener": "Good Listener 👂",
    "advice-giver": "Advice Giver 💡",
    "funny-loud": "Funny & Loud 📢",
    "real-talker": "Real Talker 💯",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-purple-900 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/")}
            className="mr-3"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl font-bold">Your Profile</h1>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
          {isEditing ? (
            <form onSubmit={handleSaveProfile} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Name</label>
                <input
                  name="name"
                  type="text"
                  defaultValue={currentUser.name}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Age</label>
                <input
                  name="age"
                  type="number"
                  min="18"
                  max="120"
                  defaultValue={currentUser.age}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Profile Photo</label>
                <input
                  name="photo"
                  type="url"
                  defaultValue={currentUser.photo || ""}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Photo URL (optional)"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Location</label>
                <input
                  name="location"
                  type="text"
                  defaultValue={currentUser.location || ""}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="City, State/Country (optional)"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Talk Style</label>
                <select
                  name="talkStyle"
                  defaultValue={currentUser.talkStyle}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="fast-talker">Fast Talker - Quick & Energetic</option>
                  <option value="storyteller">Storyteller - Love long stories</option>
                  <option value="jokester">Jokester - Always cracking jokes</option>
                  <option value="deep-thinker">Deep Thinker - Philosophical</option>
                  <option value="listener">Good Listener - Love to hear others</option>
                  <option value="advice-giver">Advice Giver - Helper & Guide</option>
                  <option value="funny-loud">Funny & Loud - Big personality</option>
                  <option value="real-talker">Real Talker - Keep it authentic</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Interests</label>
                <input
                  name="interests"
                  type="text"
                  defaultValue={currentUser.interests.join(", ")}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="movies, music, travel, cooking..."
                />
                <p className="text-xs text-gray-500 mt-1">Separate with commas</p>
              </div>

              <div className="flex gap-3">
                <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                  Save Changes
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          ) : (
            <div className="space-y-6">
              {/* Profile Info */}
              <div className="text-center">
                <div className="w-24 h-24 rounded-full mx-auto mb-4 overflow-hidden">
                  {currentUser.photo ? (
                    <img 
                      src={currentUser.photo} 
                      alt={currentUser.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        target.nextElementSibling?.classList.remove('hidden');
                      }}
                    />
                  ) : null}
                  <div className={`w-24 h-24 bg-gradient-to-r from-ocean-400 to-mint-400 rounded-full flex items-center justify-center text-3xl text-white font-bold ${currentUser.photo ? 'hidden' : ''}`}>
                    {currentUser.name.charAt(0).toUpperCase()}
                  </div>
                </div>
                <h2 className="text-2xl font-bold mb-2">{currentUser.name}</h2>
                {currentUser.location && (
                  <p className="text-sm text-gray-500 mb-2">📍 {currentUser.location}</p>
                )}
                <p className="text-lg text-ocean-600 dark:text-ocean-400 mb-4">
                  {talkStyleLabels[currentUser.talkStyle]}
                </p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-purple-50 dark:bg-purple-900 rounded-lg p-4">
                  <MessageCircle className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{currentUser.talkStreak}</div>
                  <div className="text-sm text-gray-600 dark:text-gray-300">Talk Streak</div>
                </div>
                <div className="bg-pink-50 dark:bg-pink-900 rounded-lg p-4">
                  <Award className="w-6 h-6 text-pink-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{currentUser.badges.length}</div>
                  <div className="text-sm text-gray-600 dark:text-gray-300">Badges</div>
                </div>
                <div className="bg-blue-50 dark:bg-blue-900 rounded-lg p-4">
                  <Calendar className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold">
                    {Math.floor((Date.now() - new Date(currentUser.joinedAt).getTime()) / (1000 * 60 * 60 * 24))}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-300">Days Here</div>
                </div>
              </div>

              {/* Favorite Topics */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Favorite Topics</h3>
                <div className="flex flex-wrap gap-2">
                  {currentUser.favoriteTopics && currentUser.favoriteTopics.length > 0 ? (
                    currentUser.favoriteTopics.map((topic, index) => (
                      <span
                        key={index}
                        className="bg-ocean-100 dark:bg-ocean-800 text-ocean-700 dark:text-ocean-200 px-3 py-1 rounded-full text-sm"
                      >
                        {topic.replace('-', ' ')}
                      </span>
                    ))
                  ) : (
                    <p className="text-gray-500">No favorite topics selected yet</p>
                  )}
                </div>
              </div>

              {/* Additional Interests */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Other Interests</h3>
                <div className="flex flex-wrap gap-2">
                  {currentUser.interests && currentUser.interests.length > 0 ? (
                    currentUser.interests.map((interest, index) => (
                      <span
                        key={index}
                        className="bg-blue-100 dark:bg-blue-800 text-blue-700 dark:text-blue-200 px-3 py-1 rounded-full text-sm"
                      >
                        {interest}
                      </span>
                    ))
                  ) : (
                    <p className="text-gray-500">No additional interests added yet</p>
                  )}
                </div>
              </div>

              {/* Badges */}
              <div>
                <h3 className="text-lg font-semibold mb-3">Your Badges</h3>
                <div className="flex flex-wrap gap-2">
                  {currentUser.badges.length > 0 ? (
                    currentUser.badges.map((badge, index) => (
                      <span
                        key={index}
                        className="bg-yellow-100 dark:bg-yellow-800 text-yellow-700 dark:text-yellow-200 px-3 py-1 rounded-full text-sm"
                      >
                        🏆 {badge}
                      </span>
                    ))
                  ) : (
                    <p className="text-gray-500">Start chatting to earn badges!</p>
                  )}
                </div>
              </div>

              <Button
                onClick={() => setIsEditing(true)}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                <Edit3 className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}