import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Heart, Star, MessageSquare, Send } from "lucide-react";
import { useToastContext } from "@/components/ToastProvider";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User } from "@shared/schema";

interface Testimonial {
  id: string;
  userName: string;
  userPhoto?: string;
  content: string;
  rating: number;
  category: string;
  createdAt: Date;
}

export default function TestimonialsPage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [newTestimonial, setNewTestimonial] = useState({
    content: "",
    rating: 5,
    category: "connection"
  });
  const { toast } = useToastContext();

  // Mock testimonials data for now
  const testimonials: Testimonial[] = [
    {
      id: "1",
      userName: "Sarah M.",
      content: "I finally found people who don't roll their eyes when I get excited about a topic! The Deep Thinkers room has become my sanctuary.",
      rating: 5,
      category: "connection",
      createdAt: new Date("2024-06-20")
    },
    {
      id: "2", 
      userName: "Mike R.",
      content: "Being told I 'talk too much' used to hurt. Now I realize it's my superpower. The Late Night Venting room saved me during a tough time.",
      rating: 5,
      category: "healing",
      createdAt: new Date("2024-06-18")
    },
    {
      id: "3",
      userName: "Alex K.",
      content: "The Rant Zone is PERFECT. I can get all my thoughts out without judgment. People actually engage and understand!",
      rating: 5,
      category: "expression",
      createdAt: new Date("2024-06-15")
    },
    {
      id: "4",
      userName: "Jamie L.",
      content: "Video chat feature is amazing! Seeing faces while we talk makes conversations so much more meaningful. Found my tribe here!",
      rating: 5,
      category: "community",
      createdAt: new Date("2024-06-12")
    }
  ];

  useEffect(() => {
    const savedUser = localStorage.getItem("talksalot-user");
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);

  const handleSubmitTestimonial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      toast({ 
        title: "Please create a profile first", 
        description: "You need to be logged in to share your experience." 
      });
      return;
    }

    // In a real app, this would save to the backend
    toast({ 
      title: "Thank you!", 
      description: "Your testimonial has been shared with the community." 
    });
    
    setNewTestimonial({ content: "", rating: 5, category: "connection" });
    setShowForm(false);
  };

  const categoryLabels = {
    connection: "Found Connection",
    healing: "Emotional Healing", 
    expression: "Free Expression",
    community: "Community Support",
    growth: "Personal Growth"
  };

  const categoryColors = {
    connection: "bg-blue-100 text-blue-800",
    healing: "bg-green-100 text-green-800",
    expression: "bg-orange-100 text-orange-800", 
    community: "bg-purple-100 text-purple-800",
    growth: "bg-teal-100 text-teal-800"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">
              Community Stories
            </h1>
            <p className="text-gray-600 mt-1">
              Share what TalksAlot has meant to you
            </p>
          </div>
        </div>

        {/* Impact Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-sm text-center">
            <Heart className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-800">247</div>
            <div className="text-sm text-gray-600">Lives Touched</div>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm text-center">
            <MessageSquare className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-800">15,432</div>
            <div className="text-sm text-gray-600">Meaningful Conversations</div>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm text-center">
            <Star className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-800">4.9</div>
            <div className="text-sm text-gray-600">Average Rating</div>
          </div>
        </div>

        {/* Add Testimonial Button */}
        <div className="text-center mb-8">
          <Button 
            onClick={() => setShowForm(!showForm)}
            className="bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700"
          >
            <Heart className="w-4 h-4 mr-2" />
            Share Your Story
          </Button>
        </div>

        {/* Testimonial Form */}
        {showForm && (
          <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h3 className="text-xl font-semibold mb-4">Share Your Experience</h3>
            <form onSubmit={handleSubmitTestimonial} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">What has TalksAlot given you?</label>
                <textarea
                  value={newTestimonial.content}
                  onChange={(e) => setNewTestimonial({ ...newTestimonial, content: e.target.value })}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  rows={4}
                  placeholder="Share how TalksAlot has impacted your life..."
                  required
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Category</label>
                  <select
                    value={newTestimonial.category}
                    onChange={(e) => setNewTestimonial({ ...newTestimonial, category: e.target.value })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  >
                    {Object.entries(categoryLabels).map(([key, label]) => (
                      <option key={key} value={key}>{label}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Rating</label>
                  <select
                    value={newTestimonial.rating}
                    onChange={(e) => setNewTestimonial({ ...newTestimonial, rating: parseInt(e.target.value) })}
                    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  >
                    {[5, 4, 3, 2, 1].map(num => (
                      <option key={num} value={num}>
                        {"★".repeat(num)} ({num} star{num !== 1 ? 's' : ''})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowForm(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" className="bg-teal-600 hover:bg-teal-700">
                  <Send className="w-4 h-4 mr-2" />
                  Share Story
                </Button>
              </div>
            </form>
          </div>
        )}

        {/* Testimonials Grid */}
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-center text-gray-800">
            What Our Community Says
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-teal-400 to-cyan-400 rounded-full flex items-center justify-center text-white font-semibold">
                      {testimonial.userName.charAt(0)}
                    </div>
                    <div>
                      <div className="font-semibold text-gray-800">{testimonial.userName}</div>
                      <div className="flex items-center">
                        {"★".repeat(testimonial.rating).split("").map((star, i) => (
                          <span key={i} className="text-yellow-500">{star}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${categoryColors[testimonial.category as keyof typeof categoryColors]}`}>
                    {categoryLabels[testimonial.category as keyof typeof categoryLabels]}
                  </span>
                </div>
                
                <p className="text-gray-700 leading-relaxed mb-3">
                  "{testimonial.content}"
                </p>
                
                <div className="text-xs text-gray-500">
                  {testimonial.createdAt.toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl p-8 mt-12 text-white text-center">
          <h3 className="text-2xl font-bold mb-2">Ready to Find Your Tribe?</h3>
          <p className="mb-4 opacity-90">
            Join thousands of people who've discovered that talking a lot is actually a superpower.
          </p>
          <Link href="/">
            <Button className="bg-white text-teal-600 hover:bg-gray-100">
              Start Talking Now
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}