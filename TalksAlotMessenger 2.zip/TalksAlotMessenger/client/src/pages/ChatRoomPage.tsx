import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Send, Users, Shield } from "lucide-react";
import { useToastContext } from "@/components/ToastProvider";
import { VideoChat } from "@/components/VideoChat";
import { RambleTimer } from "@/components/RambleTimer";
import { SafetyNotice } from "@/components/SafetyNotice";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ChatRoom, Message, User } from "@shared/schema";

export default function ChatRoomPage() {
  const { roomId } = useParams<{ roomId: string }>();
  const [, setLocation] = useLocation();
  const [newMessage, setNewMessage] = useState("");
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isVideoChatEnabled, setIsVideoChatEnabled] = useState(false);
  const [rambleState, setRambleState] = useState({
    isActive: false,
    currentSpeaker: null as string | null,
    listeners: [] as Array<{ id: string; name: string; isListening: boolean }>
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToastContext();

  const { data: room } = useQuery<ChatRoom>({
    queryKey: [`/api/rooms/${roomId}`],
    enabled: !!roomId,
  });

  const { data: initialMessages = [] } = useQuery<Message[]>({
    queryKey: [`/api/rooms/${roomId}/messages`],
    enabled: !!roomId,
  });

  const joinRoomMutation = useMutation({
    mutationFn: (userId: string) => apiRequest(`/api/rooms/${roomId}/join`, {
      method: "POST",
      body: JSON.stringify({ userId }),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/rooms/${roomId}`] });
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: (messageData: any) => apiRequest("/api/messages", {
      method: "POST",
      body: JSON.stringify(messageData),
    }),
  });

  // Initialize user and WebSocket
  useEffect(() => {
    // Get current user from localStorage or create temporary one
    const savedUser = localStorage.getItem("talksalot-user");
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setCurrentUser(user);
    } else {
      // Create temporary user for demo
      const tempUser: User = {
        id: crypto.randomUUID(),
        name: `Talker${Math.floor(Math.random() * 1000)}`,
        age: 18,
        photo: undefined,
        location: undefined,
        talkStyle: "fast-talker",
        favoriteTopics: [],
        interests: [],
        isOnline: true,
        talkStreak: 1,
        badges: [],
        joinedAt: new Date(),
      };
      setCurrentUser(tempUser);
      localStorage.setItem("talksalot-user", JSON.stringify(tempUser));
    }
  }, []);

  // Setup WebSocket connection
  useEffect(() => {
    if (!currentUser || !roomId) return;

    // Always use secure WebSocket connections
    const protocol = "wss:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const websocket = new WebSocket(wsUrl);

    websocket.onopen = () => {
      setWs(websocket);
      websocket.send(JSON.stringify({
        type: "join-room",
        roomId,
        userId: currentUser.id,
      }));
      joinRoomMutation.mutate(currentUser.id);
    };

    websocket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case "new-message":
          setMessages(prev => [...prev, data.message]);
          break;
        case "user-joined":
          toast({ description: "Someone joined the chat!" });
          break;
        case "user-left":
          toast({ description: "Someone left the chat" });
          break;
      }
    };

    websocket.onclose = () => {
      setWs(null);
    };

    return () => {
      if (websocket.readyState === WebSocket.OPEN) {
        websocket.send(JSON.stringify({
          type: "leave-room",
          roomId,
          userId: currentUser.id,
        }));
      }
      websocket.close();
    };
  }, [currentUser, roomId]);

  // Load initial messages
  useEffect(() => {
    if (initialMessages.length > 0) {
      setMessages(initialMessages);
    }
  }, [initialMessages]);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !ws || !currentUser || !roomId) return;

    const messageData = {
      roomId,
      userId: currentUser.id,
      userName: currentUser.name,
      content: newMessage.trim(),
    };

    ws.send(JSON.stringify({
      type: "send-message",
      ...messageData,
    }));

    setNewMessage("");
  };

  const handleStartRamble = () => {
    setRambleState(prev => ({
      ...prev,
      isActive: true,
      currentSpeaker: currentUser?.name || "Anonymous"
    }));
  };

  const handleEndRamble = () => {
    setRambleState(prev => ({
      ...prev,
      isActive: false,
      currentSpeaker: null
    }));
  };

  const handlePassMic = (userId: string) => {
    console.log(`Mic requested by ${userId}`);
  };

  const handleAllowInterrupt = () => {
    console.log("Interrupts now allowed");
  };

  if (!room || !currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p>Loading chat room...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b shadow-sm p-4">
        <div className="flex items-center justify-between max-w-4xl mx-auto">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              className="mr-3"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center space-x-3">
              <span className="text-3xl">
                {(() => {
                  const roomEmojis: Record<string, string> = {
                    "Fun Chatters": "😄",
                    "Deep Thinkers": "🤔",
                    "Vent Space": "😮‍💨",
                    "The Rant Zone": "🔥",
                    "Late Night Venting": "🌙",
                    "Single & Talkative": "💬",
                    "Talk it Out (Mental Health)": "🧠",
                    "Healing Hearts": "💚",
                    "Safe Harbor": "🛡️", 
                    "Recovery Circle": "🌱",
                    "Anxiety & Depression Support": "🤗",
                    "Dating & Relationships": "💕",
                    "LGBTQIA+ Community": "🏳️‍🌈",
                    "Cannabis Friendly": "🌿",
                    "Bug Enthusiasts": "🐛",
                    "Animal Lovers": "🐾",
                    "Sky Watchers": "☁️",
                    "Music Corner": "🎵",
                    "Movie Night": "🎬",
                    "Gaming Zone": "🎮",
                    "Foodies United": "🍕",
                    "Cook Together Kitchen": "👩‍🍳",
                    "Travel Stories": "✈️",
                    "Entrepreneurs Hub": "🚀",
                    "Life Advice Corner": "💡",
                    "RambleRealm": "🎤",
                    "DialogueDen": "🗣️",
                    "BabbleBae": "💬",
                    "Sacred Space": "🔮",
                    "Breaking Cycles (20s)": "🌱",
                    "Wisdom & Healing": "🌿",
                    "Understanding Hearts": "💝",
                    "Night Owls": "🦉",
                    "Mindful Conversations": "🧘",
                    "Rants & Real Talk": "💯",
                    "Holiday Chatter": "🎄",
                    "Book Club Corner": "📚",
                    "Language Exchange": "🌍",
                    "College Years": "🎓",
                    "Empty Nesters": "🪺",
                    "Career Mentoring": "👔"
                  };
                  return roomEmojis[room.name] || "💬";
                })()}
              </span>
              <div>
                <h1 className="text-xl font-semibold">{room.name}</h1>
                <p className="text-sm text-gray-500">{room.description}</p>
              </div>
            </div>
          </div>
          <div className="flex items-center text-sm text-gray-500">
            <Users className="w-4 h-4 mr-1" />
            {room.participants.length}/{room.maxParticipants}
          </div>
        </div>
      </div>

      {/* Special Room Features */}
      <div className="max-w-4xl mx-auto px-4">
        {/* Safety Notice */}
        <div className="mt-4">
          <SafetyNotice />
        </div>
        
        {/* RambleRealm Timer */}
        {room.name === "RambleRealm" && (
          <RambleTimer
            isActive={rambleState.isActive}
            currentSpeaker={rambleState.currentSpeaker}
            currentUserId={currentUser?.id || ""}
            onStartRamble={handleStartRamble}
            onEndRamble={handleEndRamble}
            onPassMic={handlePassMic}
            onAllowInterrupt={handleAllowInterrupt}
            participants={rambleState.listeners}
          />
        )}

        {/* Video Chat Section */}
        {isVideoChatEnabled && currentUser && (
          <VideoChat
            roomId={roomId}
            userId={currentUser.id}
            userName={currentUser.name}
            isEnabled={isVideoChatEnabled}
            onToggle={() => setIsVideoChatEnabled(!isVideoChatEnabled)}
          />
        )}

        {!isVideoChatEnabled && room.name !== "RambleRealm" && (
          <div className="bg-teal-50 border border-teal-200 rounded-lg p-4 mb-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-teal-800">Want to see and hear your tribe?</h3>
                <p className="text-sm text-teal-600">Enable video chat for face-to-face conversations</p>
              </div>
              <Button 
                onClick={() => setIsVideoChatEnabled(true)} 
                className="bg-teal-600 hover:bg-teal-700"
              >
                Enable Video
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">💬</div>
              <h3 className="text-xl font-semibold mb-2">Start the conversation!</h3>
              <p className="text-lg font-medium text-purple-600 mb-2">Welcome home, talkers! 🏠</p>
              <p className="text-gray-500">Be the first to say something in {room.name}</p>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.userId === currentUser.id ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                    message.userId === currentUser.id
                      ? "bg-teal-600 text-white"
                      : "bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white"
                  }`}
                >
                  {message.userId !== currentUser.id && (
                    <div className="text-xs opacity-70 mb-1">{message.userName}</div>
                  )}
                  <div>{message.content}</div>
                  <div className="text-xs opacity-70 mt-1">
                    {new Date(message.timestamp).toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </div>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Message Input */}
      <div className="bg-white dark:bg-gray-800 border-t p-4">
        <form onSubmit={handleSendMessage} className="max-w-4xl mx-auto">
          <div className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 p-3 border rounded-full focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              disabled={!ws}
            />
            <Button
              type="submit"
              size="icon"
              className="rounded-full bg-purple-600 hover:bg-purple-700"
              disabled={!newMessage.trim() || !ws}
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}