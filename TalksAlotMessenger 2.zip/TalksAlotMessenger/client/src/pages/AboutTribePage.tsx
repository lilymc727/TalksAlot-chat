import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Heart, Users, Home, Star, MessageCircle } from "lucide-react";
import { TribeMeaning } from "@/components/TribeMeaning";

export default function AboutTribePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-50 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <nav className="bg-white dark:bg-gray-800 shadow-sm p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" size="icon" className="mr-3">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-teal-600 dark:text-teal-400">
            What "Tribe" Means to Us
          </h1>
          <div></div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto p-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-gradient-to-r from-teal-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <MessageCircle className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-4">
            You've Found Your Tribe
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            A platform that transforms what society sees as "talking too much" into a celebrated gift of connection.
            When we say "tribe," we mean something deeper - a place where conversation lovers finally belong.
          </p>
        </div>

        {/* Main Content */}
        <TribeMeaning />

        {/* Additional Context */}
        <div className="mt-12 space-y-8">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
              Why "Tribe" Matters for Talkers
            </h2>
            
            <div className="space-y-6 text-gray-600 dark:text-gray-300">
              <p className="leading-relaxed">
                For too long, conversation enthusiasts have been made to feel like they're "too much." 
                Friends roll their eyes, family members change the subject, and dating profiles warn against being "chatty." 
                But talking isn't a flaw - it's how many of us process, connect, and share our humanity.
              </p>
              
              <p className="leading-relaxed">
                Your TalksAlot tribe understands that a 20-minute answer to "How was your day?" isn't excessive - 
                it's thorough. That three follow-up questions aren't annoying - they show you're engaged. 
                That deep conversations at 2 AM aren't weird - they're when the best insights happen.
              </p>
              
              <p className="leading-relaxed">
                In your tribe, you don't have to apologize for loving words, stories, and the beautiful complexity 
                of human conversation. You don't have to shrink yourself or "keep it brief." 
                Here, your natural communication style is not just accepted - it's celebrated.
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-purple-800 mb-6">
              Welcome Home, Talkers!
            </h2>
            
            <div className="space-y-4 text-purple-700">
              <p className="leading-relaxed">
                This greeting isn't just friendly words - it's a recognition that you've found your place. 
                "Home" because this is where you can be authentically yourself. "Talkers" because we celebrate 
                what others have called excessive.
              </p>
              
              <p className="leading-relaxed">
                Whether you're a storyteller who paints pictures with words, a deep thinker who explores 
                every angle, or someone who just loves the rhythm of good conversation - this is your space. 
                Your tribe is waiting to hear what you have to say.
              </p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <Link href="/">
            <Button className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-3 text-lg">
              <Heart className="w-5 h-5 mr-2" />
              Join Your Tribe
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}