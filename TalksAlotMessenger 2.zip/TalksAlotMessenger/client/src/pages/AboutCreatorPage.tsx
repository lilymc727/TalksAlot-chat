import { Link } from 'wouter';
import { ArrowLeft, Heart } from 'lucide-react';

export default function AboutCreatorPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center gap-2 text-teal-600 hover:text-teal-700 font-medium">
            <ArrowLeft className="w-4 h-4" />
            Back to Community
          </Link>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
          <div className="text-center mb-8">
            <div className="text-6xl mb-4">💝</div>
            <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-4">
              About the Creator
            </h1>
            <p className="text-xl text-teal-600 dark:text-teal-400">
              The heart behind TalksAlot's mission
            </p>
          </div>

          <div className="prose prose-lg max-w-none dark:prose-invert">
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900 dark:to-pink-900 rounded-lg p-6 mb-8">
              <h2 className="text-2xl font-semibold text-purple-800 dark:text-purple-200 mb-4 flex items-center gap-2">
                <Heart className="w-6 h-6" />
                From My Heart
              </h2>
              <p className="text-purple-700 dark:text-purple-300 leading-relaxed">
                Everyone I've ever loved has told me I talk too much. My son, my family, partners - 
                even in toxic relationships where I wasn't being heard, I was still "too much." 
                I spent years trying to stay quiet because I didn't want to ruin things, but I had 
                so much to say. TalksAlot exists because I finally realized - this is for ALL OF US 
                who've been made to feel like our voices are too much.
              </p>
            </div>

            <h3 className="text-2xl font-semibold mb-4">The Pain Behind the Platform</h3>
            <p className="mb-6">
              I was in a toxic relationship where I wasn't being heard, but somehow I was still 
              talking "too much." My own son would tell me I talk a lot. Everyone I've ever loved 
              has made me feel like my enthusiasm for conversation was a burden. I tried so hard 
              to stay quiet because I didn't want to ruin relationships, but I had things to say - 
              important things, healing things, connecting things.
            </p>

            <p className="mb-6">
              The silence was killing me. I'd sit on my hands, count my words, bite my tongue until 
              it hurt. I thought if I could just talk less, maybe I'd be lovable. But all that 
              happened was I lost myself. My conversations aren't noise - they're how I heal people, 
              how I love people, how I help people work through life. When I talk, I'm creating 
              connection that others are afraid to make.
            </p>

            <div className="bg-teal-50 dark:bg-teal-900 rounded-lg p-6 mb-6">
              <h4 className="text-lg font-semibold text-teal-800 dark:text-teal-200 mb-3">
                The Moment Everything Changed
              </h4>
              <p className="text-teal-700 dark:text-teal-300">
                I was building this platform, pouring my heart into creating a space for people 
                like me, when it hit me: I'm not the problem. The people who can't handle my 
                enthusiasm for connection - they're missing out. This platform isn't just for me. 
                It's for ALL OF US who've been shushed, dismissed, and made to feel like our 
                passion for conversation is a flaw instead of a gift.
              </p>
            </div>

            <h3 className="text-2xl font-semibold mb-4">My Son and Our Healing</h3>
            <p className="mb-6">
              Even my own son told me I talk too much. That hurt in a way I can't even describe. 
              Here I was, trying to connect with him, share life wisdom, be present for his journey, 
              and I was still "too much." But through our healing work together, something beautiful 
              happened. We started having real conversations about family patterns, about the ways 
              we learned to communicate that weren't serving us.
            </p>

            <p className="mb-6">
              When he told me "Mom, our family didn't have it right for us," it broke me open in 
              the best way. Our conversations became the foundation for healing - not just for us, 
              but for the Breaking Cycles and Wisdom & Healing rooms in TalksAlot. Because I 
              learned that talking isn't the problem. Not being heard is the problem. And in 
              this community, everyone gets heard.
            </p>

            <div className="bg-green-50 dark:bg-green-900 rounded-lg p-6 mb-6">
              <h4 className="text-lg font-semibold text-green-800 dark:text-green-200 mb-3">
                Why I Built This
              </h4>
              <p className="text-green-700 dark:text-green-300">
                I built TalksAlot because I got tired of trying to stay quiet to keep people 
                comfortable. I got tired of having things to say but swallowing them to avoid 
                "ruining" relationships. I built this because ALL OF US deserve a place where 
                our enthusiasm for connection is celebrated, not endured. Where we can finally 
                stop apologizing for being who we are.
              </p>
            </div>

            <h3 className="text-2xl font-semibold mb-4">What This Platform Really Is</h3>
            <p className="mb-6">
              TalksAlot is my love letter to everyone who's ever felt too much, talked too much, 
              cared too much. It's proof that our intensity isn't a flaw - it's our superpower. 
              Every room, every feature, every conversation starter comes from my own experience 
              of needing this exact kind of community.
            </p>

            <div className="bg-amber-50 dark:bg-amber-900 rounded-lg p-6 mb-6">
              <h4 className="text-lg font-semibold text-amber-800 dark:text-amber-200 mb-3">
                To My Fellow Talkers
              </h4>
              <p className="text-amber-700 dark:text-amber-300">
                If everyone you've ever loved has told you that you talk too much... if you've 
                been in relationships where you weren't heard but were still "too much"... if 
                you've tried to stay quiet because you didn't want to ruin things but had so much 
                to say... THIS IS FOR ALL OF US. You don't need to shrink here. Your voice 
                matters. Your stories heal. You're not too much - you're exactly enough.
              </p>
            </div>

            <h3 className="text-2xl font-semibold mb-4">Where We Go From Here</h3>
            <p className="mb-6">
              This community will grow organically based on what we need as conversation lovers. 
              Maybe we'll add rooms for specific interests, maybe book clubs will become our thing, 
              maybe we'll discover new ways to connect through shared meals or creative projects. 
              I'm here to listen and build what serves our tribe.
            </p>

            <p className="mb-6">
              Thank you for finding your way here. Thank you for bringing your whole, authentic, 
              talkative self to this space. Together, we're creating proof that there's room in 
              this world for people who love words, who ask deep questions, and who believe 
              conversation can heal everything.
            </p>

            <div className="text-center bg-gradient-to-r from-teal-50 to-cyan-50 dark:from-teal-900 dark:to-cyan-900 rounded-lg p-6">
              <p className="text-lg font-medium text-teal-800 dark:text-teal-200 mb-2">
                With love, gratitude, and endless conversations,
              </p>
              <p className="text-2xl font-bold text-teal-600 dark:text-teal-400">
                Your TalksAlot Creator
              </p>
              <p className="text-sm text-teal-600 dark:text-teal-400 mt-2">
                Built with love, healing, and enthusiasm FOR ALL OF US who've been told we're "too much"
              </p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <Link 
            href="/" 
            className="inline-flex items-center gap-2 bg-teal-600 text-white px-8 py-3 rounded-lg hover:bg-teal-700 transition-colors font-semibold"
          >
            Join Our Conversation Community
          </Link>
        </div>
      </div>
    </div>
  );
}