import { Button } from "@/components/ui/button";
import { Shield, Users, MessageCircle, Heart, Lock, CheckCircle } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-500 via-teal-600 to-blue-700">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold text-white mb-6">
            🗣️ TalksAlot
          </h1>
          <p className="text-2xl text-cyan-100 mb-8 font-medium">
            Where Talkers Find Their Tribe
          </p>
          <p className="text-xl text-white/90 max-w-3xl mx-auto leading-relaxed">
            Have people said you talk a lot? You've found your tribe! 
            TalksAlot is a secure community for adults (19+) who love meaningful conversation. 
            This is your safe space where being chatty is celebrated, not criticized.
          </p>
        </div>

        {/* Authentication Notice */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 mb-12 border border-white/20">
          <div className="flex items-center justify-center mb-6">
            <Shield className="w-12 h-12 text-yellow-300 mr-4" />
            <h2 className="text-3xl font-bold text-white">Verified Community Only</h2>
          </div>
          <div className="text-center mb-8">
            <p className="text-xl text-cyan-100 mb-6">
              Every member is verified through Replit for maximum safety and security.
            </p>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold py-4 px-8 rounded-xl text-lg transition-all duration-300 transform hover:scale-105"
            >
              Log In with Replit to Join
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
            <Users className="w-12 h-12 text-cyan-300 mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">50+ Chat Rooms</h3>
            <p className="text-cyan-100">
              From Fun Chatters to Deep Thinkers, Mental Health Support to Book Clubs - 
              find your perfect conversation space.
            </p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
            <MessageCircle className="w-12 h-12 text-cyan-300 mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Real-Time Chat</h3>
            <p className="text-cyan-100">
              Instant messaging with voice and video capabilities. 
              Connect with fellow talkers in meaningful conversations.
            </p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
            <Heart className="w-12 h-12 text-cyan-300 mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Safe Space</h3>
            <p className="text-cyan-100">
              Zero tolerance for negativity. Every room is actively protected 
              from harassment with verified, mature community members.
            </p>
          </div>
        </div>

        {/* Security Features */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 mb-12 border border-white/20">
          <h2 className="text-3xl font-bold text-white text-center mb-8">Why Authentication Matters</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div className="flex items-start">
                <CheckCircle className="w-6 h-6 text-green-400 mr-3 mt-1" />
                <div>
                  <h4 className="text-xl font-semibold text-white">Verified Identity</h4>
                  <p className="text-cyan-100">Every user authenticated through Replit account</p>
                </div>
              </div>
              <div className="flex items-start">
                <CheckCircle className="w-6 h-6 text-green-400 mr-3 mt-1" />
                <div>
                  <h4 className="text-xl font-semibold text-white">No Anonymous Trolls</h4>
                  <p className="text-cyan-100">Secure environment free from fake accounts</p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start">
                <CheckCircle className="w-6 h-6 text-green-400 mr-3 mt-1" />
                <div>
                  <h4 className="text-xl font-semibold text-white">Mature Community</h4>
                  <p className="text-cyan-100">Adults only (19+) for meaningful conversations</p>
                </div>
              </div>
              <div className="flex items-start">
                <CheckCircle className="w-6 h-6 text-green-400 mr-3 mt-1" />
                <div>
                  <h4 className="text-xl font-semibold text-white">Privacy Protected</h4>
                  <p className="text-cyan-100">Secure sessions with encrypted data storage</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Featured Rooms Preview */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-8">Featured Chat Rooms</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { emoji: "😄", name: "Fun Chatters", desc: "Jokes & memes" },
              { emoji: "🤔", name: "Deep Thinkers", desc: "Philosophy & meaning" },
              { emoji: "🧠", name: "Mental Health", desc: "Supportive community" },
              { emoji: "📚", name: "Book Club", desc: "Literary discussions" }
            ].map((room, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <div className="text-4xl mb-3">{room.emoji}</div>
                <h3 className="text-lg font-bold text-white mb-2">{room.name}</h3>
                <p className="text-cyan-100 text-sm">{room.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-8 inline-block">
            <h2 className="text-3xl font-bold text-black mb-4">Welcome Home, Talkers!</h2>
            <p className="text-black/80 mb-6 text-lg">
              Join our verified community of conversation enthusiasts
            </p>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-black hover:bg-gray-800 text-white font-bold py-4 px-8 rounded-xl text-lg transition-all duration-300"
            >
              <Lock className="w-5 h-5 mr-2" />
              Secure Login with Replit
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}