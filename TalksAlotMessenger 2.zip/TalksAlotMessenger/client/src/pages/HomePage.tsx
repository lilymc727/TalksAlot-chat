import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { MessageCircle, Users, Zap, Heart, Bug, Leaf, Cloud, Music, Gamepad2, Coffee, MapPin, Film, Settings, Bell, Bookmark, Star, Shield, Mail } from "lucide-react";
import { useToastContext } from "@/components/ToastProvider";
import { AgeVerificationModal } from "@/components/AgeVerificationModal";
import { WelcomeTour } from "@/components/WelcomeTour";
import { NotificationSettings } from "@/components/NotificationSettings";
import { DarkModeToggle } from "@/components/DarkModeToggle";
import { SmartMatchingModal } from "@/components/SmartMatchingModal";
import { SubscriptionModal } from "@/components/SubscriptionModal";
import { TrialBanner } from "@/components/TrialBanner";
import { RoomBrowser } from "@/components/RoomBrowser";
import { PremiumGate } from "@/components/PremiumGate";
import { TribeMeaning } from "@/components/TribeMeaning";
import { SecurityBadge } from "@/components/SecurityBadge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ChatRoom, User } from "@shared/schema";

const topicIcons = {
  funny: MessageCircle,
  deep: Heart,
  vents: Cloud,
  "life-advice": Users,
  lgbtqia: Heart,
  entrepreneurs: Zap,
  bugs: Bug,
  animals: Heart,
  sky: Cloud,
  cannabis: Leaf,
  music: Music,
  movies: Film,
  gaming: Gamepad2,
  food: Coffee,
  travel: MapPin,
  general: MessageCircle,
};

export default function HomePage() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showCreateProfile, setShowCreateProfile] = useState(false);
  const [matchingTopic, setMatchingTopic] = useState<string | null>(null);
  const { toast } = useToastContext();

  const { data: rooms = [], isLoading: roomsLoading } = useQuery<ChatRoom[]>({
    queryKey: ["/api/rooms"],
  });

  const { data: onlineUsers = [] } = useQuery<User[]>({
    queryKey: ["/api/users/online"],
    refetchInterval: 5000,
  });

  const createUserMutation = useMutation({
    mutationFn: (userData: any) => apiRequest("/api/users", {
      method: "POST",
      body: JSON.stringify(userData),
    }),
    onSuccess: (user) => {
      setCurrentUser(user);
      setShowCreateProfile(false);
      toast({ title: "Welcome to TalksAlot!", description: "Your profile has been created!" });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
  });

  const findMatchMutation = useMutation({
    mutationFn: (matchData: any) => apiRequest("/api/match-requests", {
      method: "POST",
      body: JSON.stringify(matchData),
    }),
    onSuccess: (result) => {
      if (result.matched) {
        toast({ 
          title: "Match Found!", 
          description: `Connected with someone who loves talking about ${result.topic}!` 
        });
        setMatchingTopic(null);
      } else {
        setMatchingTopic(result.topic);
        toast({ 
          title: "Looking for a match...", 
          description: "We'll notify you when someone wants to chat!" 
        });
      }
    },
  });

  const handleCreateProfile = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const interests = formData.get("interests")?.toString().split(",").map(i => i.trim()).filter(i => i) || [];
    const favoriteTopics = formData.getAll("favoriteTopics") as string[];
    const age = parseInt(formData.get("age")?.toString() || "0");
    
    if (age < 18) {
      toast({ 
        title: "Mature Community", 
        description: "TalksAlot is a mature community for adults 18+ who appreciate meaningful conversation.",
        variant: "destructive"
      });
      return;
    }
    
    createUserMutation.mutate({
      name: formData.get("name"),
      age,
      photo: formData.get("photo")?.toString() || undefined,
      location: formData.get("location")?.toString() || undefined,
      talkStyle: formData.get("talkStyle"),
      favoriteTopics,
      interests,
      isOnline: true,
    });
  };

  const handleQuickMatch = (topic: string) => {
    if (!currentUser) {
      toast({ title: "Create Profile First", description: "Please create a profile to start matching!" });
      setShowCreateProfile(true);
      return;
    }

    findMatchMutation.mutate({
      userId: currentUser.id,
      preferredTopic: topic,
    });
  };

  if (!currentUser) {
    // Check if user has verified age
    const ageVerified = localStorage.getItem("talksalot-age-verified");
    if (!ageVerified && !showAgeVerification && !showCreateProfile) {
      setShowAgeVerification(true);
    }
    return (
      <PremiumGate 
        hasAccess={true} // Allow profile creation
        isInTrial={false}
        hoursLeft={0}
      >
        {showAgeVerification && (
          <AgeVerificationModal
            isOpen={showAgeVerification}
            onClose={() => setShowAgeVerification(false)}
            onVerified={() => {
              localStorage.setItem("talksalot-age-verified", "true");
              setShowAgeVerification(false);
              setShowCreateProfile(true);
            }}
          />
        )}

        <div className="min-h-screen flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 max-w-md w-full">
            <div className="text-center mb-6">
              <h1 className="text-3xl font-bold text-teal-600 dark:text-teal-400 mb-2">
                TalksAlot 💬
              </h1>
              <p className="text-lg font-medium text-teal-700 dark:text-teal-300 mb-2">
                Have people said you talk a lot? You've found your tribe!
              </p>
              <p className="text-xl font-semibold text-purple-600 dark:text-purple-400 mb-2">
                Welcome home, talkers! 🏠
              </p>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                A platform that transforms what society sees as "talking too much" into a celebrated gift of connection. 
                Not primarily a dating app - just a place where you're never "too much."
              </p>
            </div>

          <form onSubmit={handleCreateProfile} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Your Name</label>
              <input
                name="name"
                type="text"
                required
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="What should we call you? (We appreciate thoughtful communicators)"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Your Age</label>
              <input
                name="age"
                type="number"
                required
                min="19"
                max="120"
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Must be 19 or older for mature community"
              />
              <p className="text-xs text-gray-500 mt-1">Age verification required for safety</p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Profile Photo (Optional)</label>
              <input
                name="photo"
                type="url"
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Photo URL (optional)"
              />
              <p className="text-xs text-gray-500 mt-1">Share a photo URL if you'd like</p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Location (Optional)</label>
              <input
                name="location"
                type="text"
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="City, State/Country (optional)"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Your Talk Style</label>
              <select
                name="talkStyle"
                required
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="">Select your style...</option>
                <option value="fast-talker">Fast Talker - Quick & Energetic</option>
                <option value="storyteller">Storyteller - Love long stories</option>
                <option value="jokester">Jokester - Always cracking jokes</option>
                <option value="deep-thinker">Deep Thinker - Philosophical</option>
                <option value="listener">Good Listener - Love to hear others</option>
                <option value="advice-giver">Advice Giver - Helper & Guide</option>
                <option value="funny-loud">Funny & Loud - Big personality</option>
                <option value="real-talker">Real Talker - Keep it authentic</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Topics You Love (Select multiple)</label>
              <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto border rounded-lg p-3">
                {[
                  "rants", "real-talk", "dating", "deep-chats", "life-advice", "vents", 
                  "funny", "cannabis", "lgbtqia", "entrepreneurs", "animals", "bugs", 
                  "sky", "music", "movies", "gaming", "food", "travel", "late-night", 
                  "singles", "mental-health"
                ].map(topic => (
                  <label key={topic} className="flex items-center space-x-2 text-sm">
                    <input
                      type="checkbox"
                      name="favoriteTopics"
                      value={topic}
                      className="rounded text-purple-600 focus:ring-purple-500"
                    />
                    <span className="capitalize">{topic.replace('-', ' ')}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Your Interests</label>
              <input
                name="interests"
                type="text"
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="movies, music, travel, cooking..."
              />
              <p className="text-xs text-gray-500 mt-1">Separate with commas</p>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3"
              disabled={createUserMutation.isPending}
            >
              {createUserMutation.isPending ? "Creating..." : "Join TalksAlot!"}
            </Button>
          </form>
        </div>
      </div>
      </PremiumGate>
    );
  }

  return (
    <div className="min-h-screen p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent mb-2">
            TalksAlot 💬
          </h1>
          <p className="text-xl font-semibold text-teal-700 dark:text-teal-300 mb-2">
            Have people said you talk a lot? You've found your tribe!
          </p>
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-4">
            Hey {currentUser.name}! Your conversation community is buzzing with {onlineUsers.length} talkers online right now.
          </p>
          <div className="flex items-center justify-center gap-4 text-sm text-gray-500">
            <span>🟢 {onlineUsers.length} community members active</span>
            <span>🏆 Your talk streak: {currentUser.talkStreak} days strong</span>
            <Link href="/stories" className="text-teal-600 hover:text-teal-700 font-medium">
              📖 Community Stories
            </Link>
            <Link href="/about-tribe" className="text-teal-600 hover:text-teal-700 font-medium">
              🏠 What "Tribe" Means
            </Link>
            <Link href="/about-creator" className="text-teal-600 hover:text-teal-700 font-medium">
              💝 About the Creator
            </Link>
            <Link href="/guidelines" className="text-teal-600 hover:text-teal-700 font-medium">
              📋 Guidelines
            </Link>
            <button 
              onClick={() => setShowNotificationSettings(true)}
              className="text-teal-600 hover:text-teal-700 font-medium flex items-center"
            >
              <Bell className="w-4 h-4 mr-1" />
              Notifications
            </button>
            <DarkModeToggle />
            <Link href="/profile" className="text-teal-600 hover:text-teal-700 font-medium">
              👤 Profile
            </Link>
          </div>
        </div>

        {/* Quick Match Section */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold mb-4 text-center">Talk Now!</h2>
          <p className="text-gray-600 dark:text-gray-300 text-center mb-6">
            Connect with mature, like-minded individuals who appreciate deep conversation and understand that some of us simply love to talk.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { topic: "funny", label: "Funny Stuff", color: "bg-amber-100 hover:bg-amber-200 text-amber-700" },
              { topic: "deep", label: "Deep Talk", color: "bg-ocean-100 hover:bg-ocean-200 text-ocean-700" },
              { topic: "animals", label: "Animals", color: "bg-mint-100 hover:bg-mint-200 text-mint-700" },
              { topic: "cannabis", label: "Cannabis", color: "bg-emerald-100 hover:bg-emerald-200 text-emerald-700" },
              { topic: "music", label: "Music", color: "bg-violet-100 hover:bg-violet-200 text-violet-700" },
              { topic: "sky", label: "Sky & Space", color: "bg-cyan-100 hover:bg-cyan-200 text-cyan-700" },
              { topic: "bugs", label: "Bugs & Insects", color: "bg-lime-100 hover:bg-lime-200 text-lime-700" },
              { topic: "rants", label: "Rant Zone", color: "bg-orange-100 hover:bg-orange-200 text-orange-700" },
              { topic: "late-night", label: "Late Night", color: "bg-indigo-100 hover:bg-indigo-200 text-indigo-700" },
              { topic: "singles", label: "Singles", color: "bg-pink-100 hover:bg-pink-200 text-pink-700" },
              { topic: "mental-health", label: "Mental Health", color: "bg-green-100 hover:bg-green-200 text-green-700" },
              { topic: "general", label: "Anything!", color: "bg-slate-100 hover:bg-slate-200 text-slate-700" },
            ].map(({ topic, label, color }) => {
              const Icon = topicIcons[topic as keyof typeof topicIcons];
              return (
                <Button
                  key={topic}
                  onClick={() => handleQuickMatch(topic)}
                  className={`${color} border-0 p-4 rounded-xl transition-all`}
                  disabled={findMatchMutation.isPending || matchingTopic === topic}
                >
                  <Icon className="w-4 h-4 mr-2" />
                  {matchingTopic === topic ? "Matching..." : label}
                </Button>
              );
            })}
          </div>
        </div>

        {/* Room Browser - No Scrolling, Just Flipping */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6">
          <h2 className="text-2xl font-semibold mb-6 text-center">Choose Your Conversation Space</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8 text-center">
            Pick a room that calls to you, dive in, and connect with your conversation tribe
          </p>
          
          {roomsLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin w-12 h-12 border-4 border-teal-500 border-t-transparent rounded-full"></div>
            </div>
          ) : (
            <RoomBrowser rooms={rooms} roomStyles={{
              "Fun Chatters": { emoji: "😄", bg: "from-yellow-100 to-orange-100", border: "border-yellow-300" },
              "Deep Thinkers": { emoji: "🤔", bg: "from-blue-100 to-indigo-100", border: "border-blue-300" },
              "Vent Space": { emoji: "😮‍💨", bg: "from-purple-100 to-pink-100", border: "border-purple-300" },
              "The Rant Zone": { emoji: "🔥", bg: "from-red-100 to-orange-100", border: "border-red-300" },
              "Late Night Venting": { emoji: "🌙", bg: "from-indigo-100 to-purple-100", border: "border-indigo-300" },
              "Single & Talkative": { emoji: "💬", bg: "from-pink-100 to-rose-100", border: "border-pink-300" },
              "Talk it Out (Mental Health)": { emoji: "🧠", bg: "from-green-100 to-emerald-100", border: "border-green-300" },
              "Healing Hearts": { emoji: "💚", bg: "from-emerald-100 to-teal-100", border: "border-emerald-300" },
              "Safe Harbor": { emoji: "🛡️", bg: "from-blue-100 to-cyan-100", border: "border-blue-300" },
              "Recovery Circle": { emoji: "🌱", bg: "from-green-100 to-lime-100", border: "border-green-300" },
              "Anxiety & Depression Support": { emoji: "🤗", bg: "from-purple-100 to-violet-100", border: "border-purple-300" },
              "Dating & Relationships": { emoji: "💕", bg: "from-rose-100 to-pink-100", border: "border-rose-300" },
              "LGBTQIA+ Community": { emoji: "🏳️‍🌈", bg: "from-purple-100 to-pink-100", border: "border-purple-300" },
              "Cannabis Friendly": { emoji: "🌿", bg: "from-green-100 to-lime-100", border: "border-green-300" },
              "Bug Enthusiasts": { emoji: "🐛", bg: "from-lime-100 to-green-100", border: "border-lime-300" },
              "Animal Lovers": { emoji: "🐾", bg: "from-amber-100 to-yellow-100", border: "border-amber-300" },
              "Sky Watchers": { emoji: "☁️", bg: "from-cyan-100 to-blue-100", border: "border-cyan-300" },
              "Music Corner": { emoji: "🎵", bg: "from-violet-100 to-purple-100", border: "border-violet-300" },
              "Movie Night": { emoji: "🎬", bg: "from-slate-100 to-gray-100", border: "border-slate-300" },
              "Gaming Zone": { emoji: "🎮", bg: "from-teal-100 to-cyan-100", border: "border-teal-300" },
              "Foodies United": { emoji: "🍕", bg: "from-orange-100 to-red-100", border: "border-orange-300" },
              "Cook Together Kitchen": { emoji: "👩‍🍳", bg: "from-yellow-100 to-orange-100", border: "border-yellow-300" },
              "Travel Stories": { emoji: "✈️", bg: "from-sky-100 to-blue-100", border: "border-sky-300" },
              "Entrepreneurs Hub": { emoji: "🚀", bg: "from-emerald-100 to-teal-100", border: "border-emerald-300" },
              "Life Advice Corner": { emoji: "💡", bg: "from-yellow-100 to-amber-100", border: "border-yellow-300" },
              "RambleRealm": { emoji: "🎤", bg: "from-purple-100 to-indigo-100", border: "border-purple-300" },
              "DialogueDen": { emoji: "🗣️", bg: "from-emerald-100 to-teal-100", border: "border-emerald-300" },
              "BabbleBae": { emoji: "💬", bg: "from-rose-100 to-pink-100", border: "border-rose-300" },
              "Sacred Space": { emoji: "🔮", bg: "from-violet-100 to-purple-100", border: "border-violet-300" },
              "Breaking Cycles (20s)": { emoji: "🌱", bg: "from-green-100 to-emerald-100", border: "border-green-300" },
              "Wisdom & Healing": { emoji: "🌿", bg: "from-sage-100 to-green-100", border: "border-sage-300" },
              "Understanding Hearts": { emoji: "💝", bg: "from-pink-100 to-rose-100", border: "border-pink-300" },
              "Night Owls": { emoji: "🦉", bg: "from-slate-100 to-indigo-100", border: "border-slate-300" },
              "Mindful Conversations": { emoji: "🧘", bg: "from-teal-100 to-cyan-100", border: "border-teal-300" },
              "Rants & Real Talk": { emoji: "💯", bg: "from-orange-100 to-yellow-100", border: "border-orange-300" },
              "Holiday Chatter": { emoji: "🎄", bg: "from-red-100 to-green-100", border: "border-red-300" },
              "Book Club Corner": { emoji: "📚", bg: "from-amber-100 to-orange-100", border: "border-amber-300" },
              "Language Exchange": { emoji: "🌍", bg: "from-blue-100 to-purple-100", border: "border-blue-300" },
              "College Years": { emoji: "🎓", bg: "from-indigo-100 to-blue-100", border: "border-indigo-300" },
              "Empty Nesters": { emoji: "🪺", bg: "from-pink-100 to-purple-100", border: "border-pink-300" },
              "Career Mentoring": { emoji: "👔", bg: "from-gray-100 to-slate-100", border: "border-gray-300" }
            }} />
          )}
        </div>

        {/* Not a Dating App Notice */}
        <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-2xl shadow-lg p-6 mt-8">
          <div className="flex items-start space-x-4">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-indigo-400 rounded-full flex items-center justify-center text-2xl font-bold text-white shadow-lg">
              💬
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-purple-800 mb-2">This Isn't Primarily a Dating App</h3>
              <div className="text-gray-700 space-y-2">
                <p className="font-medium text-purple-700">
                  A platform that transforms what society sees as "talking too much" into a celebrated gift of connection.
                </p>
                <p className="text-sm">
                  Whether you're seeking friendship, intellectual connection, emotional support, or just someone who 
                  celebrates your storytelling style - this is your community. We've built a place where conversation 
                  enthusiasts are valued for their authentic communication, not despite it.
                </p>
                <p className="text-sm font-medium text-purple-600">
                  Romance might spark naturally, but our core mission is building a lasting community where 
                  conversation lovers thrive together, support each other, and never feel "too much" again.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Community Vibe Check */}
        <div className="bg-gradient-to-r from-yellow-50 to-amber-50 border border-yellow-200 rounded-2xl shadow-lg p-6 mt-8">
          <div className="flex items-start space-x-4">
            <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-amber-400 rounded-full flex items-center justify-center text-2xl font-bold text-white shadow-lg">
              😄
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-yellow-800 mb-2">Fair Warning: We Talk A LOT Here!</h3>
              <div className="text-gray-700 space-y-2">
                <p className="font-medium text-yellow-700">
                  If you're someone who prefers short conversations, we're going to know! (And that's totally okay.)
                </p>
                <p className="text-sm">
                  Our community members light up during 3-hour conversations, ask 47 follow-up questions, and consider 
                  "tell me more" the three most beautiful words. If that sounds overwhelming, no judgment - 
                  but you might want to settle in with some coffee first!
                </p>
                <p className="text-sm font-medium text-yellow-600">
                  Everyone's welcome, but heads up: our community conversations run deep, long, and enthusiastically!
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Safe Spaces Notice */}
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl shadow-lg p-6 mt-8">
          <div className="flex items-start space-x-4">
            <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-emerald-400 rounded-full flex items-center justify-center text-2xl font-bold text-white shadow-lg">
              🛡️
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-green-800 mb-2">Every Room is a Safe Space</h3>
              <div className="text-gray-700 space-y-2">
                <p className="font-medium text-green-700">
                  TalksAlot is built on respect and positivity. EVERY room - from Bug Enthusiasts to Deep Thinkers - 
                  is a safe space where negativity, harassment, and disrespect have no place.
                </p>
                <p className="text-sm">
                  Whether community members are sharing daily adventures, exploring philosophical ideas, or opening up about 
                  personal struggles, they do so knowing our community actively protects and celebrates every voice. 
                  We maintain our welcoming atmosphere through dedicated moderation and community guidelines.
                </p>
                <p className="text-sm font-medium text-green-600">
                  No trolls, no judgment, no making people feel small. Just a thriving community of genuine connection.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* What Tribe Means */}
        <TribeMeaning />

        {/* About the Creator */}
        <div className="bg-gradient-to-r from-teal-50 to-cyan-50 border border-teal-200 rounded-2xl shadow-lg p-6 mt-8">
          <div className="flex items-start space-x-4">
            <div className="w-16 h-16 bg-gradient-to-r from-teal-400 to-cyan-400 rounded-full flex items-center justify-center text-2xl font-bold text-white shadow-lg">
              ✨
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-teal-800 mb-2">About the Creator</h3>
              <div className="text-gray-700 space-y-2">
                <p className="font-medium text-teal-700">
                  Hi there! I'm someone who's been told "you talk too much" more times than I can count.
                </p>
                <p className="text-sm">
                  Growing up, I always felt like I had so much to say, but people around me didn't always appreciate it. 
                  Sound familiar? I created TalksAlot because I believe that loving conversation is a gift, not a flaw.
                </p>
                <p className="text-sm">
                  This space is for all of us who light up when we find someone who actually wants to hear our stories, 
                  dive deep into topics we're passionate about, and understand that sometimes the best conversations 
                  happen at 2 AM when the world is quiet.
                </p>
                <p className="text-sm font-medium text-teal-600">
                  Welcome to your tribe. Let's talk our hearts out together! 💚
                </p>
              </div>
            </div>
          </div>
        </div>

        <WelcomeTour 
          isOpen={showWelcomeTour}
          onClose={() => setShowWelcomeTour(false)}
        />

        <NotificationSettings
          isOpen={showNotificationSettings}
          onClose={() => setShowNotificationSettings(false)}
        />

        {/* Security Badge */}
        <SecurityBadge />
      </div>
    </div>
  );
}