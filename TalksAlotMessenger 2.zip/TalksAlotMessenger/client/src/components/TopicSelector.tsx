import { useState } from 'react';
import { Check, ChevronDown, ChevronUp } from 'lucide-react';
import { TOPIC_CATEGORIES, type TopicCategory } from '@shared/topicCategories';

interface TopicSelectorProps {
  selectedTopics: string[];
  onTopicsChange: (topics: string[]) => void;
  maxSelections?: number;
}

export function TopicSelector({ selectedTopics, onTopicsChange, maxSelections = 10 }: TopicSelectorProps) {
  const [expandedCategories, setExpandedCategories] = useState<Set<TopicCategory>>(new Set());

  const toggleCategory = (category: TopicCategory) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(category)) {
      newExpanded.delete(category);
    } else {
      newExpanded.add(category);
    }
    setExpandedCategories(newExpanded);
  };

  const toggleTopic = (topic: string) => {
    if (selectedTopics.includes(topic)) {
      onTopicsChange(selectedTopics.filter(t => t !== topic));
    } else if (selectedTopics.length < maxSelections) {
      onTopicsChange([...selectedTopics, topic]);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Choose Talk Topics</h3>
        <span className="text-sm text-gray-500">
          {selectedTopics.length}/{maxSelections} selected
        </span>
      </div>

      {Object.entries(TOPIC_CATEGORIES).map(([categoryName, category]) => {
        const isExpanded = expandedCategories.has(categoryName as TopicCategory);
        const selectedInCategory = category.topics.filter(topic => selectedTopics.includes(topic)).length;
        
        return (
          <div key={categoryName} className="border rounded-lg overflow-hidden">
            <button
              onClick={() => toggleCategory(categoryName as TopicCategory)}
              className={`w-full p-4 flex items-center justify-between bg-gradient-to-r ${category.color} text-white hover:opacity-90 transition-opacity`}
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{category.emoji}</span>
                <div className="text-left">
                  <h4 className="font-semibold">{categoryName}</h4>
                  {selectedInCategory > 0 && (
                    <span className="text-sm opacity-90">
                      {selectedInCategory} topic{selectedInCategory !== 1 ? 's' : ''} selected
                    </span>
                  )}
                </div>
              </div>
              {isExpanded ? <ChevronUp /> : <ChevronDown />}
            </button>
            
            {isExpanded && (
              <div className="p-4 bg-gray-50 dark:bg-gray-800">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {category.topics.map(topic => {
                    const isSelected = selectedTopics.includes(topic);
                    const canSelect = isSelected || selectedTopics.length < maxSelections;
                    
                    return (
                      <button
                        key={topic}
                        onClick={() => toggleTopic(topic)}
                        disabled={!canSelect}
                        className={`p-3 text-left rounded-lg border transition-all ${
                          isSelected
                            ? 'bg-teal-100 border-teal-300 text-teal-800 dark:bg-teal-900 dark:border-teal-600 dark:text-teal-200'
                            : canSelect
                            ? 'bg-white border-gray-200 hover:border-gray-300 dark:bg-gray-700 dark:border-gray-600 dark:hover:border-gray-500'
                            : 'bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{topic}</span>
                          {isSelected && <Check className="w-4 h-4 text-teal-600" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}