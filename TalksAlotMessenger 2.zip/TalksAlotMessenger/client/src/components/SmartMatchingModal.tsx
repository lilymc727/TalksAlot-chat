import { useState } from 'react';
import { X, Search, Heart, Clock } from 'lucide-react';
import { TOPIC_CATEGORIES, type TopicCategory } from '@shared/topicCategories';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface SmartMatchingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: any;
}

export function SmartMatchingModal({ isOpen, onClose, currentUser }: SmartMatchingModalProps) {
  const [selectedCategory, setSelectedCategory] = useState<TopicCategory | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<string>('');
  const [conversationStyle, setConversationStyle] = useState<string>('');
  const [duration, setDuration] = useState<'quick' | 'medium' | 'long'>('medium');
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();

  if (!isOpen) return null;

  const handleStartMatching = async () => {
    if (!selectedTopic || !selectedCategory) {
      toast({
        title: "Please select a topic",
        description: "Choose a category and specific topic to find your match",
        variant: "destructive"
      });
      return;
    }

    setIsSearching(true);

    try {
      const response = await apiRequest('POST', '/api/smart-match', {
        userId: currentUser.id,
        topic: selectedTopic,
        category: selectedCategory,
        conversationStyle,
        duration
      });

      if (response.ok) {
        const data = await response.json();
        if (data.match) {
          toast({
            title: "Match Found! 🎉",
            description: `You've been matched with ${data.match.name} for ${selectedTopic}`,
          });
          onClose();
          // Navigate to chat with match
          window.location.href = `/chat/${data.conversationId}`;
        } else {
          toast({
            title: "Searching for your perfect match...",
            description: "We'll notify you when someone with similar interests joins the queue",
          });
        }
      }
    } catch (error) {
      toast({
        title: "Matching Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Smart Matching</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Category Selection */}
            <div>
              <h3 className="text-lg font-semibold mb-3">Choose a Category</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {Object.entries(TOPIC_CATEGORIES).map(([categoryName, category]) => (
                  <button
                    key={categoryName}
                    onClick={() => {
                      setSelectedCategory(categoryName as TopicCategory);
                      setSelectedTopic('');
                    }}
                    className={`p-3 rounded-lg border transition-all ${
                      selectedCategory === categoryName
                        ? 'bg-teal-100 border-teal-300 text-teal-800 dark:bg-teal-900 dark:border-teal-600'
                        : 'bg-white border-gray-200 hover:border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                    }`}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-1">{category.emoji}</div>
                      <div className="text-xs font-medium">{categoryName}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Topic Selection */}
            {selectedCategory && (
              <div>
                <h3 className="text-lg font-semibold mb-3">Pick a Specific Topic</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {TOPIC_CATEGORIES[selectedCategory].topics.map(topic => (
                    <button
                      key={topic}
                      onClick={() => setSelectedTopic(topic)}
                      className={`p-3 text-left rounded-lg border transition-all ${
                        selectedTopic === topic
                          ? 'bg-teal-100 border-teal-300 text-teal-800 dark:bg-teal-900 dark:border-teal-600'
                          : 'bg-white border-gray-200 hover:border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                      }`}
                    >
                      <span className="text-sm font-medium">{topic}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Conversation Style */}
            {selectedTopic && (
              <div>
                <h3 className="text-lg font-semibold mb-3">Conversation Style</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {['Advice Seeking', 'Just Chatting', 'Deep Discussion', 'Venting/Listening', 'Debate & Exchange'].map(style => (
                    <button
                      key={style}
                      onClick={() => setConversationStyle(style)}
                      className={`p-3 text-center rounded-lg border transition-all ${
                        conversationStyle === style
                          ? 'bg-purple-100 border-purple-300 text-purple-800 dark:bg-purple-900 dark:border-purple-600'
                          : 'bg-white border-gray-200 hover:border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                      }`}
                    >
                      <div className="text-sm font-medium">{style}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Duration */}
            {selectedTopic && (
              <div>
                <h3 className="text-lg font-semibold mb-3">How long do you want to chat?</h3>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => setDuration('quick')}
                    className={`p-4 text-center rounded-lg border transition-all ${
                      duration === 'quick'
                        ? 'bg-green-100 border-green-300 text-green-800 dark:bg-green-900 dark:border-green-600'
                        : 'bg-white border-gray-200 hover:border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                    }`}
                  >
                    <Clock className="w-5 h-5 mx-auto mb-1" />
                    <div className="text-sm font-medium">Quick</div>
                    <div className="text-xs text-gray-500">5-15 mins</div>
                  </button>
                  <button
                    onClick={() => setDuration('medium')}
                    className={`p-4 text-center rounded-lg border transition-all ${
                      duration === 'medium'
                        ? 'bg-yellow-100 border-yellow-300 text-yellow-800 dark:bg-yellow-900 dark:border-yellow-600'
                        : 'bg-white border-gray-200 hover:border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                    }`}
                  >
                    <Clock className="w-5 h-5 mx-auto mb-1" />
                    <div className="text-sm font-medium">Medium</div>
                    <div className="text-xs text-gray-500">30-60 mins</div>
                  </button>
                  <button
                    onClick={() => setDuration('long')}
                    className={`p-4 text-center rounded-lg border transition-all ${
                      duration === 'long'
                        ? 'bg-purple-100 border-purple-300 text-purple-800 dark:bg-purple-900 dark:border-purple-600'
                        : 'bg-white border-gray-200 hover:border-gray-300 dark:bg-gray-700 dark:border-gray-600'
                    }`}
                  >
                    <Clock className="w-5 h-5 mx-auto mb-1" />
                    <div className="text-sm font-medium">Deep Dive</div>
                    <div className="text-xs text-gray-500">1+ hours</div>
                  </button>
                </div>
              </div>
            )}

            {/* Match Button */}
            {selectedTopic && (
              <div className="pt-4">
                <button
                  onClick={handleStartMatching}
                  disabled={isSearching}
                  className="w-full bg-gradient-to-r from-teal-500 to-cyan-600 text-white py-4 rounded-lg font-semibold hover:from-teal-600 hover:to-cyan-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSearching ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"></div>
                      Finding your perfect match...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <Heart className="w-5 h-5" />
                      Find My Conversation Partner
                    </div>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}