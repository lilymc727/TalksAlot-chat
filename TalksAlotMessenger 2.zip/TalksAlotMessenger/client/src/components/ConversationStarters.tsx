import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { MessageCircle, Shuffle } from 'lucide-react';

interface ConversationStartersProps {
  onStarterSelect: (starter: string) => void;
  roomCategory?: string;
}

export function ConversationStarters({ onStarterSelect, roomCategory }: ConversationStartersProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const startersByCategory = {
    'life-advice': [
      "What's the best piece of advice you've ever received?",
      "How do you handle making difficult life decisions?",
      "What would you tell your younger self?",
      "How do you know when it's time to make a big change?",
      "What's something you wish more people understood about life?"
    ],
    'mental-health': [
      "What's one small thing that always improves your mood?",
      "How do you practice self-care when things get overwhelming?",
      "What's helped you build resilience through tough times?",
      "How do you maintain hope during difficult periods?",
      "What's one thing you've learned about managing stress?"
    ],
    'deep': [
      "What's something that completely changed how you see the world?",
      "If you could ask the universe one question, what would it be?",
      "What do you think makes a life meaningful?",
      "How do you think we'll be different as humans in 100 years?",
      "What's a belief you held strongly but later changed your mind about?"
    ],
    'general': [
      "What's something you're genuinely excited about right now?",
      "If you could have a 3-hour conversation with anyone, who would it be?",
      "What's the most interesting thing you've learned recently?",
      "What's a topic you could talk about for hours?",
      "What's something you've always wanted to understand better?"
    ],
    'vents': [
      "What's something that's been on your mind lately?",
      "Have you ever felt misunderstood for talking a lot?",
      "What's something you wish people would just listen to?",
      "When was the last time you felt truly heard?",
      "What's something you need to get off your chest?"
    ],
    'ramble': [
      "What's been weighing on your heart that you need to say out loud?",
      "Tell us about a time when everything changed for you...",
      "What's a story you've been carrying that needs to be shared?",
      "What would you say if you knew everyone would really listen?",
      "What's something you've never told anyone but wish you could?"
    ],
    'meaningful': [
      "What conversation changed the way you see yourself?",
      "If you could solve one problem in the world through dialogue, what would it be?",
      "What's something you believe that most people disagree with?",
      "How has a difficult conversation made you a better person?",
      "What question do you wish people would ask you more often?"
    ],
    'connections': [
      "What's something you're passionate about that lights up your whole face?",
      "What's your love language and how did you discover it?",
      "What does your ideal deep conversation look like?",
      "What's something about you that someone could only learn by really listening?",
      "If we talked for hours, what would you want me to remember about you?"
    ],
    'spiritual': [
      "What universal law or spiritual principle guides your daily life?",
      "How do you experience synchronicity and meaningful coincidences?",
      "What's your understanding of how thoughts create reality?",
      "How has your spiritual journey changed the way you communicate?",
      "What wisdom or insight has shifted your entire perspective recently?"
    ],
    'young-healing': [
      "What family pattern are you working to break or change?",
      "How has realizing 'our parents didn't have it right' affected your growth?",
      "What would you tell your younger self about family expectations?",
      "How are you creating healthier boundaries than what you grew up with?",
      "What healing conversation with a parent or family member changed everything?"
    ],
    'adult-healing': [
      "What old pattern or belief are you finally ready to release?",
      "How has your perspective on healing changed over the years?",
      "What wisdom would you share with someone just starting their healing journey?",
      "How do you practice self-compassion for your younger choices?",
      "What does 'breaking generational cycles' mean to you personally?"
    ],
    'seasonal': [
      "What holiday tradition means the most to you and why?",
      "How do you celebrate the changing seasons in your own way?",
      "Share a favorite holiday memory that still makes you smile",
      "What's your take on creating new traditions vs keeping old ones?",
      "How do different seasons affect your mood and conversations?"
    ],
    'books': [
      "What book completely changed your perspective on life?",
      "Share a quote or passage that you think about often",
      "What's the most recent book that made you want to discuss it immediately?",
      "Do you prefer fiction that helps you escape or non-fiction that teaches?",
      "What book would you recommend to someone going through a tough time?"
    ],
    'languages': [
      "What language do you wish you could speak fluently and why?",
      "Share a funny mistake you made while learning a new language",
      "How has learning another language changed how you think?",
      "What's the most beautiful word you know in any language?",
      "Do you think differently when you speak different languages?"
    ],
    'college': [
      "What's the biggest lesson college taught you outside of academics?",
      "How are you handling the pressure of 'figuring it all out'?",
      "What advice would you give to someone starting their first semester?",
      "Share a moment when you realized you were becoming more independent",
      "How do you balance studying with actually enjoying these years?"
    ],
    'life-transitions': [
      "What surprised you most about this new phase of life?",
      "How are you rediscovering who you are outside of your previous role?",
      "What new interest or hobby have you started exploring?",
      "Share advice for others going through similar life transitions",
      "How has your relationship with yourself changed during this transition?"
    ],
    'career': [
      "What career advice do you wish someone had given you earlier?",
      "How do you handle work-life balance in your current field?",
      "Share a professional challenge that taught you something valuable",
      "What skills do you think are most important for career growth?",
      "How do you stay motivated during difficult work periods?"
    ]
  };

  const getStarters = () => {
    return startersByCategory[roomCategory as keyof typeof startersByCategory] || startersByCategory.general;
  };

  const [currentStarters, setCurrentStarters] = useState(getStarters());
  
  const shuffleStarters = () => {
    const starters = getStarters();
    const shuffled = [...starters].sort(() => Math.random() - 0.5);
    setCurrentStarters(shuffled);
  };

  if (!isExpanded) {
    return (
      <div className="mb-4">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsExpanded(true)}
          className="text-teal-600 border-teal-300 hover:bg-teal-50"
        >
          <MessageCircle className="w-4 h-4 mr-2" />
          Need a conversation starter?
        </Button>
      </div>
    );
  }

  return (
    <div className="mb-4 p-4 bg-teal-50 border border-teal-200 rounded-lg">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-medium text-teal-800">Conversation Starters</h4>
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={shuffleStarters}
            className="text-teal-600 hover:text-teal-700"
          >
            <Shuffle className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(false)}
            className="text-teal-600 hover:text-teal-700"
          >
            ×
          </Button>
        </div>
      </div>
      
      <div className="space-y-2">
        {currentStarters.slice(0, 3).map((starter, index) => (
          <button
            key={index}
            onClick={() => onStarterSelect(starter)}
            className="w-full text-left p-3 bg-white border border-teal-200 rounded-lg hover:bg-teal-25 hover:border-teal-300 transition-colors text-sm"
          >
            "{starter}"
          </button>
        ))}
      </div>
      
      <p className="text-xs text-teal-600 mt-3 text-center">
        Click any starter to use it in your message
      </p>
    </div>
  );
}