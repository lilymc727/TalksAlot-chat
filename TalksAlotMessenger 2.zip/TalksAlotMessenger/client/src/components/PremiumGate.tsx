import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Crown, Lock, Star, Check } from 'lucide-react';
import { SubscriptionModal } from './SubscriptionModal';

interface PremiumGateProps {
  hasAccess: boolean;
  isInTrial: boolean;
  hoursLeft: number;
  children: React.ReactNode;
}

export function PremiumGate({ hasAccess, isInTrial, hoursLeft, children }: PremiumGateProps) {
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  if (hasAccess) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Crown className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">
            Join TalksAlot Premium
          </h1>
          <p className="text-gray-600">
            Unlimited access to your conversation tribe for just $8/month
          </p>
        </div>

        {/* Trial Notice */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-center space-x-2 mb-2">
            <Star className="w-5 h-5 text-blue-600" />
            <span className="font-semibold text-blue-800">12-Hour Free Trial</span>
          </div>
          <p className="text-sm text-blue-700">
            Full access to everything. After 12 hours, just $8/month automatically charges.
            Cancel anytime during trial with no charge.
          </p>
        </div>

        {/* Features */}
        <div className="space-y-3 mb-8">
          {[
            "30+ specialized chat rooms",
            "RambleRealm 20-minute speaking sessions",
            "DialogueDen for meaningful conversations",
            "BabbleBae for deeper connections",
            "Video chat in all rooms",
            "Message reactions & advanced features",
            "Priority community support",
            "No ads, ever"
          ].map((feature, index) => (
            <div key={index} className="flex items-center space-x-3">
              <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
              <span className="text-gray-700">{feature}</span>
            </div>
          ))}
        </div>

        {/* Pricing */}
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-gray-800">$8/month</div>
              <div className="text-sm text-gray-600">or $80/year (save $16)</div>
            </div>
            <div className="text-right">
              <div className="text-sm text-green-600 font-medium">Trial: FREE</div>
              <div className="text-xs text-gray-500">12 hours to explore</div>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <Button
          onClick={() => setShowSubscriptionModal(true)}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-4 text-lg"
        >
          <Crown className="w-5 h-5 mr-2" />
          Start 12-Hour Free Trial
        </Button>

        <p className="text-xs text-gray-500 text-center mt-4">
          Secure payment by Stripe • Cancel anytime • No hidden fees
        </p>

        {showSubscriptionModal && (
          <SubscriptionModal
            isOpen={showSubscriptionModal}
            onClose={() => setShowSubscriptionModal(false)}
            onUpgrade={() => setShowSubscriptionModal(false)}
          />
        )}
      </div>
    </div>
  );
}