import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Crown, Clock, Star } from 'lucide-react';
import { SubscriptionModal } from './SubscriptionModal';

interface AccessGateProps {
  children: React.ReactNode;
  userHasAccess: boolean;
  isInTrial: boolean;
  hoursLeft: number;
}

export function AccessGate({ children, userHasAccess, isInTrial, hoursLeft }: AccessGateProps) {
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  if (userHasAccess) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center">
        <div className="w-16 h-16 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-6">
          <Crown className="w-8 h-8 text-white" />
        </div>
        
        <h2 className="text-2xl font-bold text-gray-800 mb-4">
          Your Trial Has Ended
        </h2>
        
        <p className="text-gray-600 mb-6">
          Thanks for exploring TalksAlot! Ready to join the conversation community for just $8/month?
        </p>

        <div className="bg-teal-50 border border-teal-200 rounded-lg p-4 mb-6">
          <h3 className="font-semibold text-teal-800 mb-2">What You'll Get:</h3>
          <ul className="text-sm text-teal-700 space-y-1 text-left">
            <li>• All 30+ specialized chat rooms</li>
            <li>• RambleRealm timed speaking sessions</li>
            <li>• DialogueDen & BabbleBae</li>
            <li>• Video chat in all rooms</li>
            <li>• Priority community support</li>
          </ul>
        </div>

        <Button
          onClick={() => setShowSubscriptionModal(true)}
          className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 mb-4"
        >
          <Crown className="w-4 h-4 mr-2" />
          Upgrade to Premium - $8/month
        </Button>

        <p className="text-xs text-gray-500">
          Secure payment • Cancel anytime • Join thousands of conversation lovers
        </p>

        {showSubscriptionModal && (
          <SubscriptionModal
            isOpen={showSubscriptionModal}
            onClose={() => setShowSubscriptionModal(false)}
            onUpgrade={() => setShowSubscriptionModal(false)}
          />
        )}
      </div>
    </div>
  );
}