import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Mic, MicOff, Play, Pause, RotateCcw, Users } from 'lucide-react';

interface RambleTimerProps {
  isActive: boolean;
  currentSpeaker: string | null;
  currentUserId: string;
  onStartRamble: () => void;
  onEndRamble: () => void;
  onPassMic: (userId: string) => void;
  onAllowInterrupt: () => void;
  participants: Array<{ id: string; name: string; isListening: boolean }>;
}

export function RambleTimer({ 
  isActive, 
  currentSpeaker, 
  currentUserId, 
  onStartRamble, 
  onEndRamble, 
  onPassMic, 
  onAllowInterrupt,
  participants 
}: RambleTimerProps) {
  const [timeLeft, setTimeLeft] = useState(20 * 60); // 20 minutes in seconds
  const [isRunning, setIsRunning] = useState(false);
  const [canInterrupt, setCanInterrupt] = useState(false);

  const isCurrentSpeaker = currentSpeaker === currentUserId;
  const hasActiveSpeaker = currentSpeaker !== null;

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            setIsRunning(false);
            onEndRamble();
            return 20 * 60; // Reset to 20 minutes
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isRunning, timeLeft, onEndRamble]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartRamble = () => {
    setTimeLeft(20 * 60);
    setIsRunning(true);
    setCanInterrupt(false);
    onStartRamble();
  };

  const handleEndRamble = () => {
    setIsRunning(false);
    setTimeLeft(20 * 60);
    setCanInterrupt(false);
    onEndRamble();
  };

  const handleAllowInterrupt = () => {
    setCanInterrupt(true);
    onAllowInterrupt();
  };

  return (
    <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-lg p-4 mb-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center">
            <Mic className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-purple-800">RambleRealm</h3>
            <p className="text-sm text-purple-600">20-minute speaking sessions</p>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-2xl font-mono font-bold text-purple-800">
            {formatTime(timeLeft)}
          </div>
          <div className="text-xs text-purple-600">
            {isRunning ? 'Time remaining' : 'Ready to start'}
          </div>
        </div>
      </div>

      {/* Current Speaker Status */}
      {hasActiveSpeaker && (
        <div className="mb-4 p-3 bg-white rounded-lg border border-purple-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <span className="font-medium text-gray-800">
                {isCurrentSpeaker ? 'You are speaking' : `${currentSpeaker} is speaking`}
              </span>
            </div>
            
            {isCurrentSpeaker && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleAllowInterrupt}
                disabled={canInterrupt}
                className="text-purple-600 border-purple-300"
              >
                {canInterrupt ? 'Interrupts allowed' : 'Allow interrupts'}
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Controls */}
      <div className="flex items-center space-x-3 mb-4">
        {!hasActiveSpeaker ? (
          <Button
            onClick={handleStartRamble}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            <Play className="w-4 h-4 mr-2" />
            Start My Ramble
          </Button>
        ) : isCurrentSpeaker ? (
          <div className="flex space-x-2">
            <Button
              onClick={() => setIsRunning(!isRunning)}
              variant="outline"
              className="border-purple-300 text-purple-600"
            >
              {isRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
              {isRunning ? 'Pause' : 'Resume'}
            </Button>
            <Button
              onClick={handleEndRamble}
              variant="outline"
              className="border-red-300 text-red-600"
            >
              <MicOff className="w-4 h-4 mr-2" />
              End Ramble
            </Button>
          </div>
        ) : (
          <div className="flex space-x-2">
            {canInterrupt && (
              <Button
                onClick={handleStartRamble}
                variant="outline"
                className="border-purple-300 text-purple-600"
              >
                <Mic className="w-4 h-4 mr-2" />
                Jump In
              </Button>
            )}
            <Button
              onClick={() => onPassMic(currentUserId)}
              variant="outline"
              className="border-purple-300 text-purple-600"
            >
              Request to Speak
            </Button>
          </div>
        )}
      </div>

      {/* Participants */}
      <div className="border-t border-purple-200 pt-3">
        <div className="flex items-center space-x-2 mb-2">
          <Users className="w-4 h-4 text-purple-600" />
          <span className="text-sm font-medium text-purple-800">
            Listeners ({participants.filter(p => p.isListening).length})
          </span>
        </div>
        <div className="flex flex-wrap gap-2">
          {participants.filter(p => p.isListening).map(participant => (
            <div 
              key={participant.id}
              className="flex items-center space-x-1 bg-white px-2 py-1 rounded-md border border-purple-200"
            >
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-xs text-gray-700">{participant.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Instructions */}
      <div className="mt-4 p-3 bg-purple-100 rounded-lg">
        <h4 className="font-medium text-purple-800 mb-2">How RambleRealm Works:</h4>
        <ul className="text-sm text-purple-700 space-y-1">
          <li>• Get 20 minutes to ramble and get things off your chest</li>
          <li>• Others listen quietly until your time is up</li>
          <li>• You can allow interrupts if you want feedback</li>
          <li>• After your time, someone else can take the mic</li>
          <li>• Perfect for venting, storytelling, or working through thoughts</li>
        </ul>
      </div>
    </div>
  );
}