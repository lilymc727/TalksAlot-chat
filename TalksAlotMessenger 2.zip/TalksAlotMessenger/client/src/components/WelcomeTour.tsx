import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { X, ChevronRight, ChevronLeft } from 'lucide-react';

interface WelcomeTourProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WelcomeTour({ isOpen, onClose }: WelcomeTourProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const tourSteps = [
    {
      title: "Welcome to TalksAlot!",
      content: "Have people said you talk a lot? You've found your tribe! This isn't primarily a dating app - it's for conversation lovers who feel like burdens to non-talkers. Here, everyone deserves to be heard.",
      emoji: "🎉"
    },
    {
      title: "Fair Warning",
      content: "We talk A LOT here! If you prefer quick chats, you'll definitely notice our enthusiasm. We're the people who turn 'How was your day?' into 2-hour conversations.",
      emoji: "😄"
    },
    {
      title: "Your Profile Matters",
      content: "Set up your profile with your talk style (Fast Talker, Deep Thinker, etc.) and favorite topics. This helps us connect you with conversation companions who appreciate your enthusiasm!",
      emoji: "👤"
    },
    {
      title: "Instant Matching",
      content: "Use 'Talk Now' to instantly connect with someone who shares your interests. Perfect for when you're bursting with thoughts and need someone to listen!",
      emoji: "⚡"
    },
    {
      title: "Themed Chat Rooms",
      content: "Join 28+ rooms from Bug Enthusiasts 🐛 to Deep Thinkers 🤔. Each room has its own vibe and community of passionate talkers.",
      emoji: "🏠"
    },
    {
      title: "Voice & Video Chat",
      content: "Enable video chat in group rooms to see your tribe! Nothing beats face-to-face conversation with people who actually want to hear your stories.",
      emoji: "📹"
    },
    {
      title: "Every Room is Safe",
      content: "ALL rooms in TalksAlot are safe spaces with zero tolerance for negativity. From Bug Enthusiasts to Deep Thinkers - we actively protect against trolls and harassment so you can talk freely.",
      emoji: "🛡️"
    },
    {
      title: "Community Guidelines",
      content: "We're all about celebrating conversation while maintaining respect. Check out our guidelines to understand how we keep this space special.",
      emoji: "📋"
    },
    {
      title: "You're Home!",
      content: "Ready to talk your heart out? Your tribe is waiting. Remember: here, loving to talk isn't too much - it's exactly enough.",
      emoji: "🏡"
    }
  ];

  useEffect(() => {
    if (isOpen) {
      setCurrentStep(0);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleNext = () => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const currentStepData = tourSteps[currentStep];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            <span className="text-3xl">{currentStepData.emoji}</span>
            <h2 className="text-xl font-bold text-gray-800">{currentStepData.title}</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6">
          <p className="text-gray-700 leading-relaxed mb-6">
            {currentStepData.content}
          </p>

          {/* Progress Dots */}
          <div className="flex justify-center space-x-2 mb-6">
            {tourSteps.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentStep ? 'bg-teal-600' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>

          {/* Step Counter */}
          <div className="text-center text-sm text-gray-500 mb-6">
            Step {currentStep + 1} of {tourSteps.length}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t bg-gray-50 rounded-b-2xl">
          <Button
            variant="outline"
            onClick={handlePrev}
            disabled={currentStep === 0}
            className="flex items-center"
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Back
          </Button>

          <Button
            onClick={handleNext}
            className="bg-teal-600 hover:bg-teal-700 flex items-center"
          >
            {currentStep === tourSteps.length - 1 ? (
              "Let's Talk!"
            ) : (
              <>
                Next
                <ChevronRight className="w-4 h-4 ml-1" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}