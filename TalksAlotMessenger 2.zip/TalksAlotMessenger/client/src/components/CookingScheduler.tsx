import { useState } from 'react';
import { Calendar, Clock, Users, ChefHat, Video } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CookingSession {
  id: string;
  title: string;
  host: string;
  time: string;
  date: string;
  maxParticipants: number;
  currentParticipants: number;
  recipe: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  estimatedTime: string;
}

interface CookingSchedulerProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: any;
}

export function CookingScheduler({ isOpen, onClose, currentUser }: CookingSchedulerProps) {
  const [selectedSession, setSelectedSession] = useState<CookingSession | null>(null);
  const [showCreateSession, setShowCreateSession] = useState(false);
  const { toast } = useToast();

  // Mock cooking sessions - in real app, fetch from backend
  const upcomingSessions: CookingSession[] = [
    {
      id: '1',
      title: 'Homemade Pasta Night',
      host: 'Chef Sarah',
      time: '7:00 PM',
      date: 'Today',
      maxParticipants: 8,
      currentParticipants: 5,
      recipe: 'Fresh Fettuccine with Alfredo',
      difficulty: 'Medium',
      estimatedTime: '90 minutes'
    },
    {
      id: '2', 
      title: 'Sunday Brunch Spread',
      host: 'Mike K.',
      time: '11:00 AM',
      date: 'Tomorrow',
      maxParticipants: 6,
      currentParticipants: 3,
      recipe: 'Pancakes, Eggs Benedict & Fresh OJ',
      difficulty: 'Easy',
      estimatedTime: '2 hours'
    },
    {
      id: '3',
      title: 'Sourdough Bread Workshop',
      host: 'Baker Emma',
      time: '2:00 PM',
      date: 'Wednesday',
      maxParticipants: 10,
      currentParticipants: 7,
      recipe: 'Traditional Sourdough Loaf',
      difficulty: 'Hard',
      estimatedTime: '4 hours'
    }
  ];

  const joinSession = (session: CookingSession) => {
    toast({
      title: "Joined Cooking Session!",
      description: `You're now signed up for ${session.title} with ${session.host}`,
    });
    onClose();
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'text-green-600 bg-green-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      case 'Hard': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <ChefHat className="w-8 h-8 text-orange-500" />
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Cook Together Kitchen</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              ✕
            </button>
          </div>

          <div className="mb-6">
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Join live cooking sessions with community members! Cook together via video chat, share techniques, and learn new recipes.
            </p>
            
            <div className="flex gap-3 mb-6">
              <button
                onClick={() => setShowCreateSession(false)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  !showCreateSession 
                    ? 'bg-orange-500 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300'
                }`}
              >
                <Calendar className="w-4 h-4 inline mr-2" />
                Upcoming Sessions
              </button>
              <button
                onClick={() => setShowCreateSession(true)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  showCreateSession 
                    ? 'bg-orange-500 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300'
                }`}
              >
                <ChefHat className="w-4 h-4 inline mr-2" />
                Host Session
              </button>
            </div>
          </div>

          {!showCreateSession ? (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold mb-4">Join a Cooking Session</h3>
              {upcomingSessions.map(session => (
                <div key={session.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-lg font-semibold text-gray-800 dark:text-white">
                          {session.title}
                        </h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(session.difficulty)}`}>
                          {session.difficulty}
                        </span>
                      </div>
                      
                      <div className="text-sm text-gray-600 dark:text-gray-300 space-y-1">
                        <div className="flex items-center gap-4">
                          <span className="flex items-center gap-1">
                            <ChefHat className="w-4 h-4" />
                            Host: {session.host}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {session.date} at {session.time}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            {session.currentParticipants}/{session.maxParticipants} joined
                          </span>
                        </div>
                        <p className="font-medium text-gray-700 dark:text-gray-200">
                          Recipe: {session.recipe}
                        </p>
                        <p className="text-xs">
                          Estimated time: {session.estimatedTime}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col gap-2 ml-4">
                      <button
                        onClick={() => joinSession(session)}
                        disabled={session.currentParticipants >= session.maxParticipants}
                        className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2"
                      >
                        <Video className="w-4 h-4" />
                        {session.currentParticipants >= session.maxParticipants ? 'Full' : 'Join'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold mb-4">Host a Cooking Session</h3>
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Session Title</label>
                    <input
                      type="text"
                      placeholder="e.g., Italian Night - Fresh Pasta Making"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Date</label>
                      <input
                        type="date"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Time</label>
                      <input
                        type="time"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2">Recipe/Dish</label>
                    <input
                      type="text"
                      placeholder="What will you be cooking?"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Difficulty</label>
                      <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500">
                        <option value="Easy">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Max Participants</label>
                      <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500">
                        <option value="4">4 people</option>
                        <option value="6">6 people</option>
                        <option value="8">8 people</option>
                        <option value="10">10 people</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Duration</label>
                      <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500">
                        <option value="60">1 hour</option>
                        <option value="90">1.5 hours</option>
                        <option value="120">2 hours</option>
                        <option value="180">3 hours</option>
                      </select>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2">Ingredients & Equipment Needed</label>
                    <textarea
                      placeholder="List what participants should have ready..."
                      rows={3}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    />
                  </div>
                  
                  <button
                    onClick={() => {
                      toast({
                        title: "Cooking Session Created!",
                        description: "Your session has been scheduled and community members can now join",
                      });
                      setShowCreateSession(false);
                    }}
                    className="w-full bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition-colors"
                  >
                    Create Cooking Session
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}