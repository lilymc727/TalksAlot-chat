import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { X, Check, Crown, Star } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToastContext } from '@/components/ToastProvider';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: () => void;
}

export function SubscriptionModal({ isOpen, onClose, onUpgrade }: SubscriptionModalProps) {
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('monthly');
  const { toast } = useToastContext();

  const createSubscriptionMutation = useMutation({
    mutationFn: (planType: string) => {
      const currentUser = JSON.parse(localStorage.getItem("talksalot-user") || "{}");
      return apiRequest("/api/create-subscription", {
        method: "POST",
        body: JSON.stringify({ 
          planType,
          userId: currentUser.id,
          userEmail: currentUser.email || `${currentUser.id}@talksalot.com`
        }),
      });
    },
    onSuccess: (data) => {
      window.location.href = data.checkoutUrl;
    },
    onError: () => {
      toast({
        title: "Payment Error",
        description: "Unable to start subscription. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSubscribe = () => {
    createSubscriptionMutation.mutate(selectedPlan);
  };

  if (!isOpen) return null;

  const monthlyPrice = 8;
  const yearlyPrice = 80; // 2 months free
  const savingsAmount = (monthlyPrice * 12) - yearlyPrice;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full mx-4">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-teal-500 to-cyan-500 text-white p-6 rounded-t-2xl">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onClose}
            className="absolute top-4 right-4 text-white hover:bg-white/20"
          >
            <X className="w-5 h-5" />
          </Button>
          
          <div className="flex items-center space-x-3 mb-4">
            <Crown className="w-8 h-8" />
            <div>
              <h2 className="text-2xl font-bold">Join TalksAlot Premium</h2>
              <p className="text-teal-100">Unlimited access to your conversation tribe</p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Plan Selection */}
          <div className="space-y-3 mb-6">
            <div 
              className={`border-2 rounded-lg p-4 cursor-pointer transition-colors ${
                selectedPlan === 'monthly' 
                  ? 'border-teal-500 bg-teal-50' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => setSelectedPlan('monthly')}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">Monthly Plan</h3>
                  <p className="text-sm text-gray-600">Perfect for trying out the community</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">${monthlyPrice}</div>
                  <div className="text-sm text-gray-500">per month</div>
                </div>
              </div>
            </div>

            <div 
              className={`border-2 rounded-lg p-4 cursor-pointer transition-colors relative ${
                selectedPlan === 'yearly' 
                  ? 'border-teal-500 bg-teal-50' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => setSelectedPlan('yearly')}
            >
              <div className="absolute -top-2 left-4 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                Save ${savingsAmount}
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">Yearly Plan</h3>
                  <p className="text-sm text-gray-600">Best value - 2 months free!</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">${yearlyPrice}</div>
                  <div className="text-sm text-gray-500">per year</div>
                  <div className="text-xs text-green-600">~$6.67/month</div>
                </div>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h4 className="font-semibold mb-3">What you get with Premium:</h4>
            <div className="space-y-2">
              {[
                "Access to all 30+ specialized chat rooms",
                "RambleRealm 20-minute speaking sessions",
                "DialogueDen for meaningful conversations",
                "BabbleBae for deeper connections",
                "Video chat in all rooms",
                "Advanced features: reactions, bookmarks, karma",
                "Priority support from our community team",
                "No ads, ever"
              ].map((feature, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <Check className="w-4 h-4 text-green-500" />
                  <span className="text-sm">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Trial Notice */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <div className="flex items-center space-x-2 mb-2">
              <Star className="w-5 h-5 text-blue-600" />
              <span className="font-medium text-blue-800">Free 12-Hour Trial</span>
            </div>
            <p className="text-sm text-blue-700">
              Explore all rooms and features. Perfect time to experience the community and decide if it's for you.
            </p>
          </div>

          {/* Action Button */}
          <Button
            onClick={handleSubscribe}
            disabled={createSubscriptionMutation.isPending}
            className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3"
          >
            {createSubscriptionMutation.isPending 
              ? "Starting your trial..." 
              : `Start 12-Hour Free Trial - ${selectedPlan === 'monthly' ? `$${monthlyPrice}/month` : `$${yearlyPrice}/year`}`
            }
          </Button>

          <p className="text-xs text-gray-500 text-center mt-3">
            Secure payment powered by Stripe. Cancel anytime.
          </p>
        </div>
      </div>
    </div>
  );
}