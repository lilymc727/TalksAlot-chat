import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Bell, BellOff, X } from 'lucide-react';

interface NotificationSettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NotificationSettings({ isOpen, onClose }: NotificationSettingsProps) {
  const [settings, setSettings] = useState({
    newMessages: true,
    roomActivity: true,
    matchFound: true,
    userJoined: false,
    userLeft: false,
    soundEnabled: true,
    pushEnabled: false
  });

  useEffect(() => {
    // Load settings from localStorage
    const savedSettings = localStorage.getItem('talksalot-notifications');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
  }, []);

  const updateSetting = (key: keyof typeof settings, value: boolean) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    localStorage.setItem('talksalot-notifications', JSON.stringify(newSettings));
  };

  const requestPushPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      updateSetting('pushEnabled', permission === 'granted');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            <Bell className="w-6 h-6 text-teal-600" />
            <h2 className="text-xl font-bold text-gray-800">Notification Settings</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          <div>
            <h3 className="font-semibold text-gray-800 mb-3">Chat Notifications</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium text-gray-700">New Messages</label>
                  <p className="text-sm text-gray-500">Get notified when someone responds</p>
                </div>
                <Button
                  variant={settings.newMessages ? "default" : "outline"}
                  size="sm"
                  onClick={() => updateSetting('newMessages', !settings.newMessages)}
                  className={settings.newMessages ? "bg-teal-600 hover:bg-teal-700" : ""}
                >
                  {settings.newMessages ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium text-gray-700">Room Activity</label>
                  <p className="text-sm text-gray-500">Active conversations in your rooms</p>
                </div>
                <Button
                  variant={settings.roomActivity ? "default" : "outline"}
                  size="sm"
                  onClick={() => updateSetting('roomActivity', !settings.roomActivity)}
                  className={settings.roomActivity ? "bg-teal-600 hover:bg-teal-700" : ""}
                >
                  {settings.roomActivity ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium text-gray-700">Match Found</label>
                  <p className="text-sm text-gray-500">When instant matching finds someone</p>
                </div>
                <Button
                  variant={settings.matchFound ? "default" : "outline"}
                  size="sm"
                  onClick={() => updateSetting('matchFound', !settings.matchFound)}
                  className={settings.matchFound ? "bg-teal-600 hover:bg-teal-700" : ""}
                >
                  {settings.matchFound ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-800 mb-3">Room Events</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium text-gray-700">User Joined</label>
                  <p className="text-sm text-gray-500">When someone joins your room</p>
                </div>
                <Button
                  variant={settings.userJoined ? "default" : "outline"}
                  size="sm"
                  onClick={() => updateSetting('userJoined', !settings.userJoined)}
                  className={settings.userJoined ? "bg-teal-600 hover:bg-teal-700" : ""}
                >
                  {settings.userJoined ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium text-gray-700">User Left</label>
                  <p className="text-sm text-gray-500">When someone leaves your room</p>
                </div>
                <Button
                  variant={settings.userLeft ? "default" : "outline"}
                  size="sm"
                  onClick={() => updateSetting('userLeft', !settings.userLeft)}
                  className={settings.userLeft ? "bg-teal-600 hover:bg-teal-700" : ""}
                >
                  {settings.userLeft ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-800 mb-3">Delivery Options</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium text-gray-700">Sound Alerts</label>
                  <p className="text-sm text-gray-500">Play notification sounds</p>
                </div>
                <Button
                  variant={settings.soundEnabled ? "default" : "outline"}
                  size="sm"
                  onClick={() => updateSetting('soundEnabled', !settings.soundEnabled)}
                  className={settings.soundEnabled ? "bg-teal-600 hover:bg-teal-700" : ""}
                >
                  {settings.soundEnabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium text-gray-700">Browser Push</label>
                  <p className="text-sm text-gray-500">Get notifications when tab is closed</p>
                </div>
                <Button
                  variant={settings.pushEnabled ? "default" : "outline"}
                  size="sm"
                  onClick={settings.pushEnabled ? () => updateSetting('pushEnabled', false) : requestPushPermission}
                  className={settings.pushEnabled ? "bg-teal-600 hover:bg-teal-700" : ""}
                >
                  {settings.pushEnabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-sm text-yellow-800">
              <strong>Note:</strong> With great conversation comes great notification responsibility! 
              Adjust these settings to match your chat enthusiasm level.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t bg-gray-50 rounded-b-2xl">
          <Button onClick={onClose} className="w-full bg-teal-600 hover:bg-teal-700">
            Save Settings
          </Button>
        </div>
      </div>
    </div>
  );
}