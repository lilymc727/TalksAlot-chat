import { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Video, VideoOff, Phone, PhoneOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SimplePeer from 'simple-peer';

interface VideoChatProps {
  roomId: string;
  userId: string;
  userName: string;
  isEnabled: boolean;
  onToggle: () => void;
}

interface PeerConnection {
  peer: SimplePeer.Instance;
  userId: string;
  userName: string;
}

export function VideoChat({ roomId, userId, userName, isEnabled, onToggle }: VideoChatProps) {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [peers, setPeers] = useState<Map<string, PeerConnection>>(new Map());
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isInCall, setIsInCall] = useState(false);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (isEnabled && isInCall) {
      startCall();
    } else {
      endCall();
    }
    
    return () => {
      endCall();
    };
  }, [isEnabled, isInCall]);

  const startCall = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true, 
        audio: true 
      });
      
      setLocalStream(stream);
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      // Connect to WebSocket for signaling - always use secure connection
      const protocol = "wss:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const socket = new WebSocket(wsUrl);
      socketRef.current = socket;

      socket.onopen = () => {
        socket.send(JSON.stringify({
          type: 'join-video-room',
          roomId,
          userId,
          userName
        }));
      };

      socket.onmessage = (event) => {
        const message = JSON.parse(event.data);
        handleSignalingMessage(message, stream);
      };

    } catch (error) {
      console.error('Error accessing media devices:', error);
    }
  };

  const endCall = () => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }

    peers.forEach(({ peer }) => peer.destroy());
    setPeers(new Map());

    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }

    if (localVideoRef.current) {
      localVideoRef.current.srcObject = null;
    }
  };

  const handleSignalingMessage = (message: any, stream: MediaStream) => {
    switch (message.type) {
      case 'user-joined-video':
        if (message.userId !== userId) {
          createPeerConnection(message.userId, message.userName, true, stream);
        }
        break;
      
      case 'video-offer':
        if (message.targetUserId === userId) {
          createPeerConnection(message.fromUserId, message.fromUserName, false, stream);
          const peer = peers.get(message.fromUserId)?.peer;
          if (peer) {
            peer.signal(message.offer);
          }
        }
        break;
      
      case 'video-answer':
        if (message.targetUserId === userId) {
          const peer = peers.get(message.fromUserId)?.peer;
          if (peer) {
            peer.signal(message.answer);
          }
        }
        break;
      
      case 'ice-candidate':
        if (message.targetUserId === userId) {
          const peer = peers.get(message.fromUserId)?.peer;
          if (peer) {
            peer.signal(message.candidate);
          }
        }
        break;
    }
  };

  const createPeerConnection = (
    peerUserId: string, 
    peerUserName: string, 
    initiator: boolean, 
    stream: MediaStream
  ) => {
    const peer = new SimplePeer({
      initiator,
      trickle: false,
      stream
    });

    peer.on('signal', (data) => {
      if (socketRef.current) {
        socketRef.current.send(JSON.stringify({
          type: initiator ? 'video-offer' : 'video-answer',
          targetUserId: peerUserId,
          fromUserId: userId,
          fromUserName: userName,
          [initiator ? 'offer' : 'answer']: data
        }));
      }
    });

    peer.on('stream', (remoteStream) => {
      // Create video element for remote stream
      const videoElement = document.createElement('video');
      videoElement.srcObject = remoteStream;
      videoElement.autoplay = true;
      videoElement.playsInline = true;
      videoElement.className = 'w-full h-full object-cover rounded-lg';
      
      const container = document.getElementById(`remote-video-${peerUserId}`);
      if (container) {
        container.appendChild(videoElement);
      }
    });

    setPeers(prev => new Map(prev.set(peerUserId, { peer, userId: peerUserId, userName: peerUserName })));
  };

  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = isMuted;
      });
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = isVideoOff;
      });
      setIsVideoOff(!isVideoOff);
    }
  };

  const joinCall = () => {
    setIsInCall(true);
  };

  const leaveCall = () => {
    setIsInCall(false);
    endCall();
  };

  if (!isEnabled) {
    return (
      <div className="bg-teal-50 border border-teal-200 rounded-lg p-4 mb-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-teal-800">Voice & Video Chat</h3>
            <p className="text-sm text-teal-600">Connect face-to-face with your tribe</p>
          </div>
          <Button onClick={onToggle} className="bg-teal-600 hover:bg-teal-700">
            Enable Video Chat
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border rounded-lg p-4 mb-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold">Voice & Video Chat</h3>
        <Button onClick={onToggle} variant="outline" size="sm">
          Disable
        </Button>
      </div>

      {!isInCall ? (
        <div className="text-center">
          <Button onClick={joinCall} className="bg-teal-600 hover:bg-teal-700">
            <Video className="w-4 h-4 mr-2" />
            Join Video Call
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Local Video */}
          <div className="relative">
            <video
              ref={localVideoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-48 object-cover rounded-lg bg-gray-900"
            />
            <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-sm">
              You ({userName})
            </div>
          </div>

          {/* Remote Videos */}
          <div className="grid grid-cols-2 gap-2">
            {Array.from(peers.values()).map(({ userId: peerUserId, userName: peerUserName }) => (
              <div key={peerUserId} className="relative">
                <div 
                  id={`remote-video-${peerUserId}`}
                  className="w-full h-32 bg-gray-900 rounded-lg flex items-center justify-center"
                >
                  <span className="text-white text-sm">Connecting to {peerUserName}...</span>
                </div>
                <div className="absolute bottom-1 left-1 bg-black bg-opacity-50 text-white px-1 py-0.5 rounded text-xs">
                  {peerUserName}
                </div>
              </div>
            ))}
          </div>

          {/* Controls */}
          <div className="flex justify-center space-x-4">
            <Button
              onClick={toggleMute}
              variant={isMuted ? "destructive" : "outline"}
              size="sm"
            >
              {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </Button>
            
            <Button
              onClick={toggleVideo}
              variant={isVideoOff ? "destructive" : "outline"}
              size="sm"
            >
              {isVideoOff ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
            </Button>
            
            <Button
              onClick={leaveCall}
              variant="destructive"
              size="sm"
            >
              <PhoneOff className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}