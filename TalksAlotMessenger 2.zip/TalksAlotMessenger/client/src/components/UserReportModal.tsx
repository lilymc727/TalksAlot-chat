import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { X, Flag } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToastContext } from '@/components/ToastProvider';

interface UserReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportedUserId: string;
  reportedUserName: string;
  messageId?: string;
  roomId?: string;
}

export function UserReportModal({ 
  isOpen, 
  onClose, 
  reportedUserId, 
  reportedUserName,
  messageId,
  roomId 
}: UserReportModalProps) {
  const [reason, setReason] = useState('');
  const [description, setDescription] = useState('');
  const { toast } = useToastContext();

  const reportMutation = useMutation({
    mutationFn: (reportData: any) => apiRequest("/api/reports", {
      method: "POST",
      body: JSON.stringify(reportData),
    }),
    onSuccess: () => {
      toast({ 
        title: "Report Submitted", 
        description: "Thank you for helping keep TalksAlot safe. We'll review this report promptly." 
      });
      onClose();
      setReason('');
      setDescription('');
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason) return;

    const currentUser = JSON.parse(localStorage.getItem("talksalot-user") || "{}");
    
    reportMutation.mutate({
      reporterId: currentUser.id,
      reportedUserId,
      reason,
      description,
      messageId,
      roomId,
    });
  };

  if (!isOpen) return null;

  const reasons = [
    'Harassment or bullying',
    'Inappropriate content',
    'Spam or advertising',
    'Hate speech',
    'Making others feel unwelcome',
    'Violating safe space rules',
    'Other'
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            <Flag className="w-6 h-6 text-red-600" />
            <h2 className="text-xl font-bold text-gray-800">Report User</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <p className="text-gray-700 mb-4">
              Reporting: <strong>{reportedUserName}</strong>
            </p>
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
              <p className="text-sm text-yellow-800">
                <strong>Our Promise:</strong> Every report is taken seriously. We maintain TalksAlot as a safe space 
                where conversation enthusiasts can talk freely without fear of harassment or judgment.
              </p>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Reason for Report</label>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            >
              <option value="">Select a reason...</option>
              {reasons.map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Additional Details (Optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Provide any additional context that might help us understand the situation..."
              rows={4}
              className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>
        </form>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t bg-gray-50 rounded-b-2xl">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!reason || reportMutation.isPending}
            className="bg-red-600 hover:bg-red-700"
          >
            {reportMutation.isPending ? "Submitting..." : "Submit Report"}
          </Button>
        </div>
      </div>
    </div>
  );
}