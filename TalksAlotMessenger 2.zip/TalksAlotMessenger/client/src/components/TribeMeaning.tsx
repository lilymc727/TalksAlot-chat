import { Heart, Users, Home, Star } from 'lucide-react';

export function TribeMeaning() {
  const meanings = [
    {
      icon: Home,
      title: "Belonging",
      description: "A place where you truly fit in, where your love of conversation is celebrated, not tolerated.",
      color: "from-teal-500 to-cyan-500"
    },
    {
      icon: Users,
      title: "Community", 
      description: "Not just users, but a real group of people who understand what it's like to be called 'chatty'.",
      color: "from-purple-500 to-indigo-500"
    },
    {
      icon: Heart,
      title: "Acceptance",
      description: "Where you're welcomed exactly as you are - no need to tone it down or apologize for talking.",
      color: "from-pink-500 to-rose-500"
    },
    {
      icon: Star,
      title: "Shared Identity",
      description: "Conversation enthusiasts who 'get it' - the joy of deep talks and meaningful exchanges.",
      color: "from-amber-500 to-orange-500"
    }
  ];

  return (
    <div className="bg-gradient-to-r from-gray-50 to-slate-50 border border-gray-200 rounded-2xl shadow-lg p-8">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-3">
          What "Tribe" Means to Us
        </h3>
        <p className="text-gray-600 max-w-2xl mx-auto">
          When we say "you've found your tribe," we mean something deeper than just a group. 
          Your TalksAlot tribe represents four essential elements of true community.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {meanings.map((meaning, index) => {
          const Icon = meaning.icon;
          return (
            <div key={index} className="bg-white rounded-xl p-6 border border-gray-100 hover:shadow-md transition-shadow">
              <div className="flex items-start space-x-4">
                <div className={`w-12 h-12 bg-gradient-to-r ${meaning.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">
                    {meaning.title}
                  </h4>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {meaning.description}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8 p-6 bg-white rounded-xl border border-gray-100">
        <div className="text-center">
          <p className="text-lg font-medium text-purple-700 mb-2">
            "Welcome home, talkers!"
          </p>
          <p className="text-gray-600 text-sm">
            This is more than a greeting - it's recognition that you've found where you belong. 
            Your tribe isn't just people who tolerate your love of conversation; 
            we're people who share it, celebrate it, and understand that talking is how you connect with the world.
          </p>
        </div>
      </div>
    </div>
  );
}