import { useState } from 'react';
import { ChevronLeft, ChevronRight, Users, MessageCircle } from 'lucide-react';
import { Link } from 'wouter';

interface Room {
  id: string;
  name: string;
  description: string;
  topic: string;
  participants: any[];
  maxParticipants: number;
}

interface RoomStyle {
  emoji: string;
  bg: string;
  border: string;
}

interface RoomBrowserProps {
  rooms: Room[];
  roomStyles: Record<string, RoomStyle>;
}

export function RoomBrowser({ rooms, roomStyles }: RoomBrowserProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextRoom = () => {
    setCurrentIndex((prev) => (prev + 1) % rooms.length);
  };

  const prevRoom = () => {
    setCurrentIndex((prev) => (prev - 1 + rooms.length) % rooms.length);
  };

  const goToRoom = (index: number) => {
    setCurrentIndex(index);
  };

  if (!rooms.length) return null;

  const currentRoom = rooms[currentIndex];
  const roomStyle = roomStyles[currentRoom.name] || { emoji: "💬", bg: "from-gray-100 to-gray-200", border: "border-gray-300" };

  return (
    <div className="flex flex-col items-center space-y-6">
      {/* Main Room Display */}
      <div className="relative w-full max-w-md">
        <div
          className={`p-8 rounded-3xl bg-gradient-to-br ${roomStyle.bg} border-2 ${roomStyle.border} shadow-xl transform transition-all duration-300`}
        >
          <div className="text-center">
            <div className="text-6xl mb-4">{roomStyle.emoji}</div>
            <h3 className="font-bold text-gray-800 text-2xl mb-3">
              {currentRoom.name}
            </h3>
            <p className="text-gray-700 text-base mb-6 leading-relaxed">
              {currentRoom.description}
            </p>
            
            <div className="flex items-center justify-center gap-6 mb-6 text-sm">
              <div className="flex items-center gap-2 bg-white bg-opacity-70 px-3 py-2 rounded-full">
                <Users className="w-4 h-4" />
                <span className="font-medium">
                  {currentRoom.participants.length}/{currentRoom.maxParticipants} active
                </span>
              </div>
              {currentRoom.participants.length > 0 && (
                <div className="flex items-center gap-2 text-green-600 font-medium">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  Live now
                </div>
              )}
            </div>

            <Link
              href={`/room/${currentRoom.id}`}
              className="inline-block bg-teal-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-teal-700 transition-colors shadow-lg hover:shadow-xl transform hover:scale-105 duration-200"
            >
              <div className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                Join Conversation
              </div>
            </Link>
          </div>
        </div>

        {/* Navigation Arrows */}
        <button
          onClick={prevRoom}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 -translate-x-full bg-white dark:bg-gray-700 p-3 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110"
        >
          <ChevronLeft className="w-6 h-6 text-gray-600 dark:text-gray-300" />
        </button>
        
        <button
          onClick={nextRoom}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 translate-x-full bg-white dark:bg-gray-700 p-3 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110"
        >
          <ChevronRight className="w-6 h-6 text-gray-600 dark:text-gray-300" />
        </button>
      </div>

      {/* Room Indicators */}
      <div className="flex space-x-2 overflow-x-auto py-2 max-w-full">
        {rooms.map((room, index) => {
          const isActive = index === currentIndex;
          const style = roomStyles[room.name] || { emoji: "💬", bg: "", border: "" };
          
          return (
            <button
              key={room.id}
              onClick={() => goToRoom(index)}
              className={`flex-shrink-0 p-3 rounded-xl border-2 transition-all duration-200 ${
                isActive
                  ? 'border-teal-500 bg-teal-50 dark:bg-teal-900 scale-110'
                  : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 hover:border-gray-300 dark:hover:border-gray-500'
              }`}
            >
              <div className="flex flex-col items-center space-y-1">
                <span className="text-lg">{style.emoji}</span>
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                  isActive 
                    ? 'bg-teal-100 text-teal-800 dark:bg-teal-800 dark:text-teal-200'
                    : 'bg-gray-100 text-gray-600 dark:bg-gray-600 dark:text-gray-300'
                }`}>
                  {room.participants.length}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Room Counter */}
      <div className="text-center text-sm text-gray-500 dark:text-gray-400">
        Room {currentIndex + 1} of {rooms.length}
      </div>
    </div>
  );
}