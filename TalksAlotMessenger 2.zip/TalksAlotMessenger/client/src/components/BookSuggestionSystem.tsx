import { useState } from 'react';
import { Book, ThumbsUp, ShoppingCart, Users, TrendingUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface BookSuggestion {
  id: string;
  title: string;
  author: string;
  suggestedBy: string;
  votes: string[];
  description?: string;
  estimatedPrice: number;
  status: 'suggested' | 'popular' | 'approved' | 'ordered';
}

interface BookSuggestionSystemProps {
  roomName: string;
  currentUser: any;
  roomMembers: any[];
  roomTopic?: string;
}

export function BookSuggestionSystem({ roomName, currentUser, roomMembers, roomTopic }: BookSuggestionSystemProps) {
  const [showSuggestionForm, setShowSuggestionForm] = useState(false);
  const [newSuggestion, setNewSuggestion] = useState({
    title: '',
    author: '',
    description: '',
    estimatedPrice: ''
  });
  const { toast } = useToast();

  // Get room-specific book suggestions
  const getRoomSpecificSuggestions = () => {
    const suggestions: Record<string, BookSuggestion[]> = {
      'Book Club Corner': [
        {
          id: '1',
          title: 'The Seven Husbands of Evelyn Hugo',
          author: 'Taylor Jenkins Reid',
          suggestedBy: 'Sarah M.',
          votes: ['user1', 'user2', 'user3', 'user4', 'user5', 'user6'],
          description: 'A captivating novel about Hollywood glamour and secrets',
          estimatedPrice: 16,
          status: 'approved'
        }
      ],
      'Career Mentoring': [
        {
          id: '2',
          title: 'Atomic Habits',
          author: 'James Clear',
          suggestedBy: 'Lisa R.',
          votes: ['user2', 'user4', 'user5', 'user8'],
          description: 'Transform your career with better habits',
          estimatedPrice: 15,
          status: 'popular'
        }
      ],
      'Entrepreneurs Hub': [
        {
          id: '3',
          title: 'The Lean Startup',
          author: 'Eric Ries',
          suggestedBy: 'Mike K.',
          votes: ['user1', 'user3', 'user7'],
          description: 'Essential reading for startup founders',
          estimatedPrice: 18,
          status: 'suggested'
        }
      ],
      'Mental Health': [
        {
          id: '4',
          title: 'Maybe You Should Talk to Someone',
          author: 'Lori Gottlieb',
          suggestedBy: 'Emma S.',
          votes: ['user5', 'user6', 'user9', 'user10'],
          description: 'A therapist\'s own therapy journey',
          estimatedPrice: 17,
          status: 'popular'
        }
      ]
    };
    
    return suggestions[roomName] || [];
  };

  const [bookSuggestions, setBookSuggestions] = useState<BookSuggestion[]>(getRoomSpecificSuggestions());

  const voteForBook = (bookId: string) => {
    setBookSuggestions(prev => prev.map(book => {
      if (book.id === bookId) {
        const hasVoted = book.votes.includes(currentUser.id);
        const newVotes = hasVoted 
          ? book.votes.filter(id => id !== currentUser.id)
          : [...book.votes, currentUser.id];
        
        let newStatus = book.status;
        if (newVotes.length >= 5 && newStatus === 'suggested') {
          newStatus = 'popular';
          toast({
            title: "Book is Trending!",
            description: `"${book.title}" has 5+ votes and is now popular in your community`,
          });
        }
        if (newVotes.length >= Math.floor(roomMembers.length * 0.33) && newStatus === 'popular') {
          newStatus = 'approved';
          toast({
            title: "Book Approved for Group Order!",
            description: `"${book.title}" will be available for community purchase soon`,
          });
        }
        
        return { ...book, votes: newVotes, status: newStatus };
      }
      return book;
    }));
  };

  const submitSuggestion = () => {
    if (!newSuggestion.title || !newSuggestion.author) {
      toast({
        title: "Missing Information",
        description: "Please provide book title and author",
        variant: "destructive"
      });
      return;
    }

    const suggestion: BookSuggestion = {
      id: Date.now().toString(),
      title: newSuggestion.title,
      author: newSuggestion.author,
      suggestedBy: currentUser.name,
      votes: [currentUser.id],
      description: newSuggestion.description,
      estimatedPrice: parseInt(newSuggestion.estimatedPrice) || 15,
      status: 'suggested'
    };

    setBookSuggestions(prev => [suggestion, ...prev]);
    setNewSuggestion({ title: '', author: '', description: '', estimatedPrice: '' });
    setShowSuggestionForm(false);
    
    toast({
      title: "Book Suggested!",
      description: "Your suggestion has been added - encourage others to vote for it",
    });
  };

  const orderBook = (book: BookSuggestion) => {
    toast({
      title: "Ordering Book for Community",
      description: `"${book.title}" will be ordered for ${book.votes.length} members - $${book.estimatedPrice} each`,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'suggested': return 'bg-gray-100 text-gray-800';
      case 'popular': return 'bg-yellow-100 text-yellow-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'ordered': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'popular': return <TrendingUp className="w-4 h-4" />;
      case 'approved': return <ShoppingCart className="w-4 h-4" />;
      case 'ordered': return <Book className="w-4 h-4" />;
      default: return null;
    }
  };

  return (
    <div className="bg-amber-50 dark:bg-amber-900 rounded-lg p-4 mt-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Book className="w-5 h-5 text-amber-600" />
          <h3 className="font-semibold text-amber-800 dark:text-amber-200">Community Book Suggestions</h3>
        </div>
        <button
          onClick={() => setShowSuggestionForm(!showSuggestionForm)}
          className="bg-amber-500 text-white px-3 py-1 rounded-lg hover:bg-amber-600 transition-colors text-sm"
        >
          Suggest Book
        </button>
      </div>

      <p className="text-amber-700 dark:text-amber-300 text-sm mb-4">
        {roomName === 'Book Club Corner' 
          ? 'When 5+ members vote for the same book, it becomes available for group ordering! Host supplies books for everyone.'
          : `Suggest books relevant to ${roomName} discussions. When enough members vote, books become available for group purchase.`
        }
      </p>

      {showSuggestionForm && (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 mb-4 border">
          <h4 className="font-medium mb-3">Suggest a Book</h4>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Book title"
                value={newSuggestion.title}
                onChange={(e) => setNewSuggestion(prev => ({ ...prev, title: e.target.value }))}
                className="p-2 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
              />
              <input
                type="text"
                placeholder="Author"
                value={newSuggestion.author}
                onChange={(e) => setNewSuggestion(prev => ({ ...prev, author: e.target.value }))}
                className="p-2 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
              />
            </div>
            <textarea
              placeholder={`How does this book relate to ${roomName}? Why should we read it?`}
              value={newSuggestion.description}
              onChange={(e) => setNewSuggestion(prev => ({ ...prev, description: e.target.value }))}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
              rows={2}
            />
            <div className="flex items-center gap-3">
              <input
                type="number"
                placeholder="Estimated price ($)"
                value={newSuggestion.estimatedPrice}
                onChange={(e) => setNewSuggestion(prev => ({ ...prev, estimatedPrice: e.target.value }))}
                className="p-2 border rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm w-32"
              />
              <div className="flex gap-2">
                <button
                  onClick={submitSuggestion}
                  className="bg-amber-500 text-white px-4 py-2 rounded-lg hover:bg-amber-600 transition-colors text-sm"
                >
                  Submit
                </button>
                <button
                  onClick={() => setShowSuggestionForm(false)}
                  className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition-colors text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {bookSuggestions.map(book => {
          const hasVoted = book.votes.includes(currentUser.id);
          const votePercentage = (book.votes.length / roomMembers.length) * 100;
          
          return (
            <div key={book.id} className="bg-white dark:bg-gray-800 rounded-lg p-4 border">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-gray-800 dark:text-white">{book.title}</h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${getStatusColor(book.status)}`}>
                      {getStatusIcon(book.status)}
                      {book.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">by {book.author}</p>
                  <p className="text-xs text-gray-500">Suggested by {book.suggestedBy}</p>
                  {book.description && (
                    <p className="text-sm text-gray-700 dark:text-gray-200 mt-1">{book.description}</p>
                  )}
                </div>
                <div className="text-right ml-4">
                  <div className="text-sm font-medium text-gray-600 dark:text-gray-300">
                    ${book.estimatedPrice}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => voteForBook(book.id)}
                    className={`flex items-center gap-1 px-3 py-1 rounded-lg transition-colors text-sm ${
                      hasVoted 
                        ? 'bg-amber-500 text-white' 
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300'
                    }`}
                  >
                    <ThumbsUp className="w-4 h-4" />
                    {book.votes.length}
                  </button>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Users className="w-4 h-4" />
                    {Math.round(votePercentage)}% of room
                  </div>
                </div>
                
                {book.status === 'approved' && (
                  <button
                    onClick={() => orderBook(book)}
                    className="bg-green-500 text-white px-4 py-1 rounded-lg hover:bg-green-600 transition-colors text-sm flex items-center gap-1"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    Order for Group
                  </button>
                )}
              </div>
              
              {book.votes.length >= 5 && book.status !== 'approved' && (
                <div className="mt-2 p-2 bg-yellow-50 dark:bg-yellow-900 rounded text-sm text-yellow-800 dark:text-yellow-200">
                  🔥 Trending! Need {Math.floor(roomMembers.length * 0.33) - book.votes.length} more votes for group order
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}