import { Check } from 'lucide-react';
import { CONVERSATION_PREFERENCES, type ConversationPreference } from '@shared/topicCategories';

interface ConversationPreferencesProps {
  selectedPreferences: ConversationPreference[];
  onPreferencesChange: (preferences: ConversationPreference[]) => void;
  maxSelections?: number;
}

export function ConversationPreferences({ 
  selectedPreferences, 
  onPreferencesChange, 
  maxSelections = 8 
}: ConversationPreferencesProps) {
  
  const togglePreference = (preference: ConversationPreference) => {
    if (selectedPreferences.includes(preference)) {
      onPreferencesChange(selectedPreferences.filter(p => p !== preference));
    } else if (selectedPreferences.length < maxSelections) {
      onPreferencesChange([...selectedPreferences, preference]);
    }
  };

  const getPreferenceStyle = (preference: ConversationPreference) => {
    if (preference.includes('Quick')) return 'from-green-400 to-emerald-500';
    if (preference.includes('Medium')) return 'from-yellow-400 to-orange-500';
    if (preference.includes('Deep') || preference.includes('hours')) return 'from-purple-400 to-pink-500';
    if (preference.includes('Voice') || preference.includes('Video')) return 'from-blue-400 to-indigo-500';
    if (preference.includes('Group')) return 'from-teal-400 to-cyan-500';
    if (preference.includes('Advice') || preference.includes('Support')) return 'from-rose-400 to-pink-500';
    return 'from-gray-400 to-slate-500';
  };

  const getPreferenceEmoji = (preference: ConversationPreference) => {
    if (preference.includes('Quick')) return '⚡';
    if (preference.includes('Medium')) return '💬';
    if (preference.includes('Deep') || preference.includes('hours')) return '🌊';
    if (preference.includes('Voice')) return '🎤';
    if (preference.includes('Video')) return '📹';
    if (preference.includes('Text')) return '✍️';
    if (preference.includes('Group')) return '👥';
    if (preference.includes('One-on-One')) return '🫂';
    if (preference.includes('Advice')) return '💡';
    if (preference.includes('Venting')) return '🗣️';
    if (preference.includes('Listening')) return '👂';
    if (preference.includes('Debate')) return '🤔';
    if (preference.includes('Support')) return '🤗';
    if (preference.includes('Casual')) return '😊';
    if (preference.includes('Serious')) return '🎯';
    return '💭';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Conversation Preferences</h3>
        <span className="text-sm text-gray-500">
          {selectedPreferences.length}/{maxSelections} selected
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {CONVERSATION_PREFERENCES.map(preference => {
          const isSelected = selectedPreferences.includes(preference);
          const canSelect = isSelected || selectedPreferences.length < maxSelections;
          
          return (
            <button
              key={preference}
              onClick={() => togglePreference(preference)}
              disabled={!canSelect}
              className={`p-4 rounded-lg border transition-all text-left ${
                isSelected
                  ? 'bg-teal-100 border-teal-300 text-teal-800 dark:bg-teal-900 dark:border-teal-600 dark:text-teal-200'
                  : canSelect
                  ? 'bg-white border-gray-200 hover:border-gray-300 dark:bg-gray-700 dark:border-gray-600 dark:hover:border-gray-500'
                  : 'bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{getPreferenceEmoji(preference)}</span>
                  <span className="text-sm font-medium">{preference}</span>
                </div>
                {isSelected && <Check className="w-4 h-4 text-teal-600" />}
              </div>
            </button>
          );
        })}
      </div>

      <div className="text-xs text-gray-500 mt-4">
        <p>These preferences help us match you with compatible conversation partners who share similar communication styles and interests.</p>
      </div>
    </div>
  );
}