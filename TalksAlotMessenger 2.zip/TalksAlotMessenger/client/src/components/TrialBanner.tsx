import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Clock, Crown, X } from 'lucide-react';

interface TrialBannerProps {
  hoursLeft: number;
  onUpgrade: () => void;
  onDismiss: () => void;
}

export function TrialBanner({ hoursLeft, onUpgrade, onDismiss }: TrialBannerProps) {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const handleDismiss = () => {
    setIsVisible(false);
    onDismiss();
  };

  const getUrgencyColor = () => {
    if (hoursLeft <= 1) return "from-red-500 to-pink-500";
    if (hoursLeft <= 3) return "from-orange-500 to-red-500";
    return "from-teal-500 to-cyan-500";
  };

  const getUrgencyText = () => {
    if (hoursLeft === 0) return "Trial expires in under 1 hour!";
    if (hoursLeft === 1) return "1 hour left in trial!";
    return `${hoursLeft} hours left in trial`;
  };

  return (
    <div className={`bg-gradient-to-r ${getUrgencyColor()} text-white p-4 relative`}>
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5" />
            <span className="font-semibold">{getUrgencyText()}</span>
          </div>
          <span className="text-sm opacity-90">
            Continue enjoying unlimited access to all rooms and features
          </span>
        </div>
        
        <div className="flex items-center space-x-3">
          <Button
            onClick={onUpgrade}
            variant="ghost"
            className="bg-white/20 hover:bg-white/30 text-white border-white/30"
          >
            <Crown className="w-4 h-4 mr-2" />
            Upgrade Now
          </Button>
          <Button
            onClick={handleDismiss}
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}