import { useState } from "react";
import { Button } from "@/components/ui/button";

interface AgeVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerified: () => void;
}

export function AgeVerificationModal({ isOpen, onClose, onVerified }: AgeVerificationModalProps) {
  const [birthYear, setBirthYear] = useState("");

  if (!isOpen) return null;

  const handleVerify = () => {
    const currentYear = new Date().getFullYear();
    const age = currentYear - parseInt(birthYear);
    
    if (age >= 19) {
      onVerified();
    } else {
      alert("TalksAlot is a mature community for adults 19 and older.");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl max-w-md w-full mx-4">
        <h2 className="text-2xl font-bold mb-4">Mature Community Access</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          TalksAlot is designed for mature adults who appreciate meaningful conversation. Please verify you're 19 or older.
        </p>
        
        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">What year were you born?</label>
          <input
            type="number"
            value={birthYear}
            onChange={(e) => setBirthYear(e.target.value)}
            placeholder="e.g., 1990"
            min="1900"
            max={new Date().getFullYear()}
            className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
        </div>

        <div className="flex gap-3">
          <Button
            onClick={handleVerify}
            disabled={!birthYear}
            className="flex-1 bg-purple-600 hover:bg-purple-700"
          >
            Verify Age
          </Button>
          <Button
            onClick={onClose}
            variant="outline"
            className="flex-1"
          >
            Cancel
          </Button>
        </div>

        <p className="text-xs text-gray-500 mt-4 text-center">
          We respect your privacy. Age information is only used for verification and safety purposes.
        </p>
      </div>
    </div>
  );
}