import { Shield, CheckCircle } from "lucide-react";

export function SecurityBadge() {
  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="bg-green-500 text-white p-3 rounded-lg shadow-lg flex items-center space-x-2 text-sm font-medium">
        <Shield className="h-4 w-4" />
        <span>Secure & Verified</span>
        <CheckCircle className="h-4 w-4" />
      </div>
    </div>
  );
}