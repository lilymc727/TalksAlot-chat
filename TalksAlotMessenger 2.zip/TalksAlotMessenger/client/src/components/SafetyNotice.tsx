import { Shield, CheckCircle, Lock } from "lucide-react";

export function SafetyNotice() {
  return (
    <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4 mb-6">
      <div className="flex items-center space-x-3">
        <Shield className="h-6 w-6 text-green-600" />
        <div className="flex-1">
          <h4 className="font-semibold text-green-800 dark:text-green-300 text-sm">
            Protected Space - All Users Verified & Secure
          </h4>
          <div className="flex items-center space-x-4 mt-1">
            <div className="flex items-center space-x-1">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-xs text-green-700 dark:text-green-400">Zero tolerance for harassment</span>
            </div>
            <div className="flex items-center space-x-1">
              <Lock className="h-4 w-4 text-green-600" />
              <span className="text-xs text-green-700 dark:text-green-400">Enterprise-grade security</span>
            </div>
            <div className="flex items-center space-x-1">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-xs text-green-700 dark:text-green-400">No anonymous users</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}