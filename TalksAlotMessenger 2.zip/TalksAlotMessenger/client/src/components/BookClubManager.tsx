import { useState } from 'react';
import { Book, Calendar, Users, ShoppingCart, MessageCircle, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface BookClub {
  id: string;
  title: string;
  author: string;
  cover?: string;
  description: string;
  startDate: string;
  endDate: string;
  meetingSchedule: string;
  maxMembers: number;
  currentMembers: number;
  status: 'upcoming' | 'active' | 'completed';
  hostSuppliesBook: boolean;
  price?: number;
}

interface BookClubManagerProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: any;
}

export function BookClubManager({ isOpen, onClose, currentUser }: BookClubManagerProps) {
  const [activeTab, setActiveTab] = useState<'browse' | 'create' | 'myClubs'>('browse');
  const { toast } = useToast();

  // Mock book clubs - in real app, fetch from backend
  const bookClubs: BookClub[] = [
    {
      id: '1',
      title: 'The Seven Husbands of Evelyn Hugo',
      author: 'Taylor Jenkins Reid',
      description: 'A captivating novel about a reclusive Hollywood icon who finally decides to tell her story',
      startDate: '2025-01-15',
      endDate: '2025-02-15',
      meetingSchedule: 'Weekly Sundays at 7 PM',
      maxMembers: 12,
      currentMembers: 8,
      status: 'upcoming',
      hostSuppliesBook: true,
      price: 15
    },
    {
      id: '2', 
      title: 'Atomic Habits',
      author: 'James Clear',
      description: 'Life-changing guide to building good habits and breaking bad ones',
      startDate: '2025-01-20',
      endDate: '2025-03-01',
      meetingSchedule: 'Bi-weekly Saturdays at 2 PM',
      maxMembers: 15,
      currentMembers: 11,
      status: 'upcoming',
      hostSuppliesBook: true,
      price: 18
    },
    {
      id: '3',
      title: 'The Midnight Library',
      author: 'Matt Haig',
      description: 'A philosophical novel about life, regret, and the possibilities that exist between life and death',
      startDate: '2025-01-01',
      endDate: '2025-01-31',
      meetingSchedule: 'Weekly Wednesdays at 8 PM',
      maxMembers: 10,
      currentMembers: 10,
      status: 'active',
      hostSuppliesBook: false
    }
  ];

  const joinBookClub = (club: BookClub) => {
    if (club.hostSuppliesBook && club.price) {
      toast({
        title: "Joining Book Club",
        description: `You'll be charged $${club.price} for your copy of "${club.title}" and club membership`,
      });
    } else {
      toast({
        title: "Joined Book Club!",
        description: `Welcome to "${club.title}" - get your copy and join the discussion`,
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming': return 'bg-blue-100 text-blue-800';
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Book className="w-8 h-8 text-amber-500" />
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Book Club Corner</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              ✕
            </button>
          </div>

          <div className="mb-6">
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              Join curated book clubs where the host supplies books for everyone. Deep discussions, shared reading experiences, and meaningful connections through literature.
            </p>
            
            <div className="flex gap-3 mb-6">
              <button
                onClick={() => setActiveTab('browse')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === 'browse'
                    ? 'bg-amber-500 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300'
                }`}
              >
                <Book className="w-4 h-4 inline mr-2" />
                Browse Clubs
              </button>
              <button
                onClick={() => setActiveTab('create')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === 'create'
                    ? 'bg-amber-500 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300'
                }`}
              >
                <Users className="w-4 h-4 inline mr-2" />
                Host a Club
              </button>
              <button
                onClick={() => setActiveTab('myClubs')}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  activeTab === 'myClubs'
                    ? 'bg-amber-500 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300'
                }`}
              >
                <MessageCircle className="w-4 h-4 inline mr-2" />
                My Clubs
              </button>
            </div>
          </div>

          {activeTab === 'browse' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold mb-4">Available Book Clubs</h3>
              {bookClubs.map(club => (
                <div key={club.id} className="border rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-xl font-semibold text-gray-800 dark:text-white">
                          {club.title}
                        </h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(club.status)}`}>
                          {club.status}
                        </span>
                        {club.hostSuppliesBook && (
                          <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                            Book Included
                          </span>
                        )}
                      </div>
                      <p className="text-gray-600 dark:text-gray-300 text-sm mb-1">by {club.author}</p>
                      <p className="text-gray-700 dark:text-gray-200 mb-3">{club.description}</p>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600 dark:text-gray-300">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>{club.startDate} - {club.endDate}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{club.meetingSchedule}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          <span>{club.currentMembers}/{club.maxMembers} members</span>
                        </div>
                        {club.hostSuppliesBook && club.price && (
                          <div className="flex items-center gap-1">
                            <ShoppingCart className="w-4 h-4" />
                            <span>${club.price} (book + membership)</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="ml-4">
                      <button
                        onClick={() => joinBookClub(club)}
                        disabled={club.currentMembers >= club.maxMembers}
                        className="bg-amber-500 text-white px-6 py-2 rounded-lg hover:bg-amber-600 disabled:bg-gray-400 disabled:cursor-not-allowed"
                      >
                        {club.currentMembers >= club.maxMembers ? 'Full' : 
                         club.hostSuppliesBook ? `Join ($${club.price})` : 'Join Club'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'create' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold mb-4">Host a Book Club</h3>
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Book Title</label>
                      <input
                        type="text"
                        placeholder="Enter book title"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Author</label>
                      <input
                        type="text"
                        placeholder="Author name"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2">Book Description</label>
                    <textarea
                      placeholder="Tell people why you chose this book..."
                      rows={3}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Start Date</label>
                      <input
                        type="date"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">End Date</label>
                      <input
                        type="date"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Meeting Schedule</label>
                      <input
                        type="text"
                        placeholder="e.g., Weekly Sundays at 7 PM"
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Max Members</label>
                      <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500">
                        <option value="8">8 members</option>
                        <option value="10">10 members</option>
                        <option value="12">12 members</option>
                        <option value="15">15 members</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="border-t pt-4">
                    <div className="flex items-center gap-3 mb-4">
                      <input type="checkbox" id="supplyBooks" className="w-4 h-4" />
                      <label htmlFor="supplyBooks" className="text-sm font-medium">
                        I will supply books for all members (recommended)
                      </label>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Book Cost (per copy)</label>
                        <input
                          type="number"
                          placeholder="15.00"
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Membership Fee</label>
                        <input
                          type="number"
                          placeholder="5.00"
                          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Members will be charged book cost + membership fee. You handle book ordering and distribution.
                    </p>
                  </div>
                  
                  <button
                    onClick={() => {
                      toast({
                        title: "Book Club Created!",
                        description: "Your book club is now live and accepting members",
                      });
                      setActiveTab('browse');
                    }}
                    className="w-full bg-amber-500 text-white py-3 rounded-lg hover:bg-amber-600 transition-colors"
                  >
                    Create Book Club
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'myClubs' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold mb-4">My Book Clubs</h3>
              <div className="text-center py-12 text-gray-500">
                <Book className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>You haven't joined any book clubs yet.</p>
                <p className="text-sm">Browse available clubs or host your own!</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}