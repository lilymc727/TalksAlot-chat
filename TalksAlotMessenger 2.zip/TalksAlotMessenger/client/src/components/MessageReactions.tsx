import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Heart, Laugh, ThumbsUp, Brain, Hug } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';

interface MessageReactionsProps {
  messageId: string;
  reactions: { emoji: string; users: string[] }[];
  currentUserId: string;
  onReact: (emoji: string) => void;
}

export function MessageReactions({ messageId, reactions, currentUserId, onReact }: MessageReactionsProps) {
  const [showReactionPicker, setShowReactionPicker] = useState(false);

  const reactionOptions = [
    { emoji: '👍', icon: ThumbsUp, label: 'Like', karmaType: 'like' },
    { emoji: '❤️', icon: Heart, label: 'Love', karmaType: 'supportive' },
    { emoji: '😂', icon: Laugh, label: 'Funny', karmaType: 'funny' },
    { emoji: '🧠', icon: Brain, label: 'Insightful', karmaType: 'insightful' },
    { emoji: '🤗', icon: Hug, label: 'Supportive', karmaType: 'supportive' },
  ];

  const reactMutation = useMutation({
    mutationFn: ({ emoji, karmaType }: { emoji: string; karmaType: string }) => 
      apiRequest("/api/messages/react", {
        method: "POST",
        body: JSON.stringify({ messageId, emoji, karmaType }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      setShowReactionPicker(false);
    },
  });

  const handleReact = (emoji: string, karmaType: string) => {
    reactMutation.mutate({ emoji, karmaType });
    onReact(emoji);
  };

  const getUserReaction = () => {
    for (const reaction of reactions) {
      if (reaction.users.includes(currentUserId)) {
        return reaction.emoji;
      }
    }
    return null;
  };

  const userReaction = getUserReaction();

  return (
    <div className="flex items-center space-x-2 mt-2">
      {/* Existing reactions */}
      {reactions.map((reaction) => (
        <Button
          key={reaction.emoji}
          variant="ghost"
          size="sm"
          className={`h-6 px-2 text-xs ${
            reaction.users.includes(currentUserId) 
              ? 'bg-teal-100 border border-teal-300' 
              : 'hover:bg-gray-100'
          }`}
          onClick={() => handleReact(reaction.emoji, 'like')}
        >
          <span className="mr-1">{reaction.emoji}</span>
          <span>{reaction.users.length}</span>
        </Button>
      ))}

      {/* Add reaction button */}
      <div className="relative">
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-2 text-xs hover:bg-gray-100"
          onClick={() => setShowReactionPicker(!showReactionPicker)}
        >
          <span className="text-gray-500">+</span>
        </Button>

        {/* Reaction picker */}
        {showReactionPicker && (
          <div className="absolute bottom-8 left-0 bg-white border rounded-lg shadow-lg p-2 flex space-x-1 z-10">
            {reactionOptions.map((option) => {
              const Icon = option.icon;
              return (
                <Button
                  key={option.emoji}
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 hover:bg-gray-100"
                  onClick={() => handleReact(option.emoji, option.karmaType)}
                  title={option.label}
                >
                  <Icon className="w-4 h-4" />
                </Button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}